<?php

namespace app\controllers;

use app\core\Controller;
use app\services\GamificacaoService;

class DashboardController extends Controller
{
    private GamificacaoService $gamificacaoService;

    public function __construct()
    {
        $this->gamificacaoService = new GamificacaoService();
    }

    public function index()
    {
        $this->autenticacaoRequired();

        $usuario = $_SESSION['usuario_logado'];

        $data = [];
        $data['usuario'] = $usuario;
        $data['gamificacao'] = $this->gamificacaoService->getGamificacao($usuario->getId());

        $this->view('dashboard/dashboard', $data);
    }
}
