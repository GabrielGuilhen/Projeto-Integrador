CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    nickname VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(255) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    data_nascimento DATE NOT NULL,
    foto VARCHAR(255) NULL,
    status ENUM('ativo', 'bloqueado') NOT NULL DEFAULT 'ativo',
    perfil ENUM('comum', 'administrador') NOT NULL DEFAULT 'comum',
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS usuario_comum (
    usuario_id INT PRIMARY KEY,
    xp_total INT NOT NULL DEFAULT 0,
    nivel INT NOT NULL DEFAULT 1,
    streak_atual INT NOT NULL DEFAULT 0,
    maior_streak INT NOT NULL DEFAULT 0,
    data_ultimo_xp DATE NULL,
    visibilidade_ranking BOOLEAN NOT NULL DEFAULT TRUE,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS administradores (
    usuario_id INT PRIMARY KEY,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS categorias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    icone VARCHAR(50) NULL,
    tipo ENUM('receita', 'despesa') NOT NULL DEFAULT 'despesa',
    limite_orcamento DECIMAL(10,2) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS metas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    nome_meta VARCHAR(100) NOT NULL,
    tipo_meta ENUM('economizar', 'comprar', 'investir') NOT NULL DEFAULT 'economizar',
    valor_alvo DECIMAL(10,2) NOT NULL,
    valor_atual DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    data_limite DATE NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS registro_financeiro (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    categoria_id INT NULL,
    tipo ENUM('receita', 'despesa') NOT NULL DEFAULT 'despesa',
    valor DECIMAL(10,2) NOT NULL,
    data_registro DATE NOT NULL,
    descricao VARCHAR(255) NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (categoria_id) REFERENCES categorias(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS parcelamentos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    categoria_id INT NULL,
    descricao VARCHAR(255) NOT NULL,
    valor_total DECIMAL(10,2) NOT NULL,
    quantidade_parcelas INT NOT NULL,
    parcelas_pagas INT NOT NULL DEFAULT 0,
    data_primeira_parcela DATE NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (categoria_id) REFERENCES categorias(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO usuarios (nome, nickname, email, senha, data_nascimento, perfil)
VALUES ('Administrador', 'admin', 'admin@dflg.com', '$2y$12$Zon6XY2fKd2Ua4YIId4MC.dVB3XxTHDlK96rgDJYEnJRoXxoZ84XS', '2000-01-01', 'administrador');

INSERT INTO administradores (usuario_id) VALUES (LAST_INSERT_ID());

-- admin@dflg.com
-- admin123

INSERT INTO categorias (nome, icone, tipo) VALUES
('Salário', 'bi-cash-coin', 'receita'),
('Freelance', 'bi-laptop', 'receita'),
('Rendimentos', 'bi-graph-up-arrow', 'receita'),
('Outras receitas', 'bi-plus-circle', 'receita'),
('Alimentação', 'bi-basket', 'despesa'),
('Moradia', 'bi-house-door', 'despesa'),
('Transporte', 'bi-bus-front', 'despesa'),
('Saúde', 'bi-heart-pulse', 'despesa'),
('Educação', 'bi-book', 'despesa'),
('Lazer', 'bi-controller', 'despesa'),
('Compras', 'bi-bag', 'despesa'),
('Contas e assinaturas', 'bi-receipt', 'despesa'),
('Outras despesas', 'bi-dash-circle', 'despesa');
