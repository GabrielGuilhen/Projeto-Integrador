<?php

namespace app\repositories;

use app\database\ConnectionFactory;
use app\models\UsuarioComum;
use PDO;

class UsuarioComumRepository
{
    private PDO $connection;

    public function __construct()
    {
        $this->connection = ConnectionFactory::getConnection();
    }

    public function criarParaUsuario(int $usuarioId): bool
    {
        $sql = "INSERT INTO usuario_comum (usuario_id) VALUES (:usuarioId)";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':usuarioId', $usuarioId);

        return $stmt->execute();
    }

    public function getPorUsuarioId(int $usuarioId)
    {
        $sql = "SELECT * FROM usuario_comum WHERE usuario_id = :usuarioId";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':usuarioId', $usuarioId);
        $stmt->execute();
        $usuarioComum = $stmt->fetch();

        if ($usuarioComum == null) {
            return false;
        }

        return UsuarioComum::arrayParaObjeto($usuarioComum);
    }

    public function atualizarXp(UsuarioComum $usuarioComum): bool
    {
        $sql = "UPDATE usuario_comum SET xp_total = :xpTotal, nivel = :nivel, data_ultimo_xp = :dataUltimoXp " .
            "WHERE usuario_id = :usuarioId";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':xpTotal', $usuarioComum->getXpTotal());
        $stmt->bindValue(':nivel', $usuarioComum->getNivel());
        $stmt->bindValue(':dataUltimoXp', $usuarioComum->getDataUltimoXp());
        $stmt->bindValue(':usuarioId', $usuarioComum->getUsuarioId());

        return $stmt->execute();
    }
}
