<?php

namespace app\services;

use app\repositories\UsuarioComumRepository;
use DateTimeImmutable;

class GamificacaoService
{
    private UsuarioComumRepository $repository;

    public function __construct()
    {
        $this->repository = new UsuarioComumRepository();
    }

    /**
     * RN07: XP só pode ser concedido no primeiro registro financeiro do dia,
     * verificando a coluna data_ultimo_xp antes de somar pontos.
     */
    public function adicionarPontos(int $usuarioId, int $pontos = 10): bool
    {
        $usuarioComum = $this->repository->getPorUsuarioId($usuarioId);

        if (!$usuarioComum) {
            return false;
        }

        $hoje = (new DateTimeImmutable())->format('Y-m-d');

        if ($usuarioComum->getDataUltimoXp() === $hoje) {
            return false;
        }

        $usuarioComum->setXpTotal($usuarioComum->getXpTotal() + $pontos);
        $usuarioComum->setNivel(intdiv($usuarioComum->getXpTotal(), 100) + 1);
        $usuarioComum->setDataUltimoXp($hoje);

        return $this->repository->atualizarXp($usuarioComum);
    }

    public function getGamificacao(int $usuarioId)
    {
        return $this->repository->getPorUsuarioId($usuarioId);
    }
}
