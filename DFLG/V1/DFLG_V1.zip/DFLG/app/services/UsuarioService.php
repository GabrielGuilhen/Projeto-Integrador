<?php

namespace app\services;

use app\models\Usuario;
use app\repositories\UsuarioRepository;
use app\repositories\UsuarioComumRepository;

class UsuarioService
{
    private UsuarioRepository $repository;
    private UsuarioComumRepository $usuarioComumRepository;

    public function __construct()
    {
        $this->repository = new UsuarioRepository();
        $this->usuarioComumRepository = new UsuarioComumRepository();
    }

    public function cadastrar(Usuario $usuario): bool
    {
        // RN02/RF01: e-mail e nickname precisam ser únicos
        if ($this->repository->getUsuarioByEmail($usuario->getEmail())) {
            return false;
        }

        if ($this->repository->getUsuarioByNickname($usuario->getNickname())) {
            return false;
        }

        if (!$this->repository->saveUsuario($usuario)) {
            return false;
        }

        $usuarioCriado = $this->repository->getUsuarioByEmail($usuario->getEmail());
        $this->usuarioComumRepository->criarParaUsuario($usuarioCriado->getId());

        return true;
    }

    public function getUsuarioById(int $id)
    {
        return $this->repository->getUsuarioById($id);
    }
}
