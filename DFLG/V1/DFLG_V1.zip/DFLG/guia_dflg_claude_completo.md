# Manual Técnico e Arquitetural Avançado - DFLG Investments
**Para execução via Claude Code**

Este documento é o guia definitivo, exaustivo e detalhado para a codificação, refatoração e implementação da arquitetura do DFLG Investments. O foco exclusivo da plataforma é a gestão financeira integrada a um sistema de gamificação para impulsionar o cumprimento de metas, não possuindo escopo educacional.

---

## 1. Padrões Arquiteturais e Estrutura do Framework

O sistema utiliza uma arquitetura MVC (Model-View-Controller) robusta, suplementada por camadas de Service e Repository para isolamento de responsabilidades.

### 1.1. O Fluxo de Requisições e Roteamento
* O Front Controller do sistema é o arquivo `public/index.php`, que centraliza as chamadas e registra as rotas.
* A classe `app/core/Router.php` captura a URI e o método HTTP (GET, POST, etc.).
* O método `dispatch` instancia dinamicamente as Controllers correspondentes, eliminando a necessidade do uso manual de `new Controller()`.
* **Ajuste de Servidor:** O método `run()` do Router possui lógica para limpar a URL caso o sistema seja executado em uma subpasta no Apache. O redirecionamento exige um arquivo `.htaccess` na raiz e outro na pasta `public/` para garantir que o tráfego chegue ao `index.php`.

### 1.2. Autoloading e Namespaces
* Para evitar a inclusão manual de arquivos e conflitos de nomenclatura, as classes são agrupadas em namespaces (ex: `app\models`, `app\controllers`).
* O arquivo `app/core/Autoload.php` usa `spl_autoload_register` para carregar as classes dinamicamente quando requisitadas.

### 1.3. Conexão com Banco de Dados e Resiliência
* A classe `app\database\ConnectionFactory` implementa Lazy Initialization para a gestão centralizada da conexão.
* Se o banco de dados especificado em `Config.php` não for encontrado, o sistema realiza um fallback invocando o `DatabaseInitializer`, que cria o banco e executa o `script.sql` automaticamente.

---

## 2. Camadas de Desenvolvimento (Como Codificar)

### 2.1. Controller (Apresentação e Controle)
* Recebe as requisições HTTP e retorna as Views.
* Utiliza a classe `app\helpers\Validador.php` para checagens estruturais de formulários, como campos obrigatórios.
* Deve invocar os métodos de segurança herdados da Controller base: `autenticacaoRequired()` para garantir que o usuário está logado e `adminRequired()` para rotas de gestão.

### 2.2. Service (Regras de Negócio)
* Concentra toda a lógica do domínio financeiro.
* Antes de chamar um Repository, o Service deve validar regras complexas (ex: "e-mail já cadastrado" ou "limite de categoria excedido").

### 2.3. Repository (Acesso a Dados)
* Isola os comandos SQL da aplicação.
* **Regra Absoluta:** O uso de `prepare` e `bindValue` do PDO é obrigatório em todas as consultas para mitigar ataques de SQL Injection.

### 2.4. Model (Entidades)
* Representa os dados da tabela.
* O método `arrayParaObjeto()` deve ser utilizado para hidratar instâncias do Model a partir dos retornos do banco, evitando o uso de arrays puros.

---

## 3. Segurança, Sessão e Controle de Acesso

* **Sessão:** A identidade é gerenciada via sessão PHP. Após validação, o objeto `Usuario` inteiro é armazenado em `$_SESSION['usuario_logado']`, disponibilizando dados como perfil e nome sem novas consultas ao banco.
* **Conflitos Apache:** Ao rodar no Apache, se houver conflitos com as sessões criadas via `php -S`, o diretório de sessões do sistema (ex: `/var/lib/php/sessions/`) deve ser limpo.
* **Git:** Os commits devem ser enviados usando um Personal Access Token (PAT) com a permissão "repo". Credenciais não devem ser salvas permanentemente no ambiente local.

---

## 4. O Dicionário de Dados e Módulos (Baseado no DER)

O sistema deve implementar as seguintes entidades e tabelas para suportar a operação:

1. **Usuario:** Tabela central. Deve conter nome, `nickname` (único), e-mail (único), senha (hash via `password_verify`), `data_nascimento`, `foto`, `status` (ativo/bloqueado) e `perfil` (comum ou administrador).
2. **UsuarioComum (Atributos de Gamificação):** Armazena `maior_streak`, `streak_atual`, `data_ultimo_xp`, `nivel`, XP total e configurações de `visibilidade_ranking`.
3. **Meta:** Entidade alvo do sistema. Registra o `nome_meta`, `valor_alvo`, `valor_atual`, `data_limite` (sempre futura), e `tipo_meta` (economizar, comprar, investir).
4. **Categoria e Meta_Categoria:** Gerencia as classificações de despesas e o limite de orçamento estipulado para cada uma.
5. **RegistroFinanceiro / Transacoes:** Registra os aportes e gastos diários, vinculados a uma Categoria e um Usuário.
6. **Parcelamento:** Registra obrigações a prazo, contendo valor total, quantidade de parcelas e parcelas já pagas.
7. **Simulacao_Investimento:** Armazena projeções de crescimento patrimonial, incluindo aporte mensal, taxa de retorno e período projetado.

---

## 5. Roadmap e Especificações de Implementação (Análise de Aderência)

A execução deve seguir uma ordem estrita de prioridade, corrigindo a lógica existente antes de criar novos módulos.

### Fase 1: Correções Críticas (Quick Wins)
* **Ativação de Segurança no Dashboard:** O arquivo `DashboardController` possui a linha `//$this->autenticacaoRequired();` comentada. Isso viola a regra de negócio RN11, permitindo acesso sem login. **Ação:** Descomentar e habilitar a verificação imediatamente.
* **Correção da Lógica de Experiência (RN07):** Atualmente, a função `adicionarPontos()` recompensa toda e qualquer transação. **Ação:** Implementar a validação que verifica a coluna `data_ultimo_xp`. O ganho de XP só pode ocorrer no *primeiro* registro financeiro do dia para evitar "farm" de níveis com registros falsos.
* **Adequação do Cadastro (RN02, RF01):** O sistema exige nomes de usuário únicos. **Ação:** Adicionar a coluna `nickname` à tabela `usuarios`, incluí-la no fluxo de `AutenticacaoController` e garantir validação de unicidade no banco (UNIQUE constraint) e no Controller.

### Fase 2: O Núcleo do Sistema (Metas e Transações)
* **Implementação do Módulo de Metas (RF08, RN08):** O sistema carece da funcionalidade principal que guia o usuário.
  * **Ação:** Criar `Meta.php` (Model), `MetaRepository.php`, `MetaService.php` e `MetaController.php`.
  * **Ação:** Implementar views para cadastro, edição e listagem.
  * **Ação:** Garantir no Service que a `data_limite` seja obrigatoriamente posterior à data atual (RN08).
* **Completar CRUDs Financeiros:** Os `TransacaoController` e `ParcelaController` atuais possuem apenas rotas de criação.
  * **Ação:** Implementar os métodos e views para **edição** e **exclusão** de transações financeiras e parcelamentos.
  * **Ação:** Garantir validação estrita (RN05) onde todo valor de transação deve ser estritamente maior que zero.

### Fase 3: Painel Administrativo e Controle
* **Módulo Admin (RF02, RF05):** O sistema precisa de gestão ativa.
  * **Ação:** Criar `AdminController.php` (protegido por `adminRequired()`).
  * **Ação:** Construir dashboard administrativo exibindo estatísticas: total de usuários, novos cadastros, total de transações.
  * **Ação:** Implementar lista de usuários com ações para edição de dados, bloqueio e desbloqueio de acesso.
  * **Ação:** Implementar RN09: O backend deve impedir a exclusão da conta de administrador logada se ela for a última conta admin ativa no banco de dados.

### Fase 4: Gamificação, Notificações e UI
* **Substituição de Mocks no Dashboard (RF07):**
  * **Ação:** Remover os dados estáticos ("hardcoded") do `DashboardController`. Substituí-los por queries reais utilizando os Repositories de Transações, Metas e Parcelas para alimentar os gráficos do front-end.
* **Evolução do Ranking (RN10):**
  * **Ação:** Expandir os métodos de ranking atuais para suportar filtros temporais (Ranking Mensal e Ranking Semanal) baseados no ganho de experiência no período.
* **Alertas de Categoria (RN12):**
  * **Ação:** Aprimorar o `CategoriaService`. Atualmente, ele alerta proximidade de limite (>80%). É necessário disparar um alerta visual ativo (toast notification ou banner na View) quando o gasto de uma categoria atingir 100% ou exceder o orçamento estipulado.
* **Modo Escuro/Claro (RNF08):**
  * **Ação:** Implementar variáveis CSS (CSS variables) e um script JavaScript para alternância de temas global (Light/Dark mode), armazenando a preferência do usuário em `localStorage` ou Cookie.
* **Aviso de Perda de Streak (RN03):**
  * **Ação:** Ao detectar que a sequência de acesso (streak) foi quebrada durante o processo de `registrarAcesso()`, o sistema deve retornar um alerta (flash message) informando o usuário sobre a quebra da sequência.
