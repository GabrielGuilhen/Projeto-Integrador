# Documentação Técnica — DFLG Investments

Este documento tem dois objetivos: (1) registrar, em detalhe, o problema de deploy no Linux que foi diagnosticado e corrigido, e (2) explicar arquivo por arquivo como o projeto funciona por dentro — de onde vêm as classes, o que cada função faz, como uma requisição HTTP vira uma tela na sua frente.

---

## Parte 1 — O problema de deploy no Linux

### Resumo rápido

| Sintoma | Causa raiz | Onde foi corrigido |
|---|---|---|
| `localhost/` não abria nenhuma tela | `DocumentRoot` do Apache apontava para `/var/www/html`, e não para `.../DFLG/public`, e o roteador da aplicação não sabia descontar o caminho da subpasta da URI | `app/core/Router.php` (`run()`) + `.htaccess` na raiz do projeto |
| Links internos quebrados / porta errada | `URL_BASE` estava fixo em `http://localhost:8080`, porta que pertencia a um container Docker do usuário, sem relação com o projeto | `app/config/Config.php` |
| `localhost/login` retornava a página 404 **do próprio Apache** (não da aplicação) | Não existia `.htaccess` em `public/` mandando as requisições para `index.php`, então o Apache procurava um arquivo físico chamado `login` e não achava | `public/.htaccess` (novo arquivo) + `sudo a2enmod rewrite` |
| `.htaccess` era ignorado mesmo existindo | O Apache do Ubuntu vem com `AllowOverride None` por padrão para `/var/www/` — diferente do XAMPP, que já libera isso | `/etc/apache2/apache2.conf` (via `<Directory>` na vhost) |
| `SQLSTATE[HY000] [1698] Access denied for user 'root'@'localhost'` | O MySQL do Ubuntu configura `root@localhost` para autenticar só via `auth_socket` (usuário do sistema operacional), não aceitando usuário/senha mesmo com senha em branco | `ALTER USER 'root'@'localhost' IDENTIFIED WITH caching_sha2_password BY '';` |

Nenhum desses problemas era falta de programa instalado. Antes de qualquer correção, foi confirmado por linha de comando que Apache 2.4.66, PHP 8.5.4 (com `mod_php` ativo) e MySQL 8.4.10 já estavam instalados e rodando normalmente. Eram 100% problemas de **configuração/deploy**, não de pacotes ausentes nem de bug no código PHP do projeto.

**Importante:** a causa raiz do primeiro sintoma foi corrigida em **duas etapas diferentes**, com duas soluções diferentes — primeiro a Opção B, depois trocada pela Opção A. As duas estão documentadas em detalhe logo abaixo, porque a segunda troca é justamente o que faz o projeto rodar em qualquer PC (Linux ou Windows, seu ou dos colegas) sem precisar editar configuração do Apache em cada máquina.

### Por que funcionava direto no Windows/XAMPP e não no Linux

No XAMPP do Windows, o conteúdo da pasta `public/` do projeto era copiado manualmente para dentro do `htdocs` do XAMPP. Ou seja, sem perceber, essa cópia manual já fazia a única coisa que realmente importa: fazia com que a **pasta raiz que o servidor web enxerga** fosse exatamente a pasta `public/` do projeto. No Linux — tanto na sua máquina quanto na dos colegas que usam Linux nativo — essa etapa nunca tinha sido feita: o Apache continuava apontando para a pasta padrão `/var/www/html`, com o projeto real "enterrado" três níveis abaixo dela (`/var/www/html/DFLG_V1/DFLG/public`). Por isso o problema era idêntico em qualquer Linux, independente do dono da máquina — não é uma peculiaridade do seu computador.

### Causa raiz 1 — `DocumentRoot` errado e roteador sem suporte a subpasta

O roteador do projeto (`app/core/Router.php`) decide qual tela mostrar comparando a URL da requisição **exatamente** (`==`) com uma lista de rotas cadastradas, como `/`, `/dashboard`, `/login`:

```php
public function run()
{
    $uri  = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    $method = strtolower($_SERVER['REQUEST_METHOD']);

    foreach ($this->routes as $route) {
        if ($route['route'] == $uri && $route['method'] == $method) {
            return $this->dispatch($route);
        }
    }

    http_response_code(404);
    exit('Rota não encontrada');
}
```

Essa comparação **não desconta nenhum prefixo de subpasta**. Enquanto o `DocumentRoot` do Apache apontava para `/var/www/html`, acessar `http://localhost/DFLG_V1/DFLG/public/` fazia `$_SERVER['REQUEST_URI']` chegar como `/DFLG_V1/DFLG/public/` — string que nunca é igual a `/`, então a rota nunca batia e a aplicação sempre respondia "Rota não encontrada".

Existiam duas soluções possíveis, e o material de apoio do professor (`exemplo/projeto_integrador-main/COMO_USAR_APACHE.md`) já documentava uma delas:

- **Opção A — ensinar o roteador a rodar em subpasta.** Reescrever o método `run()` para descobrir e remover o prefixo da subpasta usando `$_SERVER['SCRIPT_NAME']`, mais um `.htaccess` na raiz do projeto redirecionando tudo para `public/`. É a solução que o guia do exemplo ensina, pensada para o projeto conviver com outros projetos dentro do mesmo `htdocs`, em qualquer máquina, sem mexer na configuração do Apache.
- **Opção B — fazer o Apache apontar direto para `public/`.** Sem tocar em uma linha do `Router.php` já entregue, configurar o próprio servidor web (`DocumentRoot` da vhost) para tratar `.../DFLG/public` como a raiz do site.

#### Primeira tentativa: Opção B

A primeira correção aplicada foi a **opção B**, por ser mais rápida e não exigir alterar código que já tinha sido desenvolvido (e possivelmente já avaliado):

```apache
<VirtualHost *:80>
    ServerAdmin webmaster@localhost
    DocumentRoot /var/www/html/DFLG_V1/DFLG/public

    <Directory /var/www/html/DFLG_V1/DFLG/public>
        AllowOverride All
        Require all granted
    </Directory>

    ErrorLog ${APACHE_LOG_DIR}/error.log
    CustomLog ${APACHE_LOG_DIR}/access.log combined
</VirtualHost>
```

Isso funcionou (`curl http://localhost/` passou a responder `200 OK`), e junto dessa mudança `URL_BASE` foi ajustado para `http://localhost` (porta 80, sem subpasta, já que o Apache passou a enxergar `public/` como a própria raiz).

**O problema dessa solução:** ela só funciona porque a `DocumentRoot` do Apache **daquela máquina específica** foi apontada manualmente para o caminho exato `.../DFLG_V1/DFLG/public`. Se um colega clonasse o projeto em outra pasta, ou se o próprio usuário movesse a pasta, seria preciso editar `/etc/apache2/sites-available/000-default.conf` de novo, à mão, em **cada computador**. Não resolve o objetivo de "rodar em qualquer PC" — só resolve "rodar nesta máquina, neste caminho".

#### Solução final: trocado para a Opção A

Por isso a correção foi refeita usando a **opção A** — a mesma que o guia do professor ensina — que deixa o próprio projeto (código + dois arquivos `.htaccess` versionados junto com ele) descobrir sozinho em que subpasta está rodando, sem precisar de nenhuma configuração de Apache específica para este projeto. A `DocumentRoot` da vhost volta a ser a genérica `/var/www/html` (a mesma para qualquer projeto que alguém colocar ali), e três coisas passam a fazer o trabalho:

**1. `app/core/Router.php`, método `run()`, reescrito para descontar a subpasta:**

```php
public function run()
{
    $uri  = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

    // Remove a pasta do projeto (caso esteja rodando em subpasta no Apache)
    $scriptDir = str_replace('/public', '', dirname($_SERVER['SCRIPT_NAME']));

    if ($scriptDir !== '/') {
        $uri = str_replace($scriptDir, '', $uri);
    }

    $uri = str_replace('/public', '', $uri);

    // Garante que a URI não fique vazia e comece com "/"
    if (empty($uri)) {
        $uri = '/';
    }
    if ($uri[0] !== '/') {
        $uri = '/' . $uri;
    }

    $method = strtolower($_SERVER['REQUEST_METHOD']);

    foreach ($this->routes as $route) {
        if ($route['route'] == $uri && $route['method'] == $method) {
            return $this->dispatch($route);
        }
    }

    http_response_code(404);
    exit('Rota não encontrada');
}
```

Linha a linha do trecho novo:
- `$_SERVER['SCRIPT_NAME']` é o caminho, relativo à raiz do domínio, do arquivo PHP que está de fato executando — nesse projeto, sempre `.../public/index.php` (ex.: `/DFLG_V1/DFLG/public/index.php`).
- `dirname($_SERVER['SCRIPT_NAME'])` pega só a pasta, descartando o `index.php`: `/DFLG_V1/DFLG/public`.
- `str_replace('/public', '', ...)` tira o `/public` do final, sobrando só o prefixo da subpasta do projeto: `/DFLG_V1/DFLG`. Esse é o `$scriptDir`.
- Se `$scriptDir` não for `/` (ou seja, se o projeto realmente estiver dentro de uma subpasta, e não direto na raiz do domínio), remove esse prefixo do início da URI pedida com `str_replace($scriptDir, '', $uri)`. Assim, `/DFLG_V1/DFLG/login` vira `/login` — a mesma string que está cadastrada nas rotas de `public/index.php`.
- `str_replace('/public', '', $uri)` é uma segunda limpeza, para o caso de alguém acessar incluindo `/public/` explicitamente na URL.
- Os dois `if` seguintes só garantem que, depois de toda essa limpeza, a URI nunca fique como string vazia (`''`) e sempre comece com `/` — sem isso, acessar exatamente a raiz do projeto quebraria a comparação com a rota `/`.
- Dali em diante, o `foreach` que compara rota por rota é **idêntico** ao original — a única mudança real foi preparar a `$uri` antes de comparar.

**2. `.htaccess` novo na raiz do projeto** (`/var/www/html/DFLG_V1/DFLG/.htaccess`, um nível **acima** de `public/`), redirecionando tudo pra dentro de `public/`:

```apache
RewriteEngine On

# Redireciona tudo de forma silenciosa para a pasta public/
RewriteRule ^$ public/ [L]
RewriteRule ^((?!public/).*)$ public/$1 [L]
```

- A primeira `RewriteRule` trata o caso de acessar a raiz do projeto sem nada depois (`^$` = string vazia): manda para `public/`.
- A segunda trata qualquer outro caminho: `^((?!public/).*)$` é uma expressão regular com **negative lookahead** (`(?!public/)`) — captura qualquer caminho que **não comece** com `public/` (evitando um loop infinito de redirecionamento caso o pedido já seja para dentro de `public/`) e reescreve prefixando `public/` na frente. Assim, `DFLG_V1/DFLG/login` vira, internamente, `DFLG_V1/DFLG/public/login`.
- Esse `.htaccess` só existe pra evitar precisar digitar `/public/` na URL. Sem ele, o site funcionaria do mesmo jeito acessando `http://localhost/DFLG_V1/DFLG/public/login`.

**3. `app/config/Config.php` — `URL_BASE` fixo, incluindo a subpasta:**

```php
define('URL_BASE', 'http://localhost/DFLG_V1/DFLG');
```

Essa parte **não foi automatizada** de propósito — é a mesma abordagem manual que o guia do professor ensina (o guia inclusive avisa: *"Abra o arquivo `app/config/Config.php` e altere a linha 18"*). Na prática isso significa que, se um colega clonar o projeto numa pasta com nome diferente (por exemplo, direto em `htdocs/DFLG` sem o `DFLG_V1` por cima), essa linha precisa ser ajustada manualmente por ele para bater com o caminho real. É a única parte da solução que continua "por máquina" — o roteador e os dois `.htaccess` já resolvem sozinhos.

**4. Apache: `DocumentRoot` volta a ser genérica, com `AllowOverride All` liberado**

```apache
<VirtualHost *:80>
    ServerAdmin webmaster@localhost
    DocumentRoot /var/www/html

    <Directory /var/www/html>
        AllowOverride All
        Require all granted
    </Directory>

    ErrorLog ${APACHE_LOG_DIR}/error.log
    CustomLog ${APACHE_LOG_DIR}/access.log combined
</VirtualHost>
```

Diferente da tentativa com a opção B, aqui a `DocumentRoot` **não** menciona nada específico do projeto DFLG — é a configuração padrão de qualquer instalação de Apache, a mesma que qualquer colega já tem (ou só precisa copiar uma vez). O que muda é o `AllowOverride All`: por padrão, o Ubuntu define `AllowOverride None` para `/var/www/` inteiro (em `/etc/apache2/apache2.conf`), o que faz o Apache **ignorar completamente** qualquer `.htaccess` que exista em qualquer subpasta — inclusive os dois `.htaccess` do passo 2 e da causa raiz 2 abaixo. Sem esse ajuste, os `.htaccess` do projeto (que viajam junto com o código, no Git) nunca teriam efeito. É justamente esse detalhe que o XAMPP já resolve por padrão (o `httpd.conf` dele já vem com `AllowOverride All` para o `htdocs`), e que o Apache "cru" do Ubuntu não resolve — por isso funcionava sem esse passo extra no Windows.

Com essas quatro mudanças, o projeto pode ser colocado em **qualquer subpasta**, dentro do `/var/www/html` de **qualquer máquina Linux**, e vai funcionar assim que o Apache tiver `mod_rewrite` ativo e `AllowOverride All` liberado uma única vez — sem precisar criar uma vhost nova nem editar `DocumentRoot` a cada clone. Só a linha do `URL_BASE` em `Config.php` precisa ser conferida/ajustada manualmente, igual o professor já orientava.

### Causa raiz 2 — Faltava o `.htaccess` de `public/` e o `mod_rewrite`

Depois da correção 1, `http://localhost/` (a rota `/`) já funcionava — porque `/` é o "índice" padrão de qualquer pasta e o Apache já sabe entregar `index.php` automaticamente nesse caso. Mas `http://localhost/login` continuava dando erro, só que agora era um 404 **do próprio Apache** (página HTML padrão "Not Found", com rodapé "Apache/2.4.66 (Ubuntu) Server"), bem diferente do 404 "Rota não encontrada" que é texto gerado pelo `Router.php`.

O motivo: sem instrução em contrário, o Apache trata cada segmento da URL como um caminho de arquivo real no disco. Para `/login`, ele procurava um arquivo ou pasta chamada `login` dentro de `public/` — que não existe — e desistia antes mesmo de o PHP ser executado. Ou seja, o roteador do PHP nunca chegava a rodar para essas rotas.

A correção é um arquivo `.htaccess` dentro de `public/`, dizendo ao Apache: "se o que foi pedido não é um arquivo real (`!-f`) nem uma pasta real (`!-d`), manda tudo para o `index.php` e deixa o roteador decidir":

```apache
RewriteEngine On

# Impede que quem acessa veja a lista de arquivos das pastas
Options -Indexes

RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^ index.php [QSA,L]
```

Linha a linha:
- `RewriteEngine On` — liga o motor de reescrita de URLs do `mod_rewrite` para esse diretório.
- `Options -Indexes` — desliga a listagem automática de arquivos que o Apache mostra quando alguém acessa uma pasta sem `index.php`/`index.html` dentro (por exemplo, `public/assets/`). Foi adicionado junto com a troca para a opção A, seguindo o mesmo `.htaccess` do guia do professor — evita que alguém veja a estrutura de pastas do projeto navegando direto pela URL.
- `RewriteCond %{REQUEST_FILENAME} !-f` — condição: só continua se o caminho pedido **não** for um arquivo existente (`-f` = "is file"; `!` nega).
- `RewriteCond %{REQUEST_FILENAME} !-d` — segunda condição, encadeada com a anterior: também não pode ser uma pasta existente (`-d` = "is directory"). Isso garante que pedidos por arquivos reais, como `assets/css/style.css`, continuem sendo servidos normalmente, sem passar pelo roteador.
- `RewriteRule ^ index.php [QSA,L]` — se as duas condições acima passaram, reescreve **qualquer** URL (`^` casa o início da string, sem mais nada depois, ou seja, casa qualquer coisa) para `index.php`. `QSA` (Query String Append) preserva os parâmetros de `?...` que vierem na URL original; `L` (Last) diz ao Apache para parar de processar outras regras depois desta.

Isso é equivalente — só que mais enxuto — ao `.htaccess` de `public/` documentado em `exemplo/projeto_integrador-main/COMO_USAR_APACHE.md`.

Só criar o arquivo não bastava: por padrão, no Apache do Ubuntu, o módulo `mod_rewrite` (responsável por interpretar `RewriteEngine`/`RewriteRule`) vem **desabilitado**. Sem ele ativo, todo o conteúdo do `.htaccess` acima é silenciosamente ignorado, mesmo com `AllowOverride All`. A correção final foi:

```bash
sudo a2enmod rewrite
sudo systemctl reload apache2
```

### Causa raiz 3 — MySQL recusando `root` sem senha

Depois das duas correções acima, a tela abria, mas a aplicação parava em:

```
Não foi possível acessar o banco: db_dflg_investments
O erro foi: SQLSTATE[HY000] [1698] Access denied for user 'root'@'localhost'
```

`app/config/Config.php` define `DB_USER = 'root'` e `DB_PASS = ''` (senha em branco) — configuração idêntica à que o XAMPP libera por padrão. O que muda é que o **MySQL instalado via `apt` no Ubuntu** configura a conta `root@localhost` para autenticar exclusivamente pelo plugin `auth_socket`: ele verifica se quem está conectando é o próprio usuário `root` do sistema operacional (via socket Unix), e simplesmente ignora qualquer usuário/senha enviados por uma aplicação como o PHP — por isso o erro aparece mesmo com a senha certa (em branco). Isso não tem relação com o Linux "estar quebrado"; é uma política de segurança padrão desse pacote específico, mais restritiva que a do MySQL empacotado dentro do XAMPP.

Correção, trocando o método de autenticação do `root@localhost` para aceitar usuário/senha (como o restante do projeto espera):

```bash
sudo mysql -e "ALTER USER 'root'@'localhost' IDENTIFIED WITH caching_sha2_password BY ''; FLUSH PRIVILEGES;"
```

Esse comando só funciona rodado com `sudo` porque, ironicamente, é o próprio `auth_socket` que autentica o `sudo mysql` como sendo o usuário `root` do sistema — o mesmo mecanismo que estava bloqueando o PHP é o que autoriza essa alteração.

Depois disso, o próprio código do projeto (ver `ConnectionFactory.php` e `DatabaseInitializer.php` na Parte 2) consegue criar sozinho o banco `db_dflg_investments`, as tabelas e os dados iniciais na primeira conexão bem-sucedida — não é necessário importar `script.sql` manualmente.

---

## Parte 2 — Como o projeto funciona, arquivo por arquivo

### Visão geral da estrutura

```
DFLG/
├── .htaccess                      → redireciona tudo (menos public/) para dentro de public/
├── app/
│   ├── config/Config.php          → constantes globais (URL_BASE, banco, ambiente)
│   ├── core/                      → o "framework" caseiro: Autoload, Router, Controller
│   ├── database/                  → conexão PDO + criação automática do schema
│   ├── helpers/Validador.php      → validação simples de campos obrigatórios
│   ├── models/                    → classes de entidade (dados + regras simples)
│   ├── repositories/              → toda a camada que fala SQL com o banco
│   ├── services/                  → regras de negócio, chamadas pelos controllers
│   ├── controllers/               → recebem a requisição, chamam services, escolhem a view
│   └── views/                     → HTML + PHP que é efetivamente exibido
├── public/
│   ├── index.php                  → único ponto de entrada de toda requisição HTTP
│   ├── .htaccess                  → manda tudo (exceto arquivos reais) para index.php
│   └── assets/css/style.css       → (vazio atualmente; o CSS está inline nas views)
└── exemplo/                       → template original do professor, mantido como referência
```

O padrão é uma arquitetura em camadas conhecida como **MVC + Service + Repository**:

```
Requisição HTTP
   → public/index.php (registra rotas)
      → Router (decide qual Controller/método chamar)
         → Controller (lê $_POST/$_GET, valida entrada simples, decide o fluxo)
            → Service (aplica regras de negócio)
               → Repository (executa SQL via PDO)
                  → Model (representa uma linha do banco como objeto PHP)
            ← Controller escolhe uma View e passa dados pra ela
         ← Router devolve o HTML gerado
```

### `app/core/Autoload.php` — carregando classes automaticamente

```php
spl_autoload_register(function ($class) {

    $prefix = 'app\\';
    $baseDir = __DIR__ . '/../';

    if (str_starts_with($class, $prefix)) {

        $path = substr($class, strlen($prefix));
        $classFile = $baseDir . str_replace('\\', '/', $path) . '.php';

        if (file_exists($classFile)) {
            require_once $classFile;
        }
    } else {
        throw new Exception("A classe {$class} não pode ser carregada");
    }
});
```

`spl_autoload_register()` é uma função nativa do PHP: registra uma função de callback que o PHP chama automaticamente sempre que o código tenta usar uma classe (`new AlgumaClasse` ou `use app\...\AlgumaClasse`) que ainda não foi carregada com `require`/`include`. Isso evita que cada arquivo precise de uma lista manual de `require` no topo — é assim que, por exemplo, o `MetaController` consegue simplesmente escrever `use app\services\MetaService;` sem nenhum `require_once` explícito para esse arquivo.

Passo a passo da função:
1. `$prefix = 'app\\'` — todas as classes do projeto usam o namespace raiz `app`.
2. `$baseDir = __DIR__ . '/../'` — `__DIR__` é a pasta onde o `Autoload.php` está (`app/core`), então `baseDir` sobe um nível e vira `app/`.
3. `str_starts_with($class, $prefix)` — só tenta carregar classes que comecem com `app\`; qualquer outra (como classes nativas do PHP, `PDO`, `Exception`, `DateTimeImmutable`) é ignorada aqui e resolvida pelo próprio PHP.
4. `substr($class, strlen($prefix))` — remove o prefixo `app\` do nome completo da classe. Por exemplo, `app\controllers\MetaController` vira `controllers\MetaController`.
5. `str_replace('\\', '/', $path)` — troca as barras de namespace (`\`) por barras de caminho de arquivo (`/`), respeitando a convenção **PSR-4** simplificada: o namespace espelha exatamente a estrutura de pastas. `controllers\MetaController` vira `controllers/MetaController`, e com `.php` no final e `$baseDir` na frente, dá `app/controllers/MetaController.php`.
6. Se o arquivo existir, `require_once` carrega a classe.

Se a classe não começar com `app\`, a função lança uma `Exception` — o que, no fundo, só deveria acontecer se algum outro autoloader (do PHP nativo, por exemplo) já não tiver resolvido a classe antes.

### `app/core/Router.php` — o roteador

Guarda as rotas registradas em um array (`$routes`) e resolve qual delas atender.

```php
public function get($route, $action){
    $this->routes[] = ['method' => 'get', 'route' => $route, 'action' => $action];
}

public function post($route, $action){
    $this->routes[] = ['method' => 'post', 'route' => $route, 'action' => $action];
}
```

`get()` e `post()` não fazem nenhuma mágica: apenas empilham no array `$routes` um registro com três informações — o verbo HTTP, o caminho da URL, e uma string de "ação" no formato `"Controller@metodo"` (por exemplo `'DashboardController@index'`). São chamados em `public/index.php`, uma vez para cada rota da aplicação.

```php
public function run()
{
    $uri  = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

    // Remove a pasta do projeto (caso esteja rodando em subpasta no Apache)
    $scriptDir = str_replace('/public', '', dirname($_SERVER['SCRIPT_NAME']));

    if ($scriptDir !== '/') {
        $uri = str_replace($scriptDir, '', $uri);
    }

    $uri = str_replace('/public', '', $uri);

    // Garante que a URI não fique vazia e comece com "/"
    if (empty($uri)) {
        $uri = '/';
    }
    if ($uri[0] !== '/') {
        $uri = '/' . $uri;
    }

    $method = strtolower($_SERVER['REQUEST_METHOD']);

    foreach ($this->routes as $route) {
        if ($route['route'] == $uri && $route['method'] == $method) {
            return $this->dispatch($route);
        }
    }

    http_response_code(404);
    exit('Rota não encontrada');
}
```

- `$_SERVER['REQUEST_URI']` é uma variável superglobal do PHP preenchida pelo servidor web com o caminho exato que o navegador pediu (ex.: `/DFLG_V1/DFLG/metas/editar?id=3`).
- `parse_url(..., PHP_URL_PATH)` extrai só a parte do caminho, descartando a query string — então `.../metas/editar?id=3` vira `.../metas/editar` para fins de comparação (o `id=3` continua acessível depois, via `$_GET['id']`, dentro do controller).
- O bloco `$scriptDir = str_replace('/public', '', dirname($_SERVER['SCRIPT_NAME']))` até o segundo `if` é a parte que foi **adicionada** na correção do deploy (ver Parte 1, "Solução final: trocado para a Opção A") — descobre em qual subpasta o projeto está instalado nesta máquina e remove esse prefixo da URI antes de comparar com as rotas cadastradas. Sem isso, o roteador só funcionava se o projeto estivesse na raiz exata do domínio.
- `strtolower($_SERVER['REQUEST_METHOD'])` pega o verbo HTTP (`GET`, `POST`) e normaliza para minúsculo, pra bater com o que foi armazenado por `get()`/`post()`.
- O `foreach` percorre as rotas registradas em ordem e compara **ambos** rota e método com `==`; a primeira que bater dispara `dispatch()`.
- Se nenhuma rota bater, responde HTTP 404 e imprime `'Rota não encontrada'` — este é o 404 gerado pela própria aplicação PHP, diferente do 404 do Apache mencionado na Parte 1.

```php
public function dispatch($route){
    list($controller, $method) = explode('@', $route['action']);
    $controllerClass = "app\\controllers\\$controller";

    if (!class_exists($controllerClass)) {
        print "Controller $controller não encontrado";
        die;
    }
    if (!method_exists($controllerClass, $method)) {
        print "Método $method não encontrado em $controllerClass";
        die;
    }

    $controller = new $controllerClass;
    $controller->$method();
}
```

- `explode('@', 'MetaController@salvar')` separa a string da ação em duas partes: `['MetaController', 'salvar']`.
- `$controllerClass = "app\\controllers\\$controller"` monta dinamicamente o nome completo da classe, incluindo namespace: `app\controllers\MetaController`.
- `class_exists()` e `method_exists()` são funções do PHP que checam, em tempo de execução, se aquela classe/método realmente existem — é aqui que o `Autoload.php` entra em ação: ao chamar `class_exists()` com uma classe ainda não carregada, o PHP aciona o autoloader registrado, que localiza e faz `require_once` do arquivo correspondente.
- `new $controllerClass` — instancia a classe usando o nome guardado em uma variável (chamado de "instanciação dinâmica"); isso dispara o `__construct()` de cada controller, que tipicamente já cria os Services que ele vai usar.
- `$controller->$method()` — chama o método também dinamicamente, usando o nome guardado em `$method`.

### `app/core/Controller.php` — classe-base de todos os controllers

```php
class Controller
{
    public function view(string $view, ?array $data = null)
    {
        if ($data) {
            extract($data);
        }

        $path = __DIR__ . "/../views/$view.php";

        if (file_exists($path)) {
            require_once $path;
        } else {
            print 'A view solicitada não foi encontrada: ' . $view;
        }
    }

    public function redirect(string $url)
    {
        header('location: ' . $url);
        exit();
    }

    public function autenticacaoRequired()
    {
        if (!isset($_SESSION['usuario_logado'])) {
            $this->redirect(URL_BASE . '/login');
        }
        return true;
    }

    public function adminRequired()
    {
        if (!isset($_SESSION['usuario_logado']) || $_SESSION['usuario_logado']->getPerfil() !== 'administrador') {
            $this->redirect(URL_BASE . '/login');
        }
        return true;
    }

    public function getUsuarioLogadoId(): int
    {
        return $_SESSION['usuario_logado']->getId();
    }
}
```

Todo controller do projeto (`AutenticacaoController`, `DashboardController`, `MetaController`, `TransacaoController`, `ParcelaController`) estende (`extends Controller`) esta classe e herda cinco comportamentos prontos:

- **`view($view, $data)`** — renderiza um arquivo PHP de `app/views/`. `$view` é um caminho relativo sem `.php`, como `'metas/metas_list'`, que vira `app/views/metas/metas_list.php`. O truque central é `extract($data)`: essa função nativa do PHP pega um array associativo e cria, no escopo atual, uma variável para cada chave — por exemplo, `extract(['lista' => $metas])` cria uma variável `$lista` contendo `$metas`. Como isso acontece **antes** do `require_once $path`, e o `require_once` roda no mesmo escopo da função, a view incluída em seguida já enxerga `$lista` como se tivesse sido declarada ali dentro. É assim que `metas_list.php` consegue simplesmente escrever `foreach ($lista as $meta)` sem receber nenhum parâmetro explícito.
- **`redirect($url)`** — envia o cabeçalho HTTP `Location` (redirecionamento) e encerra a execução com `exit()`, para garantir que nenhum HTML seja impresso depois do redirect.
- **`autenticacaoRequired()`** — trava de acesso simples: se não existir `$_SESSION['usuario_logado']`, redireciona para `/login` antes que o controller continue. É chamado como primeira linha de quase todo método de `DashboardController`, `MetaController`, `TransacaoController` e `ParcelaController`.
- **`adminRequired()`** — variante mais restritiva, também exige que o perfil do usuário logado seja `'administrador'`. (Não é usado em nenhum controller atual do projeto — está disponível para uso futuro.)
- **`getUsuarioLogadoId()`** — atalho para pegar o ID do usuário da sessão, evitando repetir `$_SESSION['usuario_logado']->getId()` em cada método.

### `public/index.php` — o único ponto de entrada

```php
require_once __DIR__ . '/../app/core/Autoload.php';
require_once __DIR__ . '/../app/config/Config.php';

use app\core\Router;

$router = new Router();

$router->get('/', 'DashboardController@index');
$router->get('/dashboard', 'DashboardController@index');
// ... (mais rotas)
$router->run();
```

A ordem dos dois `require_once` importa: o `Autoload.php` precisa ser carregado **primeiro** porque, mesmo sem ainda ter nenhuma classe do projeto em uso, ele é quem registra a função capaz de carregar `Router` (`use app\core\Router;` mais abaixo) e todas as outras classes que serão usadas durante a requisição. Só depois vem `Config.php`, que define constantes globais como `URL_BASE` e as credenciais do banco — necessárias antes de qualquer controller rodar.

`$router = new Router()` cria uma instância vazia do roteador. Cada chamada `$router->get(...)`/`$router->post(...)` que vem em seguida apenas empilha uma rota (ver `Router::get()`/`post()` acima) — nada é executado ainda. Mapa completo das rotas registradas:

| Rota | Verbo | Controller@método | Tela/ação |
|---|---|---|---|
| `/` e `/dashboard` | GET | `DashboardController@index` | Painel principal |
| `/login` | GET | `AutenticacaoController@login` | Formulário de login |
| `/logar` | POST | `AutenticacaoController@logar` | Processa o login |
| `/logout` | GET | `AutenticacaoController@logout` | Encerra a sessão |
| `/cadastrar` | GET | `AutenticacaoController@cadastrar` | Formulário de cadastro |
| `/cadastrar/salvar` | POST | `AutenticacaoController@salvar` | Processa o cadastro |
| `/metas` | GET | `MetaController@listarTodas` | Lista de metas |
| `/metas/cadastrar` | GET | `MetaController@criar` | Formulário de nova meta |
| `/metas/salvar` | POST | `MetaController@salvar` | Grava nova meta |
| `/metas/editar` | GET | `MetaController@editar` | Formulário de edição |
| `/metas/atualizar` | POST | `MetaController@atualizar` | Grava edição |
| `/metas/excluir` | GET | `MetaController@excluir` | Remove meta |
| `/transacoes...` | GET/POST | `TransacaoController@...` | Mesmo padrão acima, para transações |
| `/parcelamentos...` | GET/POST | `ParcelaController@...` | Mesmo padrão acima, para parcelamentos |

Só a última linha, `$router->run()`, efetivamente processa a requisição atual: lê `REQUEST_URI`/`REQUEST_METHOD`, compara com a lista montada acima, e dispara o controller correspondente (ver seção do `Router.php`).

### `app/config/Config.php` — configuração global

```php
define('DEV_ENVIRONMENT', true);

if (DEV_ENVIRONMENT == true) {
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

define('APP_NAME', 'DFLG Investments');
define('URL_BASE', 'http://localhost/DFLG_V1/DFLG');

define('DB_HOST', 'localhost');
define('DB_NAME', 'db_dflg_investments');
define('DB_USER', 'root');
define('DB_PASS', '');
```

- `define('DEV_ENVIRONMENT', true)` cria uma constante global (diferente de variável, não pode ser reatribuída depois). Sendo `true`, o bloco seguinte ativa `display_errors`/`display_startup_errors` (mostra erros do PHP direto na tela em vez de só no log) e `error_reporting(E_ALL)` (reporta absolutamente todo tipo de erro/aviso/notice) — configuração típica de ambiente de desenvolvimento, que em produção normalmente seria desligada.
- `session_status() === PHP_SESSION_NONE` verifica se ainda não existe uma sessão PHP ativa antes de chamar `session_start()`. Isso é necessário porque `Config.php` é incluído uma vez por requisição a partir de `public/index.php`; sem essa checagem, uma segunda chamada a `session_start()` na mesma requisição geraria um warning ("session already started"). É graças a essa sessão que `$_SESSION['usuario_logado']`, usado em `Controller::autenticacaoRequired()` e em vários controllers, funciona.
- `URL_BASE` — endereço base usado em todo o projeto (controllers, ao montar redirects; views, ao montar `href` de links e `action` de formulários). Inclui o caminho da subpasta onde o projeto está instalado (`/DFLG_V1/DFLG`) — é a única parte da correção da Parte 1 que precisa ser conferida manualmente em cada máquina/clone, igual explicado lá.
- `DB_HOST`, `DB_NAME`, `DB_USER`, `DB_PASS` — usados exclusivamente por `ConnectionFactory::createConnection()` para montar a string de conexão PDO.

### `app/database/ConnectionFactory.php` — conexão com o banco

```php
class ConnectionFactory {
    private static ?PDO $connection = null;

    public static function getConnection(){
        if (self::$connection == null) {
            try {
                $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME;
                self::$connection = self::createConnection($dsn);
            } catch(Exception $e){
                print("Não foi possível acessar o banco:  " . DB_NAME);
                print("<br>O erro foi: ". $e->getMessage());
                print("<br>Tentando inicializar o banco de dados...");

                $dsn = "mysql:host=" . DB_HOST;
                self::$connection = self::createConnection($dsn);

                $databaseInit = new DatabaseInitializer();
                $databaseInit->init(self::$connection);

                $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME;
                self::$connection = self::createConnection($dsn);
            }
        }
        return self::$connection;
    }

    private static function createConnection(string $dsn){
        $connection = new PDO($dsn, DB_USER, DB_PASS);
        $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $connection->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        return $connection;
    }
}
```

Implementa dois padrões de projeto conhecidos ao mesmo tempo:
- **Factory** — `createConnection()` centraliza a criação de um objeto `PDO` configurado (modo de erro `ERRMODE_EXCEPTION`, que faz qualquer erro de SQL virar uma exceção PHP em vez de um retorno silencioso; modo de fetch padrão `FETCH_ASSOC`, que faz todo `fetch()`/`fetchAll()` devolver arrays associativos com o nome das colunas como chave).
- **Singleton estático** — `private static ?PDO $connection = null` guarda a conexão em uma propriedade estática (compartilhada por todas as instâncias/chamadas da classe, não por objeto). `getConnection()` só cria uma conexão nova se `$connection` ainda for `null`; nas chamadas seguintes (de qualquer Repository, na mesma requisição), devolve a mesma conexão já aberta, evitando reconectar ao banco a cada consulta.

O `try/catch` implementa uma auto-inicialização: na primeira vez que o banco `db_dflg_investments` ainda não existe, a primeira tentativa de conexão (com `dbname=` no DSN) falha e cai no `catch`. Ali, ele abre uma segunda conexão **sem** especificar banco (só `host=`, que sempre existe), usa essa conexão para instanciar `DatabaseInitializer` e chamar `init()` (que cria o banco e as tabelas — ver próxima seção), e por fim tenta a conexão original mais uma vez, agora com sucesso porque o banco já existe. Foi exatamente esse fluxo que a Causa raiz 3 (Parte 1) impedia de completar: sem conseguir sequer autenticar como `root`, nem a primeira nem a segunda tentativa de `createConnection()` funcionavam.

### `app/database/DatabaseInitializer.php` — criação automática do schema

```php
public function init(PDO $connection)
{
    $connection->exec("CREATE DATABASE IF NOT EXISTS " . DB_NAME);
    $connection->exec("USE " . DB_NAME);

    $scriptPath = __DIR__ . '/scripts/script.sql';

    if (file_exists($scriptPath)) {
        $sql = file_get_contents($scriptPath);
        try {
            $connection->exec($sql);
        } catch (\Exception $e) {
            error_log("Erro ao inicializar banco de dados: " . $e->getMessage());
        }
    }
}
```

Recebe a conexão (sem banco selecionado) vinda de `ConnectionFactory`, cria o banco com `CREATE DATABASE IF NOT EXISTS`, seleciona esse banco com `USE`, lê o arquivo `app/database/scripts/script.sql` inteiro como texto (`file_get_contents`) e executa tudo de uma vez com `exec()`. Qualquer erro na execução do SQL é só registrado no log de erros do servidor (`error_log`), sem interromper a aplicação.

**`script.sql` (91 linhas) cria seis tabelas:**

| Tabela | Principais colunas | Relações |
|---|---|---|
| `usuarios` | nome, nickname (único), email (único), senha (hash), data_nascimento, status, perfil | — |
| `usuario_comum` | usuario_id, xp_total, nivel, streak_atual, maior_streak, data_ultimo_xp, visibilidade_ranking | 1:1 com `usuarios`, `ON DELETE CASCADE` |
| `categorias` | nome, icone, tipo (receita/despesa), limite_orcamento | — |
| `metas` | usuario_id, nome_meta, tipo_meta, valor_alvo, valor_atual, data_limite | N:1 com `usuarios`, `ON DELETE CASCADE` |
| `registro_financeiro` | usuario_id, categoria_id, tipo, valor, data_registro, descricao | N:1 com `usuarios` e `categorias` |
| `parcelamentos` | usuario_id, categoria_id, descricao, valor_total, quantidade_parcelas, parcelas_pagas, data_primeira_parcela | N:1 com `usuarios` e `categorias` |

O script também insere dados iniciais: um usuário administrador (`admin@dflg.com`, senha já com hash bcrypt, correspondente a `admin123`) e 13 categorias padrão (4 de receita, 9 de despesa).

### `app/helpers/Validador.php` — validação de campos obrigatórios

```php
class Validador {
    private array $erros = [];

    public function obrigatorio(string $campo, mixed $valor, ?string $mensagem = null) {
        if (empty($valor) && $valor !== '0') {
            $this->erros[$campo] = $mensagem ?? "O campo {$campo} é obrigatório";
        }
        return $this;
    }

    public function temErros(): bool {
        return !empty($this->erros);
    }

    public function getErros(){
        return $this->erros;
    }
}
```

Classe simples, sem regras de negócio de domínio (essas ficam nos Services — ver adiante). `obrigatorio()` verifica se um valor está "vazio" (`empty()`, que trata `''`, `null`, `0`, `false` e arrays vazios como vazios) — com uma ressalva explícita: `$valor !== '0'`, para que o texto `"0"` (por exemplo, um valor numérico legítimo digitado como zero) **não** seja tratado como campo vazio. O `return $this` no final permite encadear chamadas (`$validador->obrigatorio(...)->obrigatorio(...)`), técnica chamada de *fluent interface*. Os controllers chamam `obrigatorio()` uma vez para cada campo do formulário e depois checam `temErros()`/`getErros()` para decidir se re-exibem o formulário com mensagens de erro ou seguem em frente.

### Controllers (`app/controllers/`)

Todos seguem o mesmo formato: `__construct()` instancia os Services que vão usar; cada método público corresponde a uma rota do `public/index.php`; a maioria das ações protegidas começa chamando `$this->autenticacaoRequired()`.

**`AutenticacaoController`** — cadastro/login/logout.
- `login()` — apenas exibe a view `autenticacao/login`.
- `logar()` — lê `email`/`senha` de `$_POST`, delega a `AutenticacaoService::logar()`; se autenticar, redireciona para `/dashboard`; senão, reexibe o login com `erros`.
- `logout()` — chama `AutenticacaoService::logout()` e redireciona para `/login`.
- `cadastrar()` — exibe a view `autenticacao/cadastro`.
- `salvar()` — valida os campos do formulário com `Validador`, monta um objeto `Usuario` (sempre com perfil fixo `'comum'` — comentário no código chama isso de **RN01**, regra de negócio que garante que ninguém vira administrador só preenchendo o cadastro público) e chama `UsuarioService::cadastrar()`. Em caso de e-mail/nickname duplicado, reexibe o formulário com erro.

  No exemplo original (`exemplo/.../AutenticacaoController.php`), esse controller só tinha `login()` e `logar()`, sem cadastro público nem `UsuarioService` — o fluxo de cadastro de usuário comum foi construído do zero no projeto do aluno.

**`DashboardController`** — painel inicial.
- `index()` — exige login, pega o usuário da sessão, busca dados de gamificação via `GamificacaoService::getGamificacao()` e renderiza `dashboard/dashboard` passando `usuario` e `gamificacao`.

**`MetaController`** — CRUD de metas financeiras.
- `listarTodas()` — lista as metas do usuário logado.
- `criar()` — exibe formulário de nova meta.
- `salvar()` — valida (`nomeMeta`, `valorAlvo`, `dataLimite` obrigatórios), monta um `Meta` e chama `MetaService::saveMeta()`; em caso de erro de validação de negócio (ex.: data no passado), reaproveita `MetaService::getErros()`.
- `editar()` — busca a meta pelo `id` da query string, garantindo que pertence ao usuário logado.
- `atualizar()` — mesma validação de `salvar()`, mas chama `MetaService::updateMeta()`.
- `excluir()` — remove a meta pelo `id`, sempre restrito ao usuário logado.

**`TransacaoController`** — CRUD de receitas/despesas.
- `listarTodas()` — além de listar, lê filtros opcionais `tipo` e `categoriaId` de `$_GET`, e calcula `totalReceitas`, `totalDespesas` e `saldo` via `TransacaoService` para exibir no topo da tela.
- `criar()`/`salvar()`/`editar()`/`atualizar()`/`excluir()` — mesmo padrão de `MetaController`, mas para o model `Transacao`, sempre carregando também a lista de categorias (`CategoriaService::getCategorias()`) para popular o `<select>` do formulário.

**`ParcelaController`** — CRUD de compras parceladas/dívidas.
- Mesmo padrão dos dois anteriores, operando sobre o model `Parcelamento`, também com categorias associadas.

### Services (`app/services/`)

Camada que concentra regras de negócio — o que pode/não pode acontecer — mantendo os controllers enxutos (só orquestração de entrada/saída) e os repositories sem lógica além de SQL.

- **`AutenticacaoService`** — `logar($email, $senha)` busca o usuário pelo e-mail via `UsuarioRepository` e confere a senha com `password_verify()` (comparação segura contra hash bcrypt); se bater, grava o objeto `Usuario` inteiro em `$_SESSION['usuario_logado']`. `logout()` chama `session_destroy()`.
- **`CategoriaService`** — camada fina sobre `CategoriaRepository`: `getCategorias()`, `getCategoria($id)`, e `existeCategoria($id)` (usado por `TransacaoService::validar()` para checar se o `categoriaId` enviado é válido).
- **`GamificacaoService`** — **não existe no projeto de exemplo**; é uma funcionalidade construída do zero. `adicionarPontos($usuarioId, $pontos = 10)` implementa a regra comentada no código como **RN07**: XP só pode ser concedido uma vez por dia, comparando a data de hoje (`DateTimeImmutable`) com a coluna `data_ultimo_xp`; se já ganhou XP hoje, não soma de novo. Quando concede, recalcula o nível com `intdiv($xpTotal, 100) + 1` (a cada 100 XP, sobe um nível) e persiste via `UsuarioComumRepository::atualizarXp()`. `getGamificacao($usuarioId)` só repassa a consulta para o repository, usado pelo `DashboardController`.
- **`MetaService`** — `saveMeta()`/`updateMeta()` chamam `validar()` antes de gravar (regra **RN08** no comentário: a data limite precisa ser posterior a hoje, e o valor alvo maior que zero); `updateMeta()` também confere que a meta pertence ao usuário antes de deixar atualizar. Erros ficam acumulados em `$erros` e expostos via `getErros()` para o controller reexibir no formulário.
- **`ParcelamentoService`** — mesma estrutura de `MetaService`; regra **RN05**: valor total maior que zero, ao menos uma parcela, e parcelas pagas nunca podem ultrapassar o total contratado.
- **`TransacaoService`** — além do CRUD com validação (**RN05/RN06**: valor maior que zero, tipo precisa ser `receita` ou `despesa`, categoria obrigatória e existente), é o único Service que depende de outro Service (`CategoriaService`, para validar `categoriaId`, e `GamificacaoService`): toda vez que uma transação é salva com sucesso, `saveTransacao()` chama `GamificacaoService::adicionarPontos()` — é a ponte entre "registrar uma finança" e "ganhar XP no dashboard". Também expõe `getTotalReceitas()`, `getTotalDespesas()` e `getSaldo()`, usados no resumo da tela de transações.
- **`UsuarioService`** — `cadastrar()` implementa **RN02/RF01** (e-mail e nickname precisam ser únicos, checados via `UsuarioRepository` antes de inserir) e, ao criar um usuário com sucesso, também cria a linha correspondente em `usuario_comum` via `UsuarioComumRepository::criarParaUsuario()` — é assim que todo novo cadastro já nasce com XP zerado e nível 1.

### Repositories (`app/repositories/`)

Cada Repository isola completamente o SQL de uma tabela (padrão **Repository**), sempre recebendo a conexão via `ConnectionFactory::getConnection()` no construtor e usando **prepared statements** do PDO (`prepare()` + `bindValue()` + `execute()`) — o que protege contra SQL injection, já que os valores nunca são concatenados direto na string SQL.

- **`CategoriaRepository`** — `getCategorias()` (todas, ordenadas por tipo e nome) e `getCategoria($id)`.
- **`MetaRepository`**, **`ParcelamentoRepository`**, **`TransacaoRepository`** — seguem o mesmo padrão de cinco métodos: `getXPorUsuario()` (lista), `getX($id, $usuarioId)` (um registro, sempre filtrando pelo dono — comentário no código explica que isso "garante que um usuário não acesse o registro de outro"), `saveX()` (INSERT), `updateX()` (UPDATE, também restrito ao dono), `deleteX()` (DELETE, também restrito ao dono). `TransacaoRepository` adicionalmente tem `getTotalPorTipo()`, que monta a soma de receitas/despesas com `SUM()` no SQL. `ParcelamentoRepository` e `TransacaoRepository` fazem `LEFT JOIN` com `categorias` para já trazer `nome_categoria` junto do registro principal.
- **`UsuarioRepository`** — `saveUsuario()` (aplica `password_hash($senha, PASSWORD_BCRYPT)` antes de gravar — a senha nunca é salva em texto puro), `getUsuarioById()`, `getUsuarioByEmail()`, `getUsuarioByNickname()` (essas duas últimas usadas por `UsuarioService` para checar duplicidade e por `AutenticacaoService` para o login).
- **`UsuarioComumRepository`** — `criarParaUsuario($usuarioId)` (INSERT inicial ao cadastrar), `getPorUsuarioId()`, `atualizarXp()` (UPDATE dos campos de gamificação).

Todos convertem cada linha (array associativo, por causa de `PDO::FETCH_ASSOC` configurado em `ConnectionFactory`) em objeto de domínio através de um método estático `arrayParaObjeto()`, definido em cada Model correspondente.

### Models (`app/models/`)

São classes de dados (entidades) com propriedades privadas, construtor, getters, e — quando fazem sentido — pequenos cálculos derivados. Nenhuma acessa o banco diretamente.

- **`Usuario`** — id, nome, nickname, email, senha (hash), dataNascimento, foto, status, perfil, criadoEm. Método `eAdmin()` retorna `$this->perfil === 'administrador'`.
- **`UsuarioComum`** — usuarioId, xpTotal, nivel, streakAtual, maiorStreak, dataUltimoXp, visibilidadeRanking. É o único Model com **setters** (`setXpTotal()`, `setNivel()`, etc., todos retornando `self` para encadeamento), porque `GamificacaoService` precisa modificar um objeto já carregado antes de persistir de volta.
- **`Categoria`** — id, nome, icone, tipo, limiteOrcamento.
- **`Meta`** — id, usuarioId, nomeMeta, tipoMeta, valorAlvo, valorAtual, dataLimite. Tem dois métodos calculados: `getProgresso()` (percentual `valorAtual / valorAlvo * 100`, limitado a 100%, usado na barra de progresso das views) e `eConcluida()` (`valorAtual >= valorAlvo`).
- **`Parcelamento`** — id, usuarioId, categoriaId, descricao, valorTotal, quantidadeParcelas, parcelasPagas, dataPrimeiraParcela, nomeCategoria (vem do `JOIN` no repository). Métodos calculados: `getValorParcela()` (`valorTotal / quantidadeParcelas`), `getValorRestante()` (valor da parcela × parcelas que faltam), `getProgresso()` e `eQuitado()`.
- **`Transacao`** — id, usuarioId, categoriaId, tipo, valor, dataRegistro, descricao, nomeCategoria. Método `eReceita()` (`$this->tipo === 'receita'`).

Todos implementam `arrayParaObjeto(array $linha): self`, um método estático que recebe a linha crua vinda do PDO (array associativo com chaves em `snake_case`, como `valor_alvo`) e devolve uma instância do Model (propriedades em `camelCase`), já convertendo tipos quando necessário (`(float)`, `(int)`) — é a "tradução" entre o formato do banco e o formato usado no código PHP.

### Views (`app/views/`)

Organizadas em subpastas por funcionalidade: `autenticacao/` (`login.php`, `cadastro.php`), `dashboard/` (`dashboard.php`), `metas/`, `parcelamentos/`, `transacoes/` — estas três últimas seguindo sempre o mesmo trio de arquivos: `X_list.php` (listagem em tabela), `X_create.php` (formulário de novo registro), `X_edit.php` (formulário de edição, pré-preenchido).

Uma view nunca é chamada diretamente pela URL — ela só é incluída de dentro de `Controller::view()` (explicado acima), que roda `extract($data)` antes do `require_once`. Por isso uma view como `metas/metas_list.php` pode simplesmente usar `$lista` (veja abaixo) sem receber parâmetro nenhum: essa variável foi criada pelo `extract()` a partir do array `['lista' => $metas]` que o `MetaController::listarTodas()` montou.

Trecho real de `metas_list.php`, mostrando o padrão repetido em todas as views de listagem — checar se a lista está vazia, senão percorrer com `foreach` chamando os getters do Model:

```php
<?php if (empty($lista)): ?>
    <div class="alert alert-info">Você ainda não cadastrou nenhuma meta...</div>
<?php else: ?>
    <?php foreach ($lista as $meta): ?>
        <tr>
            <td><?= htmlspecialchars($meta->getNomeMeta()) ?></td>
            ...
            <div class="progress-bar" style="width: <?= $meta->getProgresso() ?>%"></div>
            ...
            <a href="<?= URL_BASE ?>/metas/editar?id=<?= $meta->getId() ?>">Editar</a>
        </tr>
    <?php endforeach; ?>
<?php endif; ?>
```

`htmlspecialchars()` converte caracteres especiais de HTML (`<`, `>`, `&`, aspas) em suas entidades, prevenindo XSS ao exibir texto que veio do usuário. `URL_BASE` (constante global de `Config.php`) é usada em toda `href`/`action` de formulário para montar links absolutos (`URL_BASE . '/metas/editar?id=...'`), garantindo que os links funcionem independente de onde a aplicação estiver hospedada — é justamente essa constante que foi ajustada na Parte 1 deste documento.

Todas as views são HTML completo e autocontido (usam Bootstrap 5 e Bootstrap Icons via CDN, `<style>` inline por página) — não há um layout/`header`/`footer` compartilhado; cada arquivo repete a mesma barra de navegação.

### `public/assets/` e `public/.htaccess`

`public/assets/css/style.css` existe mas está **vazio** (0 linhas) — todo o CSS atual das telas está inline, dentro de tags `<style>` em cada view, não nesse arquivo.

`public/.htaccess` — criado durante a correção da Parte 1, já detalhado linha a linha na seção "Causa raiz 2" acima. Existe também um segundo `.htaccess`, na raiz do projeto (`DFLG/.htaccess`, um nível acima de `public/`), que redireciona qualquer requisição para dentro de `public/` — detalhado na seção "Solução final: trocado para a Opção A", na Parte 1.

---

## O que mudou em relação a `exemplo/projeto_integrador-main/`

O projeto de exemplo do professor era um cadastro simples de jogadores: `JogadorController`/`JogadorService`/`JogadorRepository`/`Jogador` (model), com upload de imagem via `UploadService`, mais um `UsuarioController` básico. O núcleo do framework — `Autoload.php`, `Router.php`, `Controller.php`, `ConnectionFactory.php`, `DatabaseInitializer.php` — é **idêntico em estrutura** entre os dois projetos; a única diferença de fundo nesses arquivos-núcleo é que o exemplo nunca precisou lidar com deploy em subpasta dentro do próprio código (isso ficava documentado à parte, em `COMO_USAR_APACHE.md`).

O que foi construído inteiramente do zero, em cima dessa mesma fundação, foi a camada de domínio de finanças pessoais:

- **Novos models/repositories/services/controllers/views**: `Categoria`, `Meta`, `Parcelamento`, `Transacao` — nenhum desses existe no exemplo.
- **`UsuarioComum` + `GamificacaoService`**: sistema de XP/nível/streak sem equivalente no exemplo — é a funcionalidade mais autoral do projeto.
- **`AutenticacaoController`/`UsuarioService`**: o exemplo só tinha login; o cadastro público de usuário comum (com a regra RN01 de nunca permitir cadastro como administrador) foi adicionado.
- **O que foi descartado**: `UploadService` e o fluxo de upload de imagem de jogador (`public/assets/uploads/`) não têm equivalente no projeto atual, que não lida com upload de arquivos.

Em resumo: a "fundação" (como uma requisição vira uma chamada de método) veio pronta do template; tudo que faz o DFLG Investments ser um sistema de controle financeiro — as tabelas, os models, as regras de negócio (RN01 a RN08 citadas nos comentários dos Services) e as telas — foi escrito para este projeto.
