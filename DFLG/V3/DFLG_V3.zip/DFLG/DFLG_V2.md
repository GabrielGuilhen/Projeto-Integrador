# DFLG Investments — Versão 2

Documento técnico da segunda etapa de desenvolvimento do DFLG Investments.

A **V1** entregou a base do sistema: autenticação, gamificação de XP e os CRUDs de Metas,
Transações e Parcelamentos. A **V2** resolve duas lacunas que travavam a continuidade do
projeto:

1. **A aplicação não rodava no Apache/XAMPP** — só funcionava com o servidor embutido do PHP
   (`php -S localhost:8080`), o que impedia a execução em outras máquinas.
2. **Não existia módulo administrativo** — os requisitos RF02, RF05 e RN09 estavam
   inteiramente ausentes, e o campo `status = 'bloqueado'` do banco não produzia efeito
   nenhum no login.

Junto disso entrou o controle de sequência de acesso diário (streak), que a tabela
`usuario_comum` já previa nas colunas `streak_atual` e `maior_streak`, mas que nunca era
alimentado.

> **Premissa de projeto:** toda a V2 seguiu a mesma arquitetura, o mesmo padrão de codificação
> e a mesma lógica do framework base (`projeto_integrador-main`). Nenhuma biblioteca externa
> foi adicionada. Controllers continuam finos, as regras vivem nos Services, o SQL fica
> isolado nos Repositories com `prepare`/`bindValue`, e os Models são hidratados por
> `arrayParaObjeto()`.

---

## Sumário

- [Parte A — Fundação](#parte-a--fundação)
  - [A1. Execução em subpasta no Apache](#a1-execução-em-subpasta-no-apache)
  - [A2. Configuração da URL_BASE](#a2-configuração-da-url_base)
  - [A3. Sequência de acesso diário — RF11 e RN03](#a3-sequência-de-acesso-diário--rf11-e-rn03)
  - [A4. Login respeitando o bloqueio — RF02](#a4-login-respeitando-o-bloqueio--rf02)
- [Parte B — Módulo Administrativo](#parte-b--módulo-administrativo)
  - [B1. Camada de dados](#b1-camada-de-dados)
  - [B2. Regras de negócio](#b2-regras-de-negócio)
  - [B3. Controller e rotas](#b3-controller-e-rotas)
  - [B4. Views e partials](#b4-views-e-partials)
- [Requisitos atendidos](#requisitos-atendidos)
- [Arquivos criados e alterados](#arquivos-criados-e-alterados)
- [Migração da V1 para a V2](#migração-da-v1-para-a-v2)
- [Testes executados](#testes-executados)
- [Próximos passos](#próximos-passos)

---

# Parte A — Fundação

## A1. Execução em subpasta no Apache

O `Router` original lia `$_SERVER['REQUEST_URI']` diretamente. Ao rodar em
`http://localhost/IFPR/ProjetoIntegrador/DFLG/metas`, ele recebia a URI completa
`/IFPR/ProjetoIntegrador/DFLG/metas`, que não corresponde a nenhuma rota registrada — o
resultado era erro 404 em todas as páginas.

**`app/core/Router.php`** — o método `run()` passou a detectar a subpasta automaticamente
a partir do caminho do próprio `index.php` e a remover esse prefixo antes de procurar a rota:

```php
public function run()
{
    $uri  = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

    // Remove a pasta do projeto (caso esteja rodando em subpasta no Apache)
    $scriptDir = str_replace('/public', '', dirname($_SERVER['SCRIPT_NAME']));

    if ($scriptDir !== '/') {
        $uri = str_replace($scriptDir, '', $uri);
    }

    $uri = str_replace('/public', '', $uri);

    // Garante que a URI não fique vazia e comece com "/"
    if (empty($uri)) {
        $uri = '/';
    }
    if ($uri[0] !== '/') {
        $uri = '/' . $uri;
    }

    $method = strtolower($_SERVER['REQUEST_METHOD']);

    // ... busca da rota permanece igual
}
```

O mesmo código funciona nos dois cenários: quando o projeto está na raiz do servidor,
`$scriptDir` vale `/` e nada é removido; quando está em subpasta, o prefixo é descartado.
Os métodos `get()`, `post()`, `dispatch()` e `getAllRoutes()` não foram tocados.

**Dois arquivos `.htaccess`** foram criados para que o usuário não precise digitar `/public`
na barra de endereços:

`.htaccess` (raiz do projeto) — encaminha silenciosamente tudo para a pasta `public/`:

```apache
RewriteEngine On

RewriteRule ^$ public/ [L]
RewriteRule ^((?!public/).*)$ public/$1 [L]
```

`public/.htaccess` — manda para o `index.php` tudo que não for arquivo ou diretório real,
e desliga a listagem de diretórios:

```apache
RewriteEngine On

Options -Indexes

RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)$ index.php [L,QSA]
```

> Requer o módulo `mod_rewrite` ativo e `AllowOverride All` no diretório do `htdocs`.
> No XAMPP padrão, ambos já vêm habilitados.

## A2. Configuração da URL_BASE

A `URL_BASE` continua sendo uma constante declarada manualmente, exatamente como no framework
base — a decisão foi manter fidelidade ao original em vez de introduzir detecção automática
via `$_SERVER`. O que mudou foi o valor padrão e a documentação de como trocá-lo.

**`app/config/Config.php`:**

```php
// Ajuste a URL_BASE de acordo com o ambiente onde o projeto está sendo executado.
// Apache/XAMPP em subpasta (htdocs/IFPR/ProjetoIntegrador/DFLG):
define('URL_BASE', 'http://localhost/IFPR/ProjetoIntegrador/DFLG');
// Servidor embutido do PHP (php -S localhost:8080 -t public):
// define('URL_BASE', 'http://localhost:8080');

define('URL_BASE_CSS', URL_BASE . '/assets/css');
```

Trocar de ambiente é uma edição de uma linha só. A constante `URL_BASE_CSS` foi adicionada
para que as partials referenciem a folha de estilo própria do projeto sem repetir o caminho.

Foi criado também um **`README.md`** cobrindo as duas formas de execução, a configuração do
banco, as credenciais padrão e os erros mais comuns (mod_rewrite desligado, `URL_BASE`
incorreta, conflito de sessão ao alternar entre Apache e `php -S`).

## A3. Sequência de acesso diário — RF11 e RN03

O sistema passou a registrar quantos dias seguidos o usuário acessa a plataforma e a avisar
quando essa sequência é interrompida.

### Banco de dados

**`app/database/scripts/script.sql`** — a tabela `usuario_comum` ganhou uma coluna para
guardar a data do último acesso, separada da `data_ultimo_xp` (que serve à RN07 e tem
finalidade diferente):

```sql
CREATE TABLE IF NOT EXISTS usuario_comum (
    usuario_id INT PRIMARY KEY,
    xp_total INT NOT NULL DEFAULT 0,
    nivel INT NOT NULL DEFAULT 1,
    streak_atual INT NOT NULL DEFAULT 0,
    maior_streak INT NOT NULL DEFAULT 0,
    data_ultimo_xp DATE NULL,
    data_ultimo_acesso DATE NULL,      -- novo na V2
    visibilidade_ranking BOOLEAN NOT NULL DEFAULT TRUE,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

### Model

**`app/models/UsuarioComum.php`** — nova propriedade `$dataUltimoAcesso`, com parâmetro no
construtor, getter e setter fluente no mesmo padrão dos demais. Em `arrayParaObjeto()` o
valor é lido com `?? null`, para que o Model não quebre caso a coluna ainda não exista em um
banco antigo.

### Repository

**`app/repositories/UsuarioComumRepository.php`** — novo método `atualizarAcesso()`, espelhado
no `atualizarXp()` que já existia:

```php
public function atualizarAcesso(UsuarioComum $usuarioComum): bool
{
    $sql = "UPDATE usuario_comum SET streak_atual = :streakAtual, maior_streak = :maiorStreak, " .
        "data_ultimo_acesso = :dataUltimoAcesso WHERE usuario_id = :usuarioId";
    $stmt = $this->connection->prepare($sql);
    $stmt->bindValue(':streakAtual', $usuarioComum->getStreakAtual());
    $stmt->bindValue(':maiorStreak', $usuarioComum->getMaiorStreak());
    $stmt->bindValue(':dataUltimoAcesso', $usuarioComum->getDataUltimoAcesso());
    $stmt->bindValue(':usuarioId', $usuarioComum->getUsuarioId());

    return $stmt->execute();
}
```

### Service

**`app/services/GamificacaoService.php`** — método `registrarAcesso()`, que concentra toda a
regra. Ele devolve a mensagem de quebra de sequência quando ela ocorre, ou `null`:

| Situação | Comportamento |
| --- | --- |
| Acesso de hoje já registrado | Não altera nada, retorna `null` |
| Primeiro acesso do usuário (`data_ultimo_acesso` nula) | Inicia a sequência em 1 |
| Último acesso foi ontem | Incrementa `streak_atual` |
| Lacuna maior que um dia | Reinicia em 1 e **retorna a mensagem de quebra (RN03)** |

O `maior_streak` é atualizado sempre que a sequência atual supera o recorde anterior. O
método usa `DateTimeImmutable('today')`, mesma abordagem já adotada em `adicionarPontos()`.

Usuários administradores não possuem linha em `usuario_comum`; nesse caso
`getPorUsuarioId()` retorna `false` e o método encerra sem erro.

### Integração no login e na tela

**`app/services/AutenticacaoService.php`** chama `registrarAcesso()` logo após autenticar e
guarda o retorno em `$_SESSION['flash_streak']`. A **view do dashboard** exibe esse aviso em
um alerta Bootstrap dispensável e o remove da sessão em seguida, para que ele não reapareça
a cada recarregamento da página.

## A4. Login respeitando o bloqueio — RF02

Antes da V2, bloquear um usuário no banco não produzia efeito algum: o login só verificava
e-mail e senha. Sem isso, todo o controle administrativo de contas seria decorativo.

**`app/services/AutenticacaoService.php`** foi reescrito com a verificação e com um campo de
erro, seguindo o padrão de `getErros()` já usado em `MetaService`, `TransacaoService` e
`ParcelamentoService`:

```php
public function logar(string $email, string $senha) : bool {

    $usuario = $this->usuarioRepository->getUsuarioByEmail($email);

    if (!$usuario || !password_verify($senha, $usuario->getSenha())) {
        $this->erro = "E-mail ou senha inválidos";
        return false;
    }

    // RF02: contas bloqueadas pelo administrador não podem acessar o sistema
    if ($usuario->getStatus() === 'bloqueado') {
        $this->erro = "Esta conta está bloqueada. Entre em contato com o administrador.";
        return false;
    }

    $_SESSION['usuario_logado'] = $usuario;

    // RF11/RN03: registra a sequência de acesso diário
    $mensagemStreak = $this->gamificacaoService->registrarAcesso($usuario->getId());

    if ($mensagemStreak !== null) {
        $_SESSION['flash_streak'] = $mensagemStreak;
    }

    return true;
}
```

A assinatura pública (`bool`) foi preservada — o `AutenticacaoController` apenas troca a
mensagem fixa pelo retorno de `getErro()`, mantendo o restante do fluxo idêntico.

---

# Parte B — Módulo Administrativo

Módulo completo de gestão de contas e indicadores da plataforma, atendendo RF02, RF05 e RN09.

## B1. Camada de dados

**`app/repositories/UsuarioRepository.php`** — todos os métodos novos usam consultas
preparadas, sem exceção:

| Método | Finalidade |
| --- | --- |
| `getUsuarios(?string $busca)` | Listagem hidratada em objetos `Usuario`, com filtro opcional por nome, nickname ou e-mail |
| `updateUsuario(Usuario)` | Atualiza dados cadastrais, perfil e status — **não altera a senha** |
| `atualizarStatus(int, string)` | Bloqueio e desbloqueio |
| `deleteUsuario(int)` | Exclusão da conta |
| `contarAdminsAtivos()` | Insumo da RN09 |
| `contarUsuarios()` | Indicador da RF05 |
| `contarPorStatus(string)` | Total de contas ativas e bloqueadas |
| `contarNovosUsuarios(int $dias)` | Novos cadastros no período |
| `getDistribuicaoNiveis()` | `JOIN` com `usuario_comum`, agrupado por nível |
| `getMaioresStreaks(int $limite)` | Ranking de sequências para o painel |

**`MetaRepository`** e **`TransacaoRepository`** receberam um `contarTodas()` cada, para os
totais globais do painel administrativo.

## B2. Regras de negócio

### UsuarioService

A classe existente foi estendida, reaproveitando `getUsuarioByEmail()` e
`getUsuarioByNickname()` — os mesmos métodos que já sustentavam a RN02 no cadastro público.

- **`atualizar(Usuario)`** — revalida a unicidade de e-mail e nickname **ignorando o próprio
  registro**, para que salvar um usuário sem mudar o e-mail não seja bloqueado por ele mesmo.
- **`bloquear(int)` / `desbloquear(int)`**
- **`excluir(int $id, int $idLogado)`**
- **`temErros()` / `getErros()`** — mesmo contrato dos outros Services do projeto.

### RN09 — o painel nunca fica sem gestão

A regra diz que o último administrador ativo não pode excluir a própria conta. Na prática,
existem três caminhos que levariam ao mesmo resultado indesejado, e todos foram fechados:

| Ação sobre o último admin ativo | Onde é barrado |
| --- | --- |
| **Excluir** a conta | `excluir()` — mensagem específica quando é a própria conta do usuário logado |
| **Bloquear** a conta | `bloquear()` |
| **Rebaixar** para perfil comum (ou bloquear pela tela de edição) | `atualizar()` |

```php
public function excluir(int $id, int $idLogado): bool
{
    $this->erros = [];

    $usuario = $this->repository->getUsuarioById($id);

    if (!$usuario) {
        $this->erros['usuario'] = "Usuário não encontrado.";
        return false;
    }

    if ($usuario->eAdmin() && $this->repository->contarAdminsAtivos() <= 1) {

        $mensagem = $id === $idLogado
            ? "Você é o último administrador ativo e não pode excluir a própria conta."
            : "Este é o último administrador ativo e não pode ser excluído.";

        $this->erros['usuario'] = $mensagem;

        return false;
    }

    return $this->repository->deleteUsuario($id);
}
```

### AdminService

Classe nova, dedicada aos indicadores da RF05. Ela apenas agrega os Repositories, mantendo o
`UsuarioService` focado em usuários:

- `getIndicadores()` — total de usuários, ativos, bloqueados, novos cadastros nos últimos 30
  dias, total de registros financeiros e total de metas;
- `getDistribuicaoNiveis()` — estatística de engajamento por nível;
- `getMaioresStreaks()` — maiores sequências de acesso.

## B3. Controller e rotas

**`app/controllers/AdminController.php`** — toda ação começa com `$this->adminRequired()`,
método já existente na Controller base, que verifica sessão e perfil `administrador` e
redireciona para `/login` em caso contrário.

| Método | Rota | Descrição |
| --- | --- | --- |
| `index()` | `GET /admin` | Painel de indicadores (RF05) |
| `listarUsuarios()` | `GET /admin/usuarios` | Listagem com busca (RF02) |
| `editar()` | `GET /admin/usuarios/editar` | Formulário de edição |
| `atualizar()` | `POST /admin/usuarios/atualizar` | Persiste as alterações |
| `bloquear()` | `GET /admin/usuarios/bloquear` | Bloqueia a conta |
| `desbloquear()` | `GET /admin/usuarios/desbloquear` | Reativa a conta |
| `excluir()` | `GET /admin/usuarios/excluir` | Exclui a conta (RN09) |

As ações que redirecionam gravam o resultado em `$_SESSION['flash_admin_sucesso']` ou
`$_SESSION['flash_admin_erro']`, consumidos e limpos por `listarUsuarios()` — assim a
mensagem sobrevive ao redirecionamento sem poluir a URL.

A validação de formulário usa `app\helpers\Validador`, do mesmo jeito que o
`AutenticacaoController::salvar()` já fazia.

As rotas foram registradas em **`public/index.php`**, seguindo o estilo dos blocos existentes:

```php
// Admin Routes
$router->get('/admin', 'AdminController@index');
$router->get('/admin/usuarios', 'AdminController@listarUsuarios');
$router->get('/admin/usuarios/editar', 'AdminController@editar');
$router->post('/admin/usuarios/atualizar', 'AdminController@atualizar');
$router->get('/admin/usuarios/bloquear', 'AdminController@bloquear');
$router->get('/admin/usuarios/desbloquear', 'AdminController@desbloquear');
$router->get('/admin/usuarios/excluir', 'AdminController@excluir');
```

## B4. Views e partials

### Partials compartilhadas

Na V1, o bloco `<!DOCTYPE>` + `<head>` + navbar estava copiado em 13 arquivos de view.
Qualquer mudança no menu exigia editar todos eles — e o menu precisava mudar agora, para
receber o link do painel administrativo.

Foram criadas duas partials, ambas em `app/views/partials/`:

- **`header.php`** — abertura do documento, CDNs do Bootstrap 5 e Bootstrap Icons, folha de
  estilo própria via `URL_BASE_CSS`, navbar com destaque da página atual e o link **Admin**
  exibido apenas quando `$_SESSION['usuario_logado']->eAdmin()` é verdadeiro;
- **`footer.php`** — fechamento do container, bundle JS do Bootstrap e fechamento das tags.

Cada view define duas variáveis e inclui as partials:

```php
<?php

$titulo = 'Metas';
$paginaAtiva = 'metas';

require __DIR__ . '/../partials/header.php';

?>

<!-- conteúdo específico da tela -->

<?php require __DIR__ . '/../partials/footer.php'; ?>
```

As 10 views internas (dashboard, metas, transações e parcelamentos) foram migradas para esse
formato, sem alteração no conteúdo de cada tela. As telas de login e cadastro ficaram de
fora, por não terem navbar.

Os estilos que estavam repetidos em blocos `<style>` inline (`body`, `.navbar-dflg`,
`.stat-card`) foram consolidados em **`public/assets/css/style.css`**, que até então estava
vazio.

### Telas novas

- **`admin/admin_dashboard.php`** — cards com os indicadores da RF05, tabela de distribuição
  de níveis e tabela das maiores sequências;
- **`admin/admin_usuarios_list.php`** — tabela de usuários com badges de perfil e status,
  campo de busca, marcação da própria conta do administrador logado e as ações Editar,
  Bloquear/Desbloquear e Excluir (as duas destrutivas com `confirm()`);
- **`admin/admin_usuarios_edit.php`** — formulário com nome, nickname, e-mail, data de
  nascimento, `select` de perfil e `select` de status, com aviso explícito de que a senha do
  usuário não é alterada por essa tela.

---

## Requisitos atendidos

| Código | Descrição | Como foi atendido |
| --- | --- | --- |
| **RF02** | Listagem de usuários e controle administrativo de contas | `AdminController` + `UsuarioService` + telas de listagem e edição; bloqueio agora efetivo no login |
| **RF05** | Painel de indicadores da plataforma | `AdminService::getIndicadores()` e `admin_dashboard.php` |
| **RF11** | Registrar e exibir a sequência de acesso | `GamificacaoService::registrarAcesso()`, coluna `data_ultimo_acesso`, exibição no dashboard |
| **RN01** | Novos administradores só definidos por outro administrador | `select` de perfil disponível apenas na tela de edição, protegida por `adminRequired()` |
| **RN02** | E-mail e nickname únicos | Estendida à edição administrativa, ignorando o próprio registro |
| **RN03** | Encerrar a sequência e exibir mensagem de fim | Mensagem de quebra retornada pelo Service e exibida como alerta no dashboard |
| **RN09** | Impedir que o último administrador ativo fique sem substituto | Barrado nos três caminhos: exclusão, bloqueio e rebaixamento |
| **RNF02** | Proteção dos dados por camadas e acesso autorizado | `adminRequired()` em todas as ações administrativas; consultas preparadas em 100% do SQL novo |
| **RNF05** | Orientação a objetos e arquitetura MVC | Todo o código novo segue Model → Repository → Service → Controller |

---

## Arquivos criados e alterados

### Criados

```
.htaccess                                  Redirecionamento para public/
public/.htaccess                           Front Controller + Options -Indexes
README.md                                  Instruções de execução e configuração
DFLG_V2.md                                 Este documento
app/controllers/AdminController.php        7 ações administrativas
app/services/AdminService.php              Indicadores da RF05
app/views/partials/header.php              Cabeçalho e navbar compartilhados
app/views/partials/footer.php              Rodapé compartilhado
app/views/admin/admin_dashboard.php        Painel de indicadores
app/views/admin/admin_usuarios_list.php    Listagem e ações de conta
app/views/admin/admin_usuarios_edit.php    Formulário de edição
```

### Alterados

```
app/core/Router.php                        run() com detecção de subpasta
app/config/Config.php                      URL_BASE documentada + URL_BASE_CSS
app/database/scripts/script.sql            Coluna data_ultimo_acesso
app/models/UsuarioComum.php                Propriedade, getter, setter e hidratação
app/repositories/UsuarioComumRepository.php  atualizarAcesso()
app/repositories/UsuarioRepository.php     10 métodos para o módulo admin
app/repositories/MetaRepository.php        contarTodas()
app/repositories/TransacaoRepository.php   contarTodas()
app/services/GamificacaoService.php        registrarAcesso()
app/services/AutenticacaoService.php       Bloqueio, streak e getErro()
app/services/UsuarioService.php            Gestão de usuários e RN09
app/controllers/AutenticacaoController.php Usa a mensagem de erro do Service
public/index.php                           Bloco de rotas do admin
public/assets/css/style.css                Estilos consolidados
app/views/dashboard/*.php                  Migradas para as partials
app/views/metas/*.php                      Migradas para as partials
app/views/transacoes/*.php                 Migradas para as partials
app/views/parcelamentos/*.php              Migradas para as partials
```

---

## Migração da V1 para a V2

O `DatabaseInitializer` só executa o `script.sql` quando o banco ainda não existe. Para quem
já tinha o banco da V1 criado, há dois caminhos:

**Recriar do zero** (recomendado em ambiente de desenvolvimento):

```sql
DROP DATABASE IF EXISTS db_dflg_investments;
```

Basta recarregar a aplicação: o banco é recriado com o schema atualizado, o administrador
padrão e as 13 categorias.

**Preservar os dados existentes:**

```sql
ALTER TABLE usuario_comum ADD COLUMN data_ultimo_acesso DATE NULL;
```

Em seguida, ajuste a `URL_BASE` em `app/config/Config.php` conforme o ambiente e confirme que
o `mod_rewrite` do Apache está ativo.

**Credenciais padrão:** `admin@dflg.com` / `admin123`

---

## Testes executados

Todos os cenários abaixo foram verificados na aplicação em execução no XAMPP (Apache +
MySQL), com o banco recriado a partir do `script.sql` atualizado.

### Fundação

| Cenário | Resultado |
| --- | --- |
| Acesso a `/` e às páginas internas em subpasta, sem `/public` na URL | HTTP 200 |
| Login do administrador e carregamento do dashboard | OK, link Admin visível na navbar |
| Primeiro acesso de um usuário novo | `streak_atual = 1` |
| Último acesso ontem, sequência em 4 | Incrementou para 5, recorde atualizado |
| Último acesso há 5 dias, sequência em 4 | Reiniciou em 1 e exibiu o aviso de quebra |
| Recarregar o dashboard após o aviso | Mensagem não se repete |
| Login de conta bloqueada | Recusado com mensagem específica |

### Módulo administrativo

| Cenário | Resultado |
| --- | --- |
| Painel `/admin` com os indicadores | Valores conferidos contra `SELECT COUNT(*)` nas tabelas |
| Listagem e busca de usuários | OK |
| Edição de nome e nickname | Persistida |
| Edição usando o e-mail de outro usuário | Recusada, nada gravado |
| Excluir a própria conta sendo o único administrador ativo (RN09) | Recusado, registro intacto |
| Bloquear o único administrador ativo (RN09) | Recusado |
| Excluir um administrador havendo dois ativos | Permitido |
| Bloquear e depois desbloquear um usuário comum | Status alternado corretamente |
| Usuário comum acessando `/admin` e `/admin/usuarios` | HTTP 302 para `/login`; link Admin oculto no menu |
| Exclusão de usuário com metas e registros financeiros | Dados removidos junto, via `ON DELETE CASCADE` |

Todos os arquivos PHP do projeto foram validados com `php -l`, sem erros de sintaxe.

---

## Próximos passos

> **Atualização:** todos os requisitos listados abaixo foram implementados na V3.
> Veja [`DFLG_V3.md`](DFLG_V3.md).

Requisitos ainda não implementados quando esta versão foi escrita:

| Código | Requisito |
| --- | --- |
| RF04 / RF14 | Perfil do usuário: visualização, edição, foto e visibilidade no ranking |
| RF07 | Dashboard financeiro com saldo, saldo do mês e evolução patrimonial reais |
| RF10 | Calculadora de investimentos e projeções (exige a tabela `simulacao_investimento`) |
| RF12 / RN10 | Rankings geral, mensal e semanal |
| RF13 | Relatórios financeiros mensais e anuais |
| RF15 | Home page pública de apresentação do sistema |
| RF16 / RN12 | CRUD de categorias pelo administrador e alerta de estouro do limite mensal |
| RNF08 | Modo claro e modo escuro em todas as telas |

A criação das partials na V2 deixa o RNF08 (modo escuro) consideravelmente mais simples de
implementar: o `<head>` e a navbar passaram a existir em um único lugar.
