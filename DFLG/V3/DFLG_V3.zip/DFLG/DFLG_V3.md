# DFLG Investments — Versão 3

Documento técnico da terceira etapa de desenvolvimento do DFLG Investments.

A **V1** entregou a base do sistema (autenticação, gamificação de XP e os CRUDs de Metas,
Transações e Parcelamentos). A **V2** colocou a aplicação para rodar no Apache/XAMPP,
implementou a sequência de acesso diário e construiu o módulo administrativo — o histórico
completo está em [`DFLG_V2.md`](DFLG_V2.md).

A **V3 fecha o escopo funcional do projeto**: todos os 19 requisitos funcionais, as 12 regras
de negócio e os 8 requisitos não funcionais do documento de especificação estão implementados.

> **Premissa mantida desde a V1:** mesma arquitetura, mesmo padrão de codificação e mesma
> lógica do framework base (`projeto_integrador-main`). Nenhuma biblioteca externa foi
> adicionada — Bootstrap continua vindo por CDN e todo o back-end é PHP puro com PDO.
> Controllers finos, regras nos Services, SQL isolado nos Repositories com `prepare`/`bindValue`,
> Models hidratados por `arrayParaObjeto()`.

---

## Sumário

- [Decisões estruturais](#decisões-estruturais)
- [Fase 4 — Gamificação](#fase-4--gamificação)
- [Fase 5 — Categorias e orçamento](#fase-5--categorias-e-orçamento)
- [Fase 6 — Ferramentas financeiras](#fase-6--ferramentas-financeiras)
- [Fase 7 — Interface](#fase-7--interface)
- [Requisitos atendidos](#requisitos-atendidos)
- [Arquivos criados e alterados](#arquivos-criados-e-alterados)
- [Migração da V2 para a V3](#migração-da-v2-para-a-v3)
- [Testes executados](#testes-executados)

---

## Decisões estruturais

Três tabelas novas entraram no banco nesta etapa. Duas já constavam no diagrama de entidade
e relacionamento e ainda não haviam sido criadas; a terceira é uma adição necessária que
precisa ser registrada.

### 1. `xp_historico` — adição ao DER original

A **RN10** exige rankings semanal e mensal "baseados nos níveis adquiridos **naquele período
de tempo**". A tabela `usuario_comum` guarda apenas o XP acumulado total, sem nenhuma
referência temporal — com ela é impossível responder "quanto este usuário ganhou nesta
semana".

A solução foi registrar cada ganho de XP como uma linha datada:

```sql
CREATE TABLE IF NOT EXISTS xp_historico (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    pontos INT NOT NULL,
    origem ENUM('acesso_diario', 'registro_financeiro', 'meta_concluida') NOT NULL,
    data_ganho DATE NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    INDEX idx_xp_usuario_data (usuario_id, data_ganho)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

O campo `origem` é o mesmo conjunto de três fontes de experiência descrito na RN04, o que faz
a tabela servir também ao extrato de XP exibido no perfil do usuário.

### 2. `meta_categoria` — prevista no DER

A **RF16** diz que o usuário "define um máximo de gastos por mês por categoria". O limite,
portanto, é **por usuário**, e não global. A coluna `categorias.limite_orcamento`, que já
existia, é global e não atende à regra. A tabela do DER foi finalmente criada:

```sql
CREATE TABLE IF NOT EXISTS meta_categoria (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    categoria_id INT NOT NULL,
    limite_mensal DECIMAL(10,2) NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (categoria_id) REFERENCES categorias(id) ON DELETE CASCADE,
    UNIQUE KEY uk_usuario_categoria (usuario_id, categoria_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

A chave única garante um único limite por usuário e categoria, permitindo gravar com
`INSERT ... ON DUPLICATE KEY UPDATE` — o mesmo formulário serve para criar e para alterar.

### 3. `simulacao_investimento` — prevista no DER

Armazena as projeções da **RF10**, com os parâmetros da simulação e os totais já calculados
(valor final, total investido e juros ganhos), evitando recalcular a projeção a cada
listagem.

### 4. Coluna `metas.xp_concedido`

A **RN04** manda pontuar metas cumpridas. Sem uma marca de controle, o usuário poderia
retirar e recolocar dinheiro na meta repetidamente para farmar XP — exatamente o abuso que a
RN07 combate no caso dos registros financeiros. A coluna booleana garante que a pontuação de
cada meta aconteça uma única vez.

---

# Fase 4 — Gamificação

## Experiência com histórico e a RN04 completa

Até a V2, XP vinha de uma única fonte: o primeiro registro financeiro do dia. A RN04, porém,
determina que os níveis venham "da sequência de acesso, do cumprimento de metas financeiras,
e do cadastro de registros financeiros" — as três.

**`app/services/GamificacaoService.php`** foi reescrito em torno de um método privado
`creditar()`, que soma os pontos, recalcula o nível e grava a linha no histórico. As três
origens passaram a ser constantes da classe:

```php
public const XP_ACESSO_DIARIO       = 5;
public const XP_REGISTRO_FINANCEIRO = 10;
public const XP_META_CONCLUIDA      = 50;
public const XP_POR_NIVEL           = 100;
```

| Método | Origem | Quando dispara | Trava |
| --- | --- | --- | --- |
| `registrarAcesso()` | `acesso_diario` | No login, uma vez por dia | `data_ultimo_acesso` |
| `adicionarPontos()` | `registro_financeiro` | No primeiro registro do dia | `data_ultimo_xp` (RN07) |
| `pontuarMetaConcluida()` | `meta_concluida` | Quando a meta atinge o valor alvo | `metas.xp_concedido` |

Dois métodos auxiliares alimentam as barras de progresso da interface:
`getProgressoNivel()` devolve a porcentagem dentro do nível atual e `getXpParaProximoNivel()`
diz quanto falta para subir.

## Rankings geral, mensal e semanal — RF12 e RN10

**`app/repositories/XpHistoricoRepository.php`** resolve o ranking em uma única consulta.
O detalhe importante é que o filtro de período fica no `ON` do `LEFT JOIN`, e não no `WHERE`:

```sql
FROM usuario_comum uc
INNER JOIN usuarios u ON u.id = uc.usuario_id
LEFT JOIN xp_historico xh ON xh.usuario_id = uc.usuario_id
                          AND xh.data_ganho >= :dataInicio
WHERE uc.visibilidade_ranking = 1 AND u.status = 'ativo'
GROUP BY ...
ORDER BY pontos_periodo DESC, uc.xp_total DESC, u.nome
```

Se o filtro estivesse no `WHERE`, usuários sem pontuação no período sumiriam da lista em vez
de aparecerem com zero. O `WHERE` cuida de outra coisa: respeitar a `visibilidade_ranking`
(RF04) e esconder contas bloqueadas.

**`app/services/RankingService.php`** traduz o período em uma data de corte
(`first day of this month`, `monday this week`, ou nenhuma para o geral) e atribui a posição
de cada usuário, de modo que a View não precise controlar contadores.

A tela `ranking/ranking_list.php` usa abas para alternar entre os três períodos, destaca a
linha do usuário logado, marca os três primeiros com troféu e avisa quem está com o perfil
oculto do ranking.

## Perfil do usuário — RF04 e RF14

**`app/controllers/PerfilController.php`** reúne visualização e edição.

A tela de visualização (RF14) mostra foto, nome, nickname, **posição no ranking**, nível,
sequência atual, recorde de sequência, metas criadas e concluídas, a barra de progresso até
o próximo nível e o extrato dos últimos ganhos de XP com a origem de cada um.

As ações de edição (RF04):

- **Dados cadastrais** — `UsuarioService::atualizarPerfil()` revalida a unicidade de e-mail e
  nickname ignorando o próprio registro. Usa `UsuarioRepository::updatePerfil()`, uma consulta
  separada que **não toca em perfil nem em status**: promover ou bloquear alguém continua
  sendo exclusividade do administrador.
- **Foto** — `UploadService` adaptado do projeto de exemplo, restrito a imagens, com limite
  de 2MB, nome gerado por `random_bytes()` e verificação por `getimagesize()` (um arquivo com
  extensão `.png` mas conteúdo diferente é recusado). A foto antiga é apagada do disco.
- **Senha** — exige a senha atual como confirmação, mínimo de 6 caracteres e confirmação
  coincidente.
- **Visibilidade no ranking** — um switch que grava em `usuario_comum.visibilidade_ranking`.

Após salvar, o objeto da sessão é recarregado para que a navbar reflita os dados novos.

## Dashboard financeiro real — RF07

O `DashboardController` da V2 exibia apenas nível, XP e sequência. Agora ele monta o resumo
financeiro completo a partir dos Repositories:

| Bloco | Fonte |
| --- | --- |
| Saldo total | `TransacaoService::getSaldo()` |
| Saldo do mês, com receitas e despesas | `getSaldoDoMes()` e `getTotalPorTipoNoMes()` |
| Total economizado | `MetaRepository::getTotalGuardado()` |
| Parcelas do mês e parcelamentos ativos | `ParcelamentoRepository::getTotais()` |
| Evolução financeira dos últimos 6 meses | `getEvolucaoMensal()` |
| Gastos do mês por categoria | `getGastoPorCategoria()` |
| Progresso das metas | `MetaService::getMetas()` |
| Alertas de orçamento (RN12) | `CategoriaService::getAlertasOrcamento()` |

A evolução mensal e o comparativo de receitas x despesas são desenhados com barras de
progresso do próprio Bootstrap, dimensionadas em relação ao maior valor da série — sem
depender de nenhuma biblioteca de gráficos, o que mantém o RNF01 (carregamento em até 2
segundos) sob controle.

## Cumprir metas — RF19

A tela de metas ganhou um botão **Guardar** que abre um modal de aporte.
`MetaService::adicionarValor()` soma o valor com `valor_atual = valor_atual + :valor` — uma
operação atômica no banco, sem ler-somar-gravar — e em seguida chama `verificarConclusao()`.

Quando a meta atinge o alvo pela primeira vez, o usuário ganha os 50 XP e a coluna
`xp_concedido` é marcada. A listagem passou a mostrar quanto falta para a meta, quantos dias
restam e um selo de **Prazo vencido** para metas não cumpridas fora do prazo.

---

# Fase 5 — Categorias e orçamento

## CRUD de categorias — RF16

**`app/controllers/CategoriaController.php`** concentra dois públicos no mesmo Controller,
separados pelo método de proteção usado em cada ação:

- as ações de CRUD de categorias abrem com `adminRequired()`;
- as ações de orçamento abrem com `autenticacaoRequired()`.

O `CategoriaService` valida nome obrigatório, tipo válido e nome único por tipo. A exclusão
tem uma trava: `contarRegistrosVinculados()` soma os lançamentos em `registro_financeiro` e
`parcelamentos`, e categorias com histórico não são apagadas — do contrário, o
`ON DELETE SET NULL` deixaria transações antigas dos usuários sem classificação.

## Orçamento mensal e alerta ativo — RN12

**`app/repositories/OrcamentoRepository.php`** grava os limites em `meta_categoria`.

`CategoriaService::getOrcamentos()` cruza cada limite com o gasto real do mês
(`getGastoDaCategoriaNoMes()`) e classifica a situação:

| Percentual do limite | Situação | Efeito na interface |
| --- | --- | --- |
| Abaixo de 80% | `ok` | Barra verde, sem alerta |
| De 80% a 99,9% | `atencao` | Barra amarela + alerta de atenção |
| 100% ou mais | `estourado` | Barra vermelha + alerta de estouro, com o valor excedido |

A V2 do sistema apenas sinalizava a proximidade do limite. A RN12 pede notificação ativa: os
alertas agora aparecem **no topo do dashboard**, em toda visita, com link direto para a tela
de orçamento — não é preciso o usuário ir procurar.

A tela `orcamentos_list.php` mostra um cartão por categoria com barra de progresso, valores
absolutos e o alerta correspondente, e um modal define ou atualiza qualquer limite.

---

# Fase 6 — Ferramentas financeiras

## Calculadora de investimentos — RF10

**`app/services/SimulacaoService.php`** projeta o crescimento mês a mês com juros compostos e
aportes:

```php
for ($mes = 1; $mes <= $simulacao->getPeriodoMeses(); $mes++) {
    $saldo = $saldo * (1 + $taxa) + $simulacao->getAporteMensal();
    $investido += $simulacao->getAporteMensal();
    // ...
}
```

O cálculo mês a mês foi escolhido em vez da fórmula fechada porque devolve a série completa,
que a tela usa para mostrar a projeção a cada 12 meses.

A tela permite calcular sem salvar e, se o usuário quiser guardar, o mesmo formulário posta
em `/calculadora/salvar`. As simulações salvas ficam listadas abaixo, com opção de exclusão.

## Relatórios mensais e anuais — RF13

**`app/controllers/RelatorioController.php`** monta os dois relatórios na mesma tela, a partir
de um seletor de mês e ano. O ano selecionado é sempre incluído na lista de opções, mesmo sem
lançamentos, para que o filtro nunca fique inconsistente.

- **Mensal:** receitas, despesas, saldo e a tabela de despesas por categoria com o percentual
  de participação de cada uma.
- **Anual:** totais do ano e um comparativo dos 12 meses, com os meses sem lançamento zerados
  em vez de ausentes, e o mês selecionado destacado na tabela.

## Indicadores de parcelamentos — RF18

`ParcelamentoRepository::getTotais()` resolve os quatro indicadores em uma consulta só,
derivando o valor da parcela de `valor_total / quantidade_parcelas`:

| Indicador | Cálculo |
| --- | --- |
| Ativos | Parcelamentos com `parcelas_pagas < quantidade_parcelas` |
| Total gasto no mês | Soma das parcelas dos parcelamentos ainda ativos |
| Total pago | `valor_total / quantidade_parcelas * parcelas_pagas` |
| Total gasto | Soma de `valor_total` |

---

# Fase 7 — Interface

## Home page pública — RF15 e RN11

A raiz do site deixou de apontar para o dashboard:

```php
// RF15/RN11: a raiz é a home pública; o dashboard exige autenticação
$router->get('/', 'HomeController@index');
$router->get('/dashboard', 'DashboardController@index');
```

O `HomeController` redireciona quem já está logado direto para o dashboard. A tela apresenta
o sistema em três passos (registrar, definir metas, ganhar XP), lista os recursos da
plataforma e traz botões de cadastro.

> **Efeito colateral esperado:** como a home não consulta o banco, a criação automática do
> schema pelo `DatabaseInitializer` passou a acontecer no primeiro acesso a uma tela com
> dados (o login, por exemplo), e não mais ao abrir a raiz. O comportamento do
> `ConnectionFactory` continua o mesmo — apenas o momento do primeiro acesso mudou.

## Modo claro e escuro — RNF08

Toda a paleta foi movida para variáveis CSS em `public/assets/css/style.css`:

```css
:root {
    --dflg-bg: #f4f5f9;
    --dflg-surface: #ffffff;
    --dflg-text: #212529;
    /* ... */
}

[data-tema="escuro"] {
    --dflg-bg: #14161c;
    --dflg-surface: #1e2129;
    --dflg-text: #e9ecef;
    /* ... */
}
```

O tema é trocado por um único atributo `data-tema` no `<html>`. `public/assets/js/tema.js`
grava a escolha em `localStorage` e a reaplica em todas as páginas — inclusive na home, no
login e no cadastro. O script é carregado **antes** do CSS, no topo do `<head>`, para que a
página não pisque branca antes de escurecer.

A migração para partials feita na V2 foi o que tornou isso barato: o `<head>` e a navbar
existem em um único arquivo.

## Navbar reorganizada

Com nove destinos, os botões soltos da V2 não cabiam mais. A navbar virou um
`navbar-expand-lg` com menu colapsável no celular (RNF07), os itens são gerados por um array
no início da partial, e as telas administrativas foram agrupadas em um dropdown **Admin**
visível apenas para administradores.

---

## Requisitos atendidos

### Nesta versão

| Código | Descrição | Implementação |
| --- | --- | --- |
| **RF04** | Gerenciar perfil, foto e visibilidade no ranking | `PerfilController`, `UploadService`, `perfil_edit.php` |
| **RF07** | Dashboard financeiro completo | `DashboardController` + métodos de agregação nos Repositories |
| **RF10** | Calculadora de investimentos | `SimulacaoService`, tabela `simulacao_investimento` |
| **RF12** | Ranking de progresso | `RankingService`, `RankingController` |
| **RF13** | Relatórios mensais e anuais | `RelatorioController` |
| **RF14** | Visualizar perfil com nível, ranking e sequência | `perfil_show.php` |
| **RF15** | Home page de apresentação | `HomeController`, `home.php` |
| **RF16** | Criar e deletar categorias; limite mensal por categoria | `CategoriaController`, `OrcamentoRepository` |
| **RF18** | Indicadores de parcelamentos | `ParcelamentoRepository::getTotais()` |
| **RF19** | Cumprir metas | `MetaService::adicionarValor()`, modal de aporte |
| **RN04** | Níveis por sequência, metas e registros | As três origens do `GamificacaoService` |
| **RN10** | Rankings semanal, mensal e geral | Tabela `xp_historico` + filtro por período |
| **RN11** | Redirecionamento à home sem autenticação | Rota `/` pública |
| **RN12** | Notificar estouro de limite de categoria | Alertas em 80% e 100%+ no dashboard |
| **RNF07** | Responsividade | Navbar colapsável e grid do Bootstrap |
| **RNF08** | Modo claro e escuro | Variáveis CSS + `tema.js` |

### Situação geral do projeto

Com a V3, **os 19 requisitos funcionais, as 12 regras de negócio e os 8 requisitos não
funcionais** da especificação estão implementados. Requisitos entregues nas versões
anteriores: RF01, RF03, RF06, RF08, RF09, RF11, RF17 e RN01–RN03, RN05–RN09 (V1 e V2);
RF02 e RF05 (V2).

---

## Arquivos criados e alterados

### Criados

```
app/controllers/HomeController.php           Home pública
app/controllers/PerfilController.php         Perfil do usuário
app/controllers/RankingController.php        Rankings
app/controllers/RelatorioController.php      Relatórios
app/controllers/CalculadoraController.php    Calculadora
app/controllers/CategoriaController.php      Categorias e orçamento
app/services/RankingService.php              Períodos e posições
app/services/SimulacaoService.php            Juros compostos
app/services/UploadService.php               Upload da foto de perfil
app/repositories/XpHistoricoRepository.php   Histórico de XP e rankings
app/repositories/OrcamentoRepository.php     Limites por categoria
app/repositories/SimulacaoRepository.php     Simulações salvas
app/models/SimulacaoInvestimento.php         Entidade da simulação
app/views/home/home.php                      Apresentação do sistema
app/views/perfil/perfil_show.php             Visualização do perfil
app/views/perfil/perfil_edit.php             Edição do perfil
app/views/ranking/ranking_list.php           Ranking com abas
app/views/relatorios/relatorios.php          Relatórios mensal e anual
app/views/calculadora/calculadora.php        Calculadora e simulações
app/views/categorias/categorias_list.php     Categorias (admin)
app/views/categorias/categorias_create.php   Nova categoria
app/views/categorias/categorias_edit.php     Editar categoria
app/views/categorias/orcamentos_list.php     Orçamento por categoria
public/assets/js/tema.js                     Alternância de tema
DFLG_V3.md                                   Este documento
```

### Alterados

```
app/database/scripts/script.sql        3 tabelas novas + coluna xp_concedido
app/config/Config.php                  UPLOAD_PATH e URL_BASE_UPLOADS
app/services/GamificacaoService.php    Reescrito: 3 origens de XP + histórico
app/services/MetaService.php           Aporte, conclusão e XP de meta
app/services/CategoriaService.php      Reescrito: CRUD + orçamento + alertas
app/services/UsuarioService.php        Perfil, foto, senha e visibilidade
app/services/TransacaoService.php      Agregações mensais e anuais
app/services/ParcelamentoService.php   getTotais()
app/repositories/TransacaoRepository.php     7 métodos de agregação
app/repositories/UsuarioRepository.php       updatePerfil, atualizarFoto, atualizarSenha
app/repositories/UsuarioComumRepository.php  atualizarDataUltimoXp, visibilidade
app/repositories/MetaRepository.php          adicionarValor, marcarXpConcedido, totais
app/repositories/CategoriaRepository.php     CRUD completo
app/repositories/ParcelamentoRepository.php  getTotais()
app/models/Meta.php                    xpConcedido, valorRestante, diasRestantes, eVencida
app/controllers/DashboardController.php  Reescrito para dados reais
app/controllers/MetaController.php     Ação de aporte
app/controllers/ParcelaController.php  Totais na listagem
app/views/partials/header.php          Navbar colapsável, dropdown admin, tema
app/views/dashboard/dashboard.php      Reescrito (RF07 + RN12)
app/views/metas/metas_list.php         Modal de aporte e selos de situação
app/views/parcelamentos/parcelamentos_list.php  Cards de indicadores
app/views/autenticacao/login.php       Script de tema e CSS próprio
app/views/autenticacao/cadastro.php    Script de tema e CSS próprio
public/assets/css/style.css            Variáveis CSS dos dois temas
public/index.php                       22 rotas novas
```

---

## Migração da V2 para a V3

O `DatabaseInitializer` só executa o `script.sql` quando o banco ainda não existe.

**Recriar do zero** (recomendado em desenvolvimento):

```sql
DROP DATABASE IF EXISTS db_dflg_investments;
```

Depois é só acessar a tela de login: o banco é recriado com o schema completo, o
administrador padrão e as 13 categorias.

**Preservar os dados existentes:**

```sql
ALTER TABLE metas ADD COLUMN xp_concedido BOOLEAN NOT NULL DEFAULT FALSE;

CREATE TABLE IF NOT EXISTS xp_historico (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    pontos INT NOT NULL,
    origem ENUM('acesso_diario', 'registro_financeiro', 'meta_concluida') NOT NULL,
    data_ganho DATE NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    INDEX idx_xp_usuario_data (usuario_id, data_ganho)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS meta_categoria (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    categoria_id INT NOT NULL,
    limite_mensal DECIMAL(10,2) NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (categoria_id) REFERENCES categorias(id) ON DELETE CASCADE,
    UNIQUE KEY uk_usuario_categoria (usuario_id, categoria_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS simulacao_investimento (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    nome VARCHAR(100) NOT NULL,
    valor_inicial DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    aporte_mensal DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    taxa_mensal DECIMAL(6,3) NOT NULL,
    periodo_meses INT NOT NULL,
    valor_final DECIMAL(12,2) NOT NULL,
    total_investido DECIMAL(12,2) NOT NULL,
    total_juros DECIMAL(12,2) NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

Bancos migrados dessa forma começam com o `xp_historico` vazio: os rankings por período só
passam a refletir dados a partir do momento da migração, enquanto o ranking geral continua
usando o XP acumulado.

A pasta `public/assets/uploads` é criada automaticamente pelo `UploadService` no primeiro
envio de foto.

**Credenciais padrão:** `admin@dflg.com` / `admin123`

---

## Testes executados

Todos os cenários foram verificados na aplicação rodando no XAMPP (Apache + MySQL), com o
banco recriado a partir do `script.sql` atualizado.

### Gamificação

| Cenário | Resultado |
| --- | --- |
| Login de usuário novo | +5 XP de `acesso_diario`, sequência em 1 |
| Primeiro registro financeiro do dia | +10 XP de `registro_financeiro` |
| Segundo e terceiro registros no mesmo dia (RN07) | Nenhum XP adicional |
| Aporte que completa a meta (RN04) | +50 XP de `meta_concluida`, `xp_concedido = 1`, mensagem na tela |
| Histórico de XP | Três linhas datadas, uma por origem |
| Progresso de nível no perfil | "Faltam 35 XP para o nível 2" com 65 XP acumulados |

### Rankings — RN10

Cenário: usuário **gab** com 500 XP ganhos há 60 dias (515 no total) e **maria** com 200 XP
ganhos hoje (215 no total).

| Período | Resultado |
| --- | --- |
| Geral | 1º gab (515 XP), 2º maria (215 XP) |
| Mensal | 1º maria (215 XP), 2º gab (15 XP) |
| Semanal | 1º maria (215 XP), 2º gab (15 XP) |

O XP antigo do gab deixa de contar nos períodos curtos — exatamente o comportamento exigido
pela regra.

### Perfil

| Cenário | Resultado |
| --- | --- |
| Editar nome e nickname | Persistido; navbar atualizada |
| Trocar senha com a senha atual errada | Recusado com mensagem |
| Trocar senha corretamente | Login com a senha nova funciona |
| Desativar a visibilidade no ranking | Usuário some da listagem e recebe aviso na tela |

### Dashboard e relatórios

Com R$ 3.000,00 de receitas e R$ 620,00 de despesas no mês:

| Indicador | Dashboard | Relatórios | Conferência SQL |
| --- | --- | --- | --- |
| Saldo total | R$ 2.380,00 | — | R$ 2.380,00 |
| Saldo do mês | R$ 2.380,00 | R$ 2.380,00 | R$ 2.380,00 |
| Receitas / despesas do mês | +3.000,00 / -620,00 | R$ 3.000,00 / R$ 620,00 | conferido |
| Saldo do ano | — | R$ 2.380,00 | conferido |

### Orçamento — RN12

Limite de R$ 500,00 em Alimentação:

| Gasto | Percentual | Resultado |
| --- | --- | --- |
| R$ 420,00 | 84% | Alerta amarelo: "você já usou 84% do limite mensal" |
| R$ 620,00 | 124% | Alerta vermelho no dashboard e "Limite ultrapassado em R$ 120,00" na tela de orçamento |

### Calculadora — RF10

Simulação de R$ 1.000,00 iniciais, R$ 300,00 por mês, 1% ao mês, 120 meses:

| Indicador | Sistema | Conferência independente |
| --- | --- | --- |
| Valor final | R$ 72.311,99 | 72311.99 |
| Total investido | R$ 37.000,00 | 37000.00 |
| Juros ganhos | R$ 35.311,99 | 35311.99 |

Os valores foram conferidos contra um script PHP à parte reproduzindo o mesmo laço.

### Parcelamentos — RF18

Parcelamento de R$ 1.200,00 em 12x com 3 parcelas pagas:

| Indicador | Resultado |
| --- | --- |
| Ativos | 1 |
| Total no mês | R$ 100,00 |
| Total pago | R$ 300,00 |
| Total gasto | R$ 1.200,00 |

### Categorias — RF16

| Cenário | Resultado |
| --- | --- |
| Criar categoria | Gravada com nome, ícone e tipo |
| Criar categoria com nome repetido no mesmo tipo | Recusada |
| Editar categoria | Persistida |
| Excluir categoria sem lançamentos | Permitida |
| Excluir categoria com lançamentos | Recusada, categoria preservada |

### Interface e acesso

| Cenário | Resultado |
| --- | --- |
| `/`, `/login`, `/cadastrar` sem sessão | HTTP 200 |
| `/` com sessão ativa | HTTP 302 para `/dashboard` |
| 10 telas do usuário comum | HTTP 200, HTML íntegro, script de tema presente |
| `/admin`, `/categorias` como usuário comum | HTTP 302 para `/login` |
| `tema.js` e `style.css` | HTTP 200; variáveis do tema escuro presentes |
| Botão de tema | Presente nas telas internas, na home, no login e no cadastro |

### Regressão da V2

| Cenário | Resultado |
| --- | --- |
| RN09 — excluir a própria conta como único admin | Recusado |
| RF02 — login de conta bloqueada | Recusado com mensagem |
| RN03 — quebra de sequência de 7 dias | Aviso exibido, sequência reiniciada |
| RN07 — dois registros no mesmo dia | XP concedido uma única vez |

Todos os 74 arquivos PHP do projeto foram validados com `php -l`, sem erros de sintaxe.
