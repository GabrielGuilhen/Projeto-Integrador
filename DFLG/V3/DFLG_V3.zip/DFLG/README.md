# DFLG Investments

Sistema web de gestão financeira pessoal com gamificação, desenvolvido para o Projeto Integrador
do curso TDS (IFPR). Construído sobre o framework didático do `projeto_integrador-main`
(MVC + Service + Repository, roteamento centralizado, autoload por namespace e PDO com
consultas preparadas).

## Funcionalidades

- **Finanças** — receitas e despesas com categorias e filtros, parcelamentos com indicadores
  de total pago e em aberto, e orçamento mensal por categoria com alerta de estouro
- **Metas** — cadastro por tipo (economizar, comprar, investir), aportes e acompanhamento de
  progresso até o prazo
- **Gamificação** — XP por acesso diário, registro financeiro e meta concluída; níveis,
  sequência de acesso (streak) e rankings geral, mensal e semanal
- **Dashboard** — saldo total e do mês, total economizado, evolução dos últimos 6 meses e
  composição dos gastos
- **Relatórios** — comparativos mensais e anuais, com despesas por categoria
- **Calculadora** — projeção de investimentos com juros compostos e aportes mensais
- **Perfil** — dados, foto, troca de senha e visibilidade no ranking
- **Administração** — gestão de usuários (edição, bloqueio, exclusão), painel de indicadores
  e CRUD de categorias
- **Interface** — responsiva, com modo claro e modo escuro

A evolução do sistema está documentada em [`DFLG_V2.md`](DFLG_V2.md) e
[`DFLG_V3.md`](DFLG_V3.md).

---

## Como executar

O projeto roda tanto no Apache (XAMPP) quanto no servidor embutido do PHP. **A única
configuração que muda entre os dois ambientes é a constante `URL_BASE`**, em
`app/config/Config.php`.

### Opção 1 — Apache / XAMPP (recomendado)

1. Coloque a pasta do projeto dentro de `htdocs`.
2. Em `app/config/Config.php`, deixe a `URL_BASE` apontando para a subpasta onde o projeto está:

   ```php
   define('URL_BASE', 'http://localhost/IFPR/ProjetoIntegrador/DFLG');
   ```

   Se você colocou o projeto direto em `htdocs/DFLG`, use `http://localhost/DFLG`.
   Se o seu Apache usa outra porta, inclua-a: `http://localhost:8080/DFLG`.
3. Garanta que o módulo de reescrita do Apache está ativo (no `httpd.conf`, a linha
   `LoadModule rewrite_module modules/mod_rewrite.so` não pode estar comentada) e que
   o `AllowOverride All` está habilitado para o diretório `htdocs`.
4. Inicie o **Apache** e o **MySQL** pelo painel do XAMPP.
5. Acesse a `URL_BASE` no navegador.

Os arquivos `.htaccess` da raiz e da pasta `public/` cuidam do redirecionamento, e o método
`run()` do `app/core/Router.php` detecta automaticamente a subpasta — não é necessário
digitar `/public` na barra de endereços.

### Opção 2 — Servidor embutido do PHP

1. Em `app/config/Config.php`, troque a `URL_BASE` para:

   ```php
   define('URL_BASE', 'http://localhost:8080');
   ```

2. Na raiz do projeto, execute:

   ```bash
   php -S localhost:8080 -t public
   ```

3. Acesse `http://localhost:8080`.

---

## Banco de dados

As credenciais ficam em `app/config/Config.php`:

```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'db_dflg_investments');
define('DB_USER', 'root');
define('DB_PASS', '');
```

Não é preciso criar o banco manualmente. No primeiro acesso, a `ConnectionFactory` detecta
que o banco não existe e aciona o `DatabaseInitializer`, que cria o schema e executa o
`app/database/scripts/script.sql` (tabelas + usuário administrador padrão + categorias).

Para recriar o banco do zero depois de alterar o `script.sql`:

```sql
DROP DATABASE IF EXISTS db_dflg_investments;
```

E recarregue a página.

### Acesso padrão

| E-mail | Senha |
| --- | --- |
| `admin@dflg.com` | `admin123` |

---

## Estrutura

```
app/
  config/       Config.php (URL_BASE, banco, uploads, sessão)
  controllers/  Recebem a requisição, validam o formulário e devolvem a View
  core/         Router, Controller base, Autoload
  database/     ConnectionFactory, DatabaseInitializer e script.sql
  helpers/      Validador de formulários
  models/       Entidades hidratadas por arrayParaObjeto()
  repositories/ SQL isolado, sempre com prepare/bindValue
  services/     Regras de negócio
  views/        Telas em Bootstrap 5 (+ partials/ com header e footer)
public/
  index.php     Front Controller: registra as rotas e executa o Router
  assets/css/   style.css com as variáveis dos temas claro e escuro
  assets/js/    tema.js (alternância de tema)
  assets/uploads/  Fotos de perfil enviadas pelos usuários
```

---

## Problemas comuns

**Erro 404 "Rota não encontrada" em todas as páginas**
O `mod_rewrite` provavelmente está desativado, ou o `AllowOverride` está como `None`.
Confira o `httpd.conf` e reinicie o Apache.

**Links levam para o endereço errado**
A `URL_BASE` não corresponde ao endereço em uso. Reveja a seção "Como executar".

**Erro de sessão ao alternar entre `php -S` e Apache**
Os dois criam sessões com usuários diferentes. Limpe os cookies do site no navegador.
