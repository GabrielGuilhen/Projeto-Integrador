<?php

//Configuração do ambiente
define('DEV_ENVIRONMENT', true);

if (DEV_ENVIRONMENT == true) {
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

//Configuração do Sistema
define('APP_NAME', 'DFLG Investments');

// Ajuste a URL_BASE de acordo com o ambiente onde o projeto está sendo executado.
// Apache/XAMPP em subpasta (htdocs/IFPR/ProjetoIntegrador/DFLG):
define('URL_BASE', 'http://localhost/IFPR/ProjetoIntegrador/DFLG');
// Servidor embutido do PHP (php -S localhost:8080 -t public):
// define('URL_BASE', 'http://localhost:8080');

define('URL_BASE_CSS', URL_BASE . '/assets/css');
define('URL_BASE_UPLOADS', URL_BASE . '/assets/uploads');

define('UPLOAD_PATH', __DIR__ . '/../../public/assets/uploads');

//Configurações do Banco de dados
define('DB_HOST', 'localhost');
define('DB_NAME', 'db_dflg_investments');

define('DB_USER', 'root');
define('DB_PASS', '');
