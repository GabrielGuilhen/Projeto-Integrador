<?php

namespace app\controllers;

use app\core\Controller;
use app\helpers\Validador;
use app\models\Usuario;
use app\services\AdminService;
use app\services\UsuarioService;

class AdminController extends Controller
{
    private AdminService $adminService;
    private UsuarioService $usuarioService;

    public function __construct()
    {
        $this->adminService = new AdminService();
        $this->usuarioService = new UsuarioService();
    }

    /**
     * RF05: painel de indicadores da plataforma.
     */
    public function index()
    {
        $this->adminRequired();

        $data['indicadores'] = $this->adminService->getIndicadores();
        $data['distribuicaoNiveis'] = $this->adminService->getDistribuicaoNiveis();
        $data['maioresStreaks'] = $this->adminService->getMaioresStreaks();

        $this->view('admin/admin_dashboard', $data);
    }

    /**
     * RF02: listagem de usuários com o controle administrativo de contas.
     */
    public function listarUsuarios()
    {
        $this->adminRequired();

        $busca = filter_input(INPUT_GET, 'busca', FILTER_SANITIZE_SPECIAL_CHARS);

        $data['lista'] = $this->usuarioService->getUsuarios($busca);
        $data['busca'] = $busca;
        $data['usuarioLogadoId'] = $this->getUsuarioLogadoId();

        if (isset($_SESSION['flash_admin_erro'])) {
            $data['erros'] = $_SESSION['flash_admin_erro'];
            unset($_SESSION['flash_admin_erro']);
        }

        if (isset($_SESSION['flash_admin_sucesso'])) {
            $data['sucesso'] = $_SESSION['flash_admin_sucesso'];
            unset($_SESSION['flash_admin_sucesso']);
        }

        $this->view('admin/admin_usuarios_list', $data);
    }

    public function editar()
    {
        $this->adminRequired();

        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/admin/usuarios');
        }

        $usuario = $this->usuarioService->getUsuarioById((int) $_GET['id']);

        if (!$usuario) {
            $this->redirect(URL_BASE . '/admin/usuarios');
        }

        $data['usuario'] = $usuario;

        $this->view('admin/admin_usuarios_edit', $data);
    }

    public function atualizar()
    {
        $this->adminRequired();

        $validador = new Validador();

        $id = $_POST['id'] ?? 0;
        $nome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_SPECIAL_CHARS);
        $nickname = filter_input(INPUT_POST, 'nickname', FILTER_SANITIZE_SPECIAL_CHARS);
        $email = $_POST['email'] ?? '';
        $dataNascimento = $_POST['dataNascimento'] ?? '';
        $perfil = $_POST['perfil'] ?? 'comum';
        $status = $_POST['status'] ?? 'ativo';

        $validador->obrigatorio('nome', $nome);
        $validador->obrigatorio('nickname', $nickname);
        $validador->obrigatorio('email', $email);
        $validador->obrigatorio('dataNascimento', $dataNascimento);

        // A senha não é alterada por aqui, então é reenviada vazia ao Model
        $usuario = new Usuario(
            (int) $id,
            $nome,
            $nickname,
            $email,
            '',
            $dataNascimento,
            $perfil,
            $status
        );

        if ($validador->temErros()) {

            $data['usuario'] = $usuario;
            $data['erros'] = $validador->getErros();

            $this->view('admin/admin_usuarios_edit', $data);

            return;
        }

        if ($this->usuarioService->atualizar($usuario)) {

            $_SESSION['flash_admin_sucesso'] = "Usuário atualizado com sucesso.";

            $this->redirect(URL_BASE . '/admin/usuarios');
        } else {

            $data['usuario'] = $usuario;
            $data['erros'] = $this->usuarioService->getErros();

            $this->view('admin/admin_usuarios_edit', $data);
        }
    }

    public function bloquear()
    {
        $this->adminRequired();

        if (isset($_GET['id'])) {

            if ($this->usuarioService->bloquear((int) $_GET['id'])) {
                $_SESSION['flash_admin_sucesso'] = "Usuário bloqueado com sucesso.";
            } else {
                $_SESSION['flash_admin_erro'] = $this->usuarioService->getErros();
            }
        }

        $this->redirect(URL_BASE . '/admin/usuarios');
    }

    public function desbloquear()
    {
        $this->adminRequired();

        if (isset($_GET['id'])) {

            if ($this->usuarioService->desbloquear((int) $_GET['id'])) {
                $_SESSION['flash_admin_sucesso'] = "Usuário desbloqueado com sucesso.";
            } else {
                $_SESSION['flash_admin_erro'] = $this->usuarioService->getErros();
            }
        }

        $this->redirect(URL_BASE . '/admin/usuarios');
    }

    /**
     * RN09: a exclusão é recusada quando resta apenas um administrador ativo.
     */
    public function excluir()
    {
        $this->adminRequired();

        if (isset($_GET['id'])) {

            if ($this->usuarioService->excluir((int) $_GET['id'], $this->getUsuarioLogadoId())) {
                $_SESSION['flash_admin_sucesso'] = "Usuário excluído com sucesso.";
            } else {
                $_SESSION['flash_admin_erro'] = $this->usuarioService->getErros();
            }
        }

        $this->redirect(URL_BASE . '/admin/usuarios');
    }
}
