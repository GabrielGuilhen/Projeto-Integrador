<?php

namespace app\controllers;

use app\core\Controller;
use app\models\SimulacaoInvestimento;
use app\services\SimulacaoService;

class CalculadoraController extends Controller
{
    private SimulacaoService $service;

    public function __construct()
    {
        $this->service = new SimulacaoService();
    }

    /**
     * RF10: formulário da calculadora e simulações já salvas.
     */
    public function index()
    {
        $this->autenticacaoRequired();

        $data['salvas'] = $this->service->getSimulacoes($this->getUsuarioLogadoId());

        $this->view('calculadora/calculadora', $data);
    }

    public function calcular()
    {
        $this->autenticacaoRequired();

        $simulacao = $this->montarSimulacao();

        $data['salvas'] = $this->service->getSimulacoes($this->getUsuarioLogadoId());
        $data['simulacao'] = $simulacao;

        if (!$this->service->validar($simulacao)) {

            $data['erros'] = $this->service->getErros();

            $this->view('calculadora/calculadora', $data);

            return;
        }

        $data['evolucao'] = $this->service->calcular($simulacao);
        $data['resultado'] = $simulacao;

        $this->view('calculadora/calculadora', $data);
    }

    public function salvar()
    {
        $this->autenticacaoRequired();

        $simulacao = $this->montarSimulacao();

        if ($this->service->salvar($simulacao)) {
            $_SESSION['flash_simulacao_sucesso'] = "Simulação salva com sucesso.";

            $this->redirect(URL_BASE . '/calculadora');

            return;
        }

        $data['salvas'] = $this->service->getSimulacoes($this->getUsuarioLogadoId());
        $data['simulacao'] = $simulacao;
        $data['erros'] = $this->service->getErros();

        $this->view('calculadora/calculadora', $data);
    }

    public function excluir()
    {
        $this->autenticacaoRequired();

        if (isset($_GET['id'])) {
            $this->service->excluir((int) $_GET['id'], $this->getUsuarioLogadoId());
        }

        $this->redirect(URL_BASE . '/calculadora');
    }

    private function montarSimulacao(): SimulacaoInvestimento
    {
        $nome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_SPECIAL_CHARS);

        return new SimulacaoInvestimento(
            0,
            $this->getUsuarioLogadoId(),
            (string) $nome,
            (float) str_replace(',', '.', $_POST['valorInicial'] ?? 0),
            (float) str_replace(',', '.', $_POST['aporteMensal'] ?? 0),
            (float) str_replace(',', '.', $_POST['taxaMensal'] ?? 0),
            (int) ($_POST['periodoMeses'] ?? 0)
        );
    }
}
