<?php

namespace app\controllers;

use app\core\Controller;
use app\helpers\Validador;
use app\models\Categoria;
use app\services\CategoriaService;

class CategoriaController extends Controller
{
    private CategoriaService $service;

    public function __construct()
    {
        $this->service = new CategoriaService();
    }

    // RF16: gestão das categorias, restrita ao administrador

    public function listarTodas()
    {
        $this->adminRequired();

        $data['lista'] = $this->service->getCategorias();

        if (isset($_SESSION['flash_categoria_sucesso'])) {
            $data['sucesso'] = $_SESSION['flash_categoria_sucesso'];
            unset($_SESSION['flash_categoria_sucesso']);
        }

        if (isset($_SESSION['flash_categoria_erro'])) {
            $data['erros'] = $_SESSION['flash_categoria_erro'];
            unset($_SESSION['flash_categoria_erro']);
        }

        $this->view('categorias/categorias_list', $data);
    }

    public function criar()
    {
        $this->adminRequired();

        $this->view('categorias/categorias_create');
    }

    public function salvar()
    {
        $this->adminRequired();

        $validador = new Validador();

        $nome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_SPECIAL_CHARS);
        $icone = filter_input(INPUT_POST, 'icone', FILTER_SANITIZE_SPECIAL_CHARS);
        $tipo = $_POST['tipo'] ?? 'despesa';

        $validador->obrigatorio('nome', $nome);

        $categoria = new Categoria(0, (string) $nome, $icone ?: null, $tipo);

        if ($validador->temErros()) {

            $data['categoria'] = $categoria;
            $data['erros'] = $validador->getErros();

            $this->view('categorias/categorias_create', $data);

            return;
        }

        if ($this->service->saveCategoria($categoria)) {

            $_SESSION['flash_categoria_sucesso'] = "Categoria criada com sucesso.";

            $this->redirect(URL_BASE . '/categorias');
        } else {

            $data['categoria'] = $categoria;
            $data['erros'] = $this->service->getErros();

            $this->view('categorias/categorias_create', $data);
        }
    }

    public function editar()
    {
        $this->adminRequired();

        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/categorias');
        }

        $categoria = $this->service->getCategoria((int) $_GET['id']);

        if (!$categoria) {
            $this->redirect(URL_BASE . '/categorias');
        }

        $data['categoria'] = $categoria;

        $this->view('categorias/categorias_edit', $data);
    }

    public function atualizar()
    {
        $this->adminRequired();

        $validador = new Validador();

        $id = (int) ($_POST['id'] ?? 0);
        $nome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_SPECIAL_CHARS);
        $icone = filter_input(INPUT_POST, 'icone', FILTER_SANITIZE_SPECIAL_CHARS);
        $tipo = $_POST['tipo'] ?? 'despesa';

        $validador->obrigatorio('nome', $nome);

        $categoria = new Categoria($id, (string) $nome, $icone ?: null, $tipo);

        if ($validador->temErros()) {

            $data['categoria'] = $categoria;
            $data['erros'] = $validador->getErros();

            $this->view('categorias/categorias_edit', $data);

            return;
        }

        if ($this->service->updateCategoria($categoria)) {

            $_SESSION['flash_categoria_sucesso'] = "Categoria atualizada com sucesso.";

            $this->redirect(URL_BASE . '/categorias');
        } else {

            $data['categoria'] = $categoria;
            $data['erros'] = $this->service->getErros();

            $this->view('categorias/categorias_edit', $data);
        }
    }

    public function excluir()
    {
        $this->adminRequired();

        if (isset($_GET['id'])) {

            if ($this->service->deleteCategoria((int) $_GET['id'])) {
                $_SESSION['flash_categoria_sucesso'] = "Categoria excluída com sucesso.";
            } else {
                $_SESSION['flash_categoria_erro'] = $this->service->getErros();
            }
        }

        $this->redirect(URL_BASE . '/categorias');
    }

    // RN12: orçamento mensal por categoria, definido por cada usuário

    public function orcamentos()
    {
        $this->autenticacaoRequired();

        $data['orcamentos'] = $this->service->getOrcamentos($this->getUsuarioLogadoId());
        $data['categorias'] = $this->service->getCategoriasPorTipo('despesa');

        if (isset($_SESSION['flash_orcamento_sucesso'])) {
            $data['sucesso'] = $_SESSION['flash_orcamento_sucesso'];
            unset($_SESSION['flash_orcamento_sucesso']);
        }

        if (isset($_SESSION['flash_orcamento_erro'])) {
            $data['erros'] = $_SESSION['flash_orcamento_erro'];
            unset($_SESSION['flash_orcamento_erro']);
        }

        $this->view('categorias/orcamentos_list', $data);
    }

    public function salvarOrcamento()
    {
        $this->autenticacaoRequired();

        $categoriaId = (int) ($_POST['categoriaId'] ?? 0);
        $limite = (float) str_replace(',', '.', $_POST['limiteMensal'] ?? 0);

        if ($this->service->salvarOrcamento($this->getUsuarioLogadoId(), $categoriaId, $limite)) {
            $_SESSION['flash_orcamento_sucesso'] = "Limite mensal salvo com sucesso.";
        } else {
            $_SESSION['flash_orcamento_erro'] = $this->service->getErros();
        }

        $this->redirect(URL_BASE . '/orcamentos');
    }

    public function excluirOrcamento()
    {
        $this->autenticacaoRequired();

        if (isset($_GET['categoriaId'])) {
            $this->service->excluirOrcamento($this->getUsuarioLogadoId(), (int) $_GET['categoriaId']);
            $_SESSION['flash_orcamento_sucesso'] = "Limite removido.";
        }

        $this->redirect(URL_BASE . '/orcamentos');
    }
}
