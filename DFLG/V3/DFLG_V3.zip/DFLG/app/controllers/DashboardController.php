<?php

namespace app\controllers;

use app\core\Controller;
use app\services\CategoriaService;
use app\services\GamificacaoService;
use app\services\MetaService;
use app\services\ParcelamentoService;
use app\services\RankingService;
use app\services\TransacaoService;

class DashboardController extends Controller
{
    private GamificacaoService $gamificacaoService;
    private TransacaoService $transacaoService;
    private MetaService $metaService;
    private ParcelamentoService $parcelamentoService;
    private RankingService $rankingService;
    private CategoriaService $categoriaService;

    public function __construct()
    {
        $this->gamificacaoService = new GamificacaoService();
        $this->transacaoService = new TransacaoService();
        $this->metaService = new MetaService();
        $this->parcelamentoService = new ParcelamentoService();
        $this->rankingService = new RankingService();
        $this->categoriaService = new CategoriaService();
    }

    /**
     * RF07: resumo financeiro geral com dados reais dos repositórios.
     */
    public function index()
    {
        $this->autenticacaoRequired();

        $usuario = $_SESSION['usuario_logado'];
        $usuarioId = $usuario->getId();

        $ano = (int) date('Y');
        $mes = (int) date('n');

        $data['usuario'] = $usuario;
        $data['gamificacao'] = $this->gamificacaoService->getGamificacao($usuarioId);
        $data['posicao'] = $this->rankingService->getPosicaoUsuario($usuarioId);

        if ($data['gamificacao']) {
            $xpTotal = $data['gamificacao']->getXpTotal();
            $data['progressoNivel'] = $this->gamificacaoService->getProgressoNivel($xpTotal);
            $data['xpProximoNivel'] = $this->gamificacaoService->getXpParaProximoNivel($xpTotal);
        }

        // Resumo financeiro
        $data['saldoTotal'] = $this->transacaoService->getSaldo($usuarioId);
        $data['saldoMes'] = $this->transacaoService->getSaldoDoMes($usuarioId, $ano, $mes);
        $data['receitasMes'] = $this->transacaoService->getTotalPorTipoNoMes($usuarioId, 'receita', $ano, $mes);
        $data['despesasMes'] = $this->transacaoService->getTotalPorTipoNoMes($usuarioId, 'despesa', $ano, $mes);
        $data['totalEconomizado'] = $this->metaService->getTotalGuardado($usuarioId);

        // Metas em andamento e concluídas
        $data['metas'] = $this->metaService->getMetas($usuarioId);
        $data['metasConcluidas'] = $this->metaService->contarMetas($usuarioId, true);

        // Evolução financeira e composição dos gastos
        $data['evolucao'] = $this->transacaoService->getEvolucaoMensal($usuarioId);
        $data['gastoPorCategoria'] = $this->transacaoService->getGastoPorCategoria($usuarioId, $ano, $mes);

        // Parcelamentos
        $data['totaisParcelas'] = $this->parcelamentoService->getTotais($usuarioId);

        // RN12: alertas de categorias que estouraram ou estão perto do limite
        $data['alertasCategoria'] = $this->categoriaService->getAlertasOrcamento($usuarioId);

        $this->view('dashboard/dashboard', $data);
    }
}
