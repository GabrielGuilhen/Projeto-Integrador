<?php

namespace app\controllers;

use app\core\Controller;

/**
 * RF15/RN11: página inicial pública. Usuários já autenticados vão
 * direto para o dashboard.
 */
class HomeController extends Controller
{
    public function index()
    {
        if (isset($_SESSION['usuario_logado'])) {
            $this->redirect(URL_BASE . '/dashboard');
        }

        $this->view('home/home');
    }
}
