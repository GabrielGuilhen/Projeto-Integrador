<?php

namespace app\controllers;

use app\core\Controller;
use app\helpers\Validador;
use app\models\Meta;
use app\services\GamificacaoService;
use app\services\MetaService;

class MetaController extends Controller
{
    private MetaService $service;

    public function __construct()
    {
        $this->service = new MetaService();
    }

    public function listarTodas()
    {
        $this->autenticacaoRequired();

        $data['lista'] = $this->service->getMetas($this->getUsuarioLogadoId());

        if (isset($_SESSION['flash_meta_sucesso'])) {
            $data['sucesso'] = $_SESSION['flash_meta_sucesso'];
            unset($_SESSION['flash_meta_sucesso']);
        }

        if (isset($_SESSION['flash_meta_erro'])) {
            $data['erros'] = $_SESSION['flash_meta_erro'];
            unset($_SESSION['flash_meta_erro']);
        }

        $this->view('metas/metas_list', $data);
    }

    public function criar()
    {
        $this->autenticacaoRequired();

        $this->view('metas/metas_create');
    }

    public function salvar()
    {
        $this->autenticacaoRequired();

        $validador = new Validador();

        $nomeMeta = filter_input(INPUT_POST, 'nomeMeta', FILTER_SANITIZE_SPECIAL_CHARS);
        $tipoMeta = $_POST['tipoMeta'] ?? 'economizar';
        $valorAlvo = $_POST['valorAlvo'] ?? '';
        $valorAtual = $_POST['valorAtual'] ?? 0;
        $dataLimite = $_POST['dataLimite'] ?? '';

        $validador->obrigatorio('nomeMeta', $nomeMeta);
        $validador->obrigatorio('valorAlvo', $valorAlvo);
        $validador->obrigatorio('dataLimite', $dataLimite);

        if ($validador->temErros()) {

            $data['meta'] = $_POST;
            $data['erros'] = $validador->getErros();

            $this->view('metas/metas_create', $data);

            return;
        }

        $meta = new Meta(
            0,
            $this->getUsuarioLogadoId(),
            $nomeMeta,
            $tipoMeta,
            (float) $valorAlvo,
            (float) $valorAtual,
            $dataLimite
        );

        if ($this->service->saveMeta($meta)) {
            $this->redirect(URL_BASE . '/metas');
        } else {

            $data['meta'] = $_POST;
            $data['erros'] = $this->service->getErros();

            $this->view('metas/metas_create', $data);
        }
    }

    public function editar()
    {
        $this->autenticacaoRequired();

        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/metas');
        }

        $meta = $this->service->getMeta((int) $_GET['id'], $this->getUsuarioLogadoId());

        if (!$meta) {
            $this->redirect(URL_BASE . '/metas');
        }

        $data['meta'] = $meta;

        $this->view('metas/metas_edit', $data);
    }

    public function atualizar()
    {
        $this->autenticacaoRequired();

        $validador = new Validador();

        $id = $_POST['id'] ?? 0;
        $nomeMeta = filter_input(INPUT_POST, 'nomeMeta', FILTER_SANITIZE_SPECIAL_CHARS);
        $tipoMeta = $_POST['tipoMeta'] ?? 'economizar';
        $valorAlvo = $_POST['valorAlvo'] ?? '';
        $valorAtual = $_POST['valorAtual'] ?? 0;
        $dataLimite = $_POST['dataLimite'] ?? '';

        $validador->obrigatorio('nomeMeta', $nomeMeta);
        $validador->obrigatorio('valorAlvo', $valorAlvo);
        $validador->obrigatorio('dataLimite', $dataLimite);

        $meta = new Meta(
            (int) $id,
            $this->getUsuarioLogadoId(),
            $nomeMeta,
            $tipoMeta,
            (float) $valorAlvo,
            (float) $valorAtual,
            $dataLimite
        );

        if ($validador->temErros()) {

            $data['meta'] = $meta;
            $data['erros'] = $validador->getErros();

            $this->view('metas/metas_edit', $data);

            return;
        }

        if ($this->service->updateMeta($meta)) {
            $this->redirect(URL_BASE . '/metas');
        } else {

            $data['meta'] = $meta;
            $data['erros'] = $this->service->getErros();

            $this->view('metas/metas_edit', $data);
        }
    }

    /**
     * RF19: aporte em uma meta já cadastrada.
     */
    public function aportar()
    {
        $this->autenticacaoRequired();

        $id = (int) ($_POST['id'] ?? 0);
        $valor = (float) str_replace(',', '.', $_POST['valor'] ?? 0);

        if ($this->service->adicionarValor($id, $this->getUsuarioLogadoId(), $valor)) {

            $_SESSION['flash_meta_sucesso'] = $this->service->metaConcluidaAgora()
                ? "Meta concluída! Você ganhou " . GamificacaoService::XP_META_CONCLUIDA . " XP."
                : "Aporte registrado com sucesso.";
        } else {
            $_SESSION['flash_meta_erro'] = $this->service->getErros();
        }

        $this->redirect(URL_BASE . '/metas');
    }

    public function excluir()
    {
        $this->autenticacaoRequired();

        if (isset($_GET['id'])) {
            $this->service->deleteMeta((int) $_GET['id'], $this->getUsuarioLogadoId());
        }

        $this->redirect(URL_BASE . '/metas');
    }
}
