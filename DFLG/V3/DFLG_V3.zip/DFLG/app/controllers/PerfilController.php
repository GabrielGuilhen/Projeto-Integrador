<?php

namespace app\controllers;

use app\core\Controller;
use app\helpers\Validador;
use app\models\Usuario;
use app\services\GamificacaoService;
use app\services\MetaService;
use app\services\RankingService;
use app\services\UploadService;
use app\services\UsuarioService;
use Exception;

class PerfilController extends Controller
{
    private UsuarioService $usuarioService;
    private GamificacaoService $gamificacaoService;
    private RankingService $rankingService;
    private MetaService $metaService;

    public function __construct()
    {
        $this->usuarioService = new UsuarioService();
        $this->gamificacaoService = new GamificacaoService();
        $this->rankingService = new RankingService();
        $this->metaService = new MetaService();
    }

    /**
     * RF14: visualização do perfil com nível, XP, sequência e posição no ranking.
     */
    public function index()
    {
        $this->autenticacaoRequired();

        $usuarioId = $this->getUsuarioLogadoId();

        $data['usuario'] = $this->usuarioService->getUsuarioById($usuarioId);
        $data['gamificacao'] = $this->gamificacaoService->getGamificacao($usuarioId);
        $data['posicao'] = $this->rankingService->getPosicaoUsuario($usuarioId);
        $data['historico'] = $this->gamificacaoService->getHistoricoRecente($usuarioId);
        $data['totalMetas'] = $this->metaService->contarMetas($usuarioId);
        $data['metasConcluidas'] = $this->metaService->contarMetas($usuarioId, true);

        if ($data['gamificacao']) {
            $xpTotal = $data['gamificacao']->getXpTotal();
            $data['progressoNivel'] = $this->gamificacaoService->getProgressoNivel($xpTotal);
            $data['xpProximoNivel'] = $this->gamificacaoService->getXpParaProximoNivel($xpTotal);
        }

        $data['sucesso'] = $this->consumirFlash('flash_perfil_sucesso');
        $data['erros'] = $this->consumirFlash('flash_perfil_erro');

        $this->view('perfil/perfil_show', $data);
    }

    public function editar()
    {
        $this->autenticacaoRequired();

        $data['usuario'] = $this->usuarioService->getUsuarioById($this->getUsuarioLogadoId());

        $this->view('perfil/perfil_edit', $data);
    }

    public function atualizar()
    {
        $this->autenticacaoRequired();

        $usuarioId = $this->getUsuarioLogadoId();

        $validador = new Validador();

        $nome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_SPECIAL_CHARS);
        $nickname = filter_input(INPUT_POST, 'nickname', FILTER_SANITIZE_SPECIAL_CHARS);
        $email = $_POST['email'] ?? '';
        $dataNascimento = $_POST['dataNascimento'] ?? '';

        $validador->obrigatorio('nome', $nome);
        $validador->obrigatorio('nickname', $nickname);
        $validador->obrigatorio('email', $email);
        $validador->obrigatorio('dataNascimento', $dataNascimento);

        $usuarioAtual = $this->usuarioService->getUsuarioById($usuarioId);

        $usuario = new Usuario(
            $usuarioId,
            $nome,
            $nickname,
            $email,
            '',
            $dataNascimento,
            $usuarioAtual->getPerfil(),
            $usuarioAtual->getStatus(),
            $usuarioAtual->getFoto()
        );

        if ($validador->temErros()) {

            $data['usuario'] = $usuario;
            $data['erros'] = $validador->getErros();

            $this->view('perfil/perfil_edit', $data);

            return;
        }

        if (!$this->usuarioService->atualizarPerfil($usuario)) {

            $data['usuario'] = $usuario;
            $data['erros'] = $this->usuarioService->getErros();

            $this->view('perfil/perfil_edit', $data);

            return;
        }

        // RF04: troca opcional da foto de perfil
        if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {

            $uploadService = new UploadService();

            try {
                $novaFoto = $uploadService->upload($_FILES['foto']);

                $uploadService->remover($usuarioAtual->getFoto());
                $this->usuarioService->atualizarFoto($usuarioId, $novaFoto);

            } catch (Exception $e) {

                $data['usuario'] = $usuario;
                $data['erros']['foto'] = $e->getMessage();

                $this->view('perfil/perfil_edit', $data);

                return;
            }
        }

        $this->atualizarSessao($usuarioId);

        $_SESSION['flash_perfil_sucesso'] = "Perfil atualizado com sucesso.";

        $this->redirect(URL_BASE . '/perfil');
    }

    public function alterarSenha()
    {
        $this->autenticacaoRequired();

        $senhaAtual = $_POST['senhaAtual'] ?? '';
        $novaSenha = $_POST['novaSenha'] ?? '';
        $confirmacao = $_POST['confirmacao'] ?? '';

        $alterada = $this->usuarioService->alterarSenha(
            $this->getUsuarioLogadoId(),
            $senhaAtual,
            $novaSenha,
            $confirmacao
        );

        if ($alterada) {
            $_SESSION['flash_perfil_sucesso'] = "Senha alterada com sucesso.";
        } else {
            $_SESSION['flash_perfil_erro'] = $this->usuarioService->getErros();
        }

        $this->redirect(URL_BASE . '/perfil');
    }

    /**
     * RF04: o usuário decide se aparece ou não no ranking.
     */
    public function alterarVisibilidade()
    {
        $this->autenticacaoRequired();

        $visivel = isset($_POST['visibilidadeRanking']);

        $this->usuarioService->alterarVisibilidadeRanking($this->getUsuarioLogadoId(), $visivel);

        $_SESSION['flash_perfil_sucesso'] = $visivel
            ? "Agora você aparece no ranking."
            : "Seu perfil foi ocultado do ranking.";

        $this->redirect(URL_BASE . '/perfil');
    }

    /**
     * Recarrega o objeto da sessão para que a navbar reflita os dados novos.
     */
    private function atualizarSessao(int $usuarioId): void
    {
        $atualizado = $this->usuarioService->getUsuarioById($usuarioId);

        if ($atualizado) {
            $_SESSION['usuario_logado'] = $atualizado;
        }
    }

    private function consumirFlash(string $chave)
    {
        if (!isset($_SESSION[$chave])) {
            return null;
        }

        $valor = $_SESSION[$chave];
        unset($_SESSION[$chave]);

        return $valor;
    }
}
