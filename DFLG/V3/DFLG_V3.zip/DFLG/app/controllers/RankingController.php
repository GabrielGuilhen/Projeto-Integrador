<?php

namespace app\controllers;

use app\core\Controller;
use app\services\RankingService;

class RankingController extends Controller
{
    private RankingService $service;

    public function __construct()
    {
        $this->service = new RankingService();
    }

    /**
     * RF12: listagem dos usuários por progresso, nos três períodos da RN10.
     */
    public function index()
    {
        $this->autenticacaoRequired();

        $periodos = $this->service->getPeriodosDisponiveis();

        $periodo = $_GET['periodo'] ?? 'geral';

        if (!array_key_exists($periodo, $periodos)) {
            $periodo = 'geral';
        }

        $data['periodo'] = $periodo;
        $data['periodos'] = $periodos;
        $data['lista'] = $this->service->getRanking($periodo);
        $data['usuarioLogadoId'] = $this->getUsuarioLogadoId();
        $data['minhaPosicao'] = $this->service->getPosicaoUsuario($this->getUsuarioLogadoId(), $periodo);

        $this->view('ranking/ranking_list', $data);
    }
}
