<?php

namespace app\controllers;

use app\core\Controller;
use app\services\TransacaoService;

/**
 * RF13: relatórios financeiros mensais e anuais.
 */
class RelatorioController extends Controller
{
    private TransacaoService $service;

    public function __construct()
    {
        $this->service = new TransacaoService();
    }

    public function index()
    {
        $this->autenticacaoRequired();

        $usuarioId = $this->getUsuarioLogadoId();

        $ano = (int) ($_GET['ano'] ?? date('Y'));
        $mes = (int) ($_GET['mes'] ?? date('n'));

        if ($mes < 1 || $mes > 12) {
            $mes = (int) date('n');
        }

        $data['ano'] = $ano;
        $data['mes'] = $mes;
        $data['anosDisponiveis'] = $this->getAnos($usuarioId, $ano);

        // Relatório mensal
        $data['receitasMes'] = $this->service->getTotalPorTipoNoMes($usuarioId, 'receita', $ano, $mes);
        $data['despesasMes'] = $this->service->getTotalPorTipoNoMes($usuarioId, 'despesa', $ano, $mes);
        $data['saldoMes'] = $data['receitasMes'] - $data['despesasMes'];
        $data['gastoPorCategoria'] = $this->service->getGastoPorCategoria($usuarioId, $ano, $mes);

        // Relatório anual
        $data['resumoAnual'] = $this->service->getResumoAnual($usuarioId, $ano);

        $receitasAno = 0.0;
        $despesasAno = 0.0;

        foreach ($data['resumoAnual'] as $linha) {
            $receitasAno += (float) $linha['receitas'];
            $despesasAno += (float) $linha['despesas'];
        }

        $data['receitasAno'] = $receitasAno;
        $data['despesasAno'] = $despesasAno;
        $data['saldoAno'] = $receitasAno - $despesasAno;

        $this->view('relatorios/relatorios', $data);
    }

    /**
     * Garante que o ano selecionado apareça na lista, mesmo sem registros.
     */
    private function getAnos(int $usuarioId, int $anoSelecionado): array
    {
        $anos = [];

        foreach ($this->service->getAnosComRegistros($usuarioId) as $linha) {
            $anos[] = (int) $linha['ano'];
        }

        if (!in_array($anoSelecionado, $anos)) {
            $anos[] = $anoSelecionado;
        }

        $anoAtual = (int) date('Y');

        if (!in_array($anoAtual, $anos)) {
            $anos[] = $anoAtual;
        }

        rsort($anos);

        return $anos;
    }
}
