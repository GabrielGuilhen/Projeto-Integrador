CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    nickname VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(255) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    data_nascimento DATE NOT NULL,
    foto VARCHAR(255) NULL,
    status ENUM('ativo', 'bloqueado') NOT NULL DEFAULT 'ativo',
    perfil ENUM('comum', 'administrador') NOT NULL DEFAULT 'comum',
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS usuario_comum (
    usuario_id INT PRIMARY KEY,
    xp_total INT NOT NULL DEFAULT 0,
    nivel INT NOT NULL DEFAULT 1,
    streak_atual INT NOT NULL DEFAULT 0,
    maior_streak INT NOT NULL DEFAULT 0,
    data_ultimo_xp DATE NULL,
    data_ultimo_acesso DATE NULL,
    visibilidade_ranking BOOLEAN NOT NULL DEFAULT TRUE,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- RN04/RN10: histórico de ganhos de XP, necessário para os rankings por período
CREATE TABLE IF NOT EXISTS xp_historico (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    pontos INT NOT NULL,
    origem ENUM('acesso_diario', 'registro_financeiro', 'meta_concluida') NOT NULL,
    data_ganho DATE NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    INDEX idx_xp_usuario_data (usuario_id, data_ganho)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS categorias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    icone VARCHAR(50) NULL,
    tipo ENUM('receita', 'despesa') NOT NULL DEFAULT 'despesa',
    limite_orcamento DECIMAL(10,2) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS metas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    nome_meta VARCHAR(100) NOT NULL,
    tipo_meta ENUM('economizar', 'comprar', 'investir') NOT NULL DEFAULT 'economizar',
    valor_alvo DECIMAL(10,2) NOT NULL,
    valor_atual DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    data_limite DATE NOT NULL,
    xp_concedido BOOLEAN NOT NULL DEFAULT FALSE,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- RF16/RN12: limite de gastos mensais que o usuário estipula para cada categoria
CREATE TABLE IF NOT EXISTS meta_categoria (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    categoria_id INT NOT NULL,
    limite_mensal DECIMAL(10,2) NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (categoria_id) REFERENCES categorias(id) ON DELETE CASCADE,
    UNIQUE KEY uk_usuario_categoria (usuario_id, categoria_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- RF10: projeções de crescimento patrimonial salvas pelo usuário
CREATE TABLE IF NOT EXISTS simulacao_investimento (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    nome VARCHAR(100) NOT NULL,
    valor_inicial DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    aporte_mensal DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    taxa_mensal DECIMAL(6,3) NOT NULL,
    periodo_meses INT NOT NULL,
    valor_final DECIMAL(12,2) NOT NULL,
    total_investido DECIMAL(12,2) NOT NULL,
    total_juros DECIMAL(12,2) NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS registro_financeiro (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    categoria_id INT NULL,
    tipo ENUM('receita', 'despesa') NOT NULL DEFAULT 'despesa',
    valor DECIMAL(10,2) NOT NULL,
    data_registro DATE NOT NULL,
    descricao VARCHAR(255) NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (categoria_id) REFERENCES categorias(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS parcelamentos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    categoria_id INT NULL,
    descricao VARCHAR(255) NOT NULL,
    valor_total DECIMAL(10,2) NOT NULL,
    quantidade_parcelas INT NOT NULL,
    parcelas_pagas INT NOT NULL DEFAULT 0,
    data_primeira_parcela DATE NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (categoria_id) REFERENCES categorias(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO usuarios (nome, nickname, email, senha, data_nascimento, perfil)
VALUES ('Administrador', 'admin', 'admin@dflg.com', '$2y$12$Zon6XY2fKd2Ua4YIId4MC.dVB3XxTHDlK96rgDJYEnJRoXxoZ84XS', '2000-01-01', 'administrador');

-- admin@dflg.com
-- admin123

INSERT INTO categorias (nome, icone, tipo) VALUES
('Salário', 'bi-cash-coin', 'receita'),
('Freelance', 'bi-laptop', 'receita'),
('Rendimentos', 'bi-graph-up-arrow', 'receita'),
('Outras receitas', 'bi-plus-circle', 'receita'),
('Alimentação', 'bi-basket', 'despesa'),
('Moradia', 'bi-house-door', 'despesa'),
('Transporte', 'bi-bus-front', 'despesa'),
('Saúde', 'bi-heart-pulse', 'despesa'),
('Educação', 'bi-book', 'despesa'),
('Lazer', 'bi-controller', 'despesa'),
('Compras', 'bi-bag', 'despesa'),
('Contas e assinaturas', 'bi-receipt', 'despesa'),
('Outras despesas', 'bi-dash-circle', 'despesa');
