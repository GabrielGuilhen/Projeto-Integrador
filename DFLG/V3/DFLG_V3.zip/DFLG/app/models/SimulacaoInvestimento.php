<?php

namespace app\models;

/**
 * RF10: projeção de crescimento patrimonial salva pelo usuário.
 */
class SimulacaoInvestimento
{
    private int $id;
    private int $usuarioId;
    private string $nome;
    private float $valorInicial;
    private float $aporteMensal;
    private float $taxaMensal;
    private int $periodoMeses;
    private float $valorFinal;
    private float $totalInvestido;
    private float $totalJuros;
    private ?string $criadoEm;

    public function __construct(
        int $id,
        int $usuarioId,
        string $nome,
        float $valorInicial,
        float $aporteMensal,
        float $taxaMensal,
        int $periodoMeses,
        float $valorFinal = 0.0,
        float $totalInvestido = 0.0,
        float $totalJuros = 0.0,
        ?string $criadoEm = null
    ) {
        $this->id = $id;
        $this->usuarioId = $usuarioId;
        $this->nome = $nome;
        $this->valorInicial = $valorInicial;
        $this->aporteMensal = $aporteMensal;
        $this->taxaMensal = $taxaMensal;
        $this->periodoMeses = $periodoMeses;
        $this->valorFinal = $valorFinal;
        $this->totalInvestido = $totalInvestido;
        $this->totalJuros = $totalJuros;
        $this->criadoEm = $criadoEm;
    }

    public function getId(): int
    {
        return $this->id;
    }

    public function getUsuarioId(): int
    {
        return $this->usuarioId;
    }

    public function getNome(): string
    {
        return $this->nome;
    }

    public function getValorInicial(): float
    {
        return $this->valorInicial;
    }

    public function getAporteMensal(): float
    {
        return $this->aporteMensal;
    }

    public function getTaxaMensal(): float
    {
        return $this->taxaMensal;
    }

    public function getPeriodoMeses(): int
    {
        return $this->periodoMeses;
    }

    public function getValorFinal(): float
    {
        return $this->valorFinal;
    }

    public function setValorFinal(float $valorFinal): self
    {
        $this->valorFinal = $valorFinal;

        return $this;
    }

    public function getTotalInvestido(): float
    {
        return $this->totalInvestido;
    }

    public function setTotalInvestido(float $totalInvestido): self
    {
        $this->totalInvestido = $totalInvestido;

        return $this;
    }

    public function getTotalJuros(): float
    {
        return $this->totalJuros;
    }

    public function setTotalJuros(float $totalJuros): self
    {
        $this->totalJuros = $totalJuros;

        return $this;
    }

    public function getCriadoEm(): ?string
    {
        return $this->criadoEm;
    }

    /**
     * Taxa equivalente anual, exibida junto da mensal para dar contexto.
     */
    public function getTaxaAnual(): float
    {
        return round((pow(1 + $this->taxaMensal / 100, 12) - 1) * 100, 2);
    }

    public static function arrayParaObjeto(array $simulacao): self
    {
        return new self(
            $simulacao['id'],
            $simulacao['usuario_id'],
            $simulacao['nome'],
            (float) $simulacao['valor_inicial'],
            (float) $simulacao['aporte_mensal'],
            (float) $simulacao['taxa_mensal'],
            (int) $simulacao['periodo_meses'],
            (float) $simulacao['valor_final'],
            (float) $simulacao['total_investido'],
            (float) $simulacao['total_juros'],
            $simulacao['criado_em'] ?? null
        );
    }
}
