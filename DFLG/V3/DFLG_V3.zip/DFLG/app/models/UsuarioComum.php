<?php

namespace app\models;

class UsuarioComum
{
    private int $usuarioId;
    private int $xpTotal;
    private int $nivel;
    private int $streakAtual;
    private int $maiorStreak;
    private ?string $dataUltimoXp;
    private ?string $dataUltimoAcesso;
    private bool $visibilidadeRanking;

    public function __construct(
        int $usuarioId,
        int $xpTotal = 0,
        int $nivel = 1,
        int $streakAtual = 0,
        int $maiorStreak = 0,
        ?string $dataUltimoXp = null,
        ?string $dataUltimoAcesso = null,
        bool $visibilidadeRanking = true
    ) {
        $this->usuarioId = $usuarioId;
        $this->xpTotal = $xpTotal;
        $this->nivel = $nivel;
        $this->streakAtual = $streakAtual;
        $this->maiorStreak = $maiorStreak;
        $this->dataUltimoXp = $dataUltimoXp;
        $this->dataUltimoAcesso = $dataUltimoAcesso;
        $this->visibilidadeRanking = $visibilidadeRanking;
    }

    public function getUsuarioId(): int
    {
        return $this->usuarioId;
    }

    public function getXpTotal(): int
    {
        return $this->xpTotal;
    }

    public function setXpTotal(int $xpTotal): self
    {
        $this->xpTotal = $xpTotal;

        return $this;
    }

    public function getNivel(): int
    {
        return $this->nivel;
    }

    public function setNivel(int $nivel): self
    {
        $this->nivel = $nivel;

        return $this;
    }

    public function getStreakAtual(): int
    {
        return $this->streakAtual;
    }

    public function setStreakAtual(int $streakAtual): self
    {
        $this->streakAtual = $streakAtual;

        return $this;
    }

    public function getMaiorStreak(): int
    {
        return $this->maiorStreak;
    }

    public function setMaiorStreak(int $maiorStreak): self
    {
        $this->maiorStreak = $maiorStreak;

        return $this;
    }

    public function getDataUltimoXp(): ?string
    {
        return $this->dataUltimoXp;
    }

    public function setDataUltimoXp(?string $dataUltimoXp): self
    {
        $this->dataUltimoXp = $dataUltimoXp;

        return $this;
    }

    public function getDataUltimoAcesso(): ?string
    {
        return $this->dataUltimoAcesso;
    }

    public function setDataUltimoAcesso(?string $dataUltimoAcesso): self
    {
        $this->dataUltimoAcesso = $dataUltimoAcesso;

        return $this;
    }

    public function getVisibilidadeRanking(): bool
    {
        return $this->visibilidadeRanking;
    }

    public function setVisibilidadeRanking(bool $visibilidadeRanking): self
    {
        $this->visibilidadeRanking = $visibilidadeRanking;

        return $this;
    }

    public static function arrayParaObjeto(array $usuarioComum): self
    {
        return new self(
            $usuarioComum['usuario_id'],
            (int) $usuarioComum['xp_total'],
            (int) $usuarioComum['nivel'],
            (int) $usuarioComum['streak_atual'],
            (int) $usuarioComum['maior_streak'],
            $usuarioComum['data_ultimo_xp'],
            $usuarioComum['data_ultimo_acesso'] ?? null,
            (bool) $usuarioComum['visibilidade_ranking']
        );
    }
}
