<?php

namespace app\repositories;

use app\database\ConnectionFactory;
use app\models\Categoria;
use PDO;

class CategoriaRepository
{
    private PDO $connection;

    public function __construct()
    {
        $this->connection = ConnectionFactory::getConnection();
    }

    public function getCategorias(): array
    {
        $sql = "SELECT * FROM categorias ORDER BY tipo ASC, nome ASC";
        $stmt = $this->connection->prepare($sql);
        $stmt->execute();

        $categorias = [];

        foreach ($stmt->fetchAll() as $categoria) {
            $categorias[] = Categoria::arrayParaObjeto($categoria);
        }

        return $categorias;
    }

    public function getCategoriasPorTipo(string $tipo): array
    {
        $sql = "SELECT * FROM categorias WHERE tipo = :tipo ORDER BY nome ASC";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':tipo', $tipo);
        $stmt->execute();

        $categorias = [];

        foreach ($stmt->fetchAll() as $categoria) {
            $categorias[] = Categoria::arrayParaObjeto($categoria);
        }

        return $categorias;
    }

    public function getCategoriaPorNome(string $nome, string $tipo)
    {
        $sql = "SELECT * FROM categorias WHERE nome = :nome AND tipo = :tipo";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':nome', $nome);
        $stmt->bindValue(':tipo', $tipo);
        $stmt->execute();

        $categoria = $stmt->fetch();

        if ($categoria == null) {
            return false;
        }

        return Categoria::arrayParaObjeto($categoria);
    }

    // RF16: criação, edição e exclusão de categorias pelo administrador

    public function saveCategoria(Categoria $categoria): bool
    {
        $sql = "INSERT INTO categorias (nome, icone, tipo, limite_orcamento) " .
            "VALUES (:nome, :icone, :tipo, :limiteOrcamento)";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':nome', $categoria->getNome());
        $stmt->bindValue(':icone', $categoria->getIcone());
        $stmt->bindValue(':tipo', $categoria->getTipo());
        $stmt->bindValue(':limiteOrcamento', $categoria->getLimiteOrcamento());

        return $stmt->execute();
    }

    public function updateCategoria(Categoria $categoria): bool
    {
        $sql = "UPDATE categorias SET nome = :nome, icone = :icone, tipo = :tipo, " .
            "limite_orcamento = :limiteOrcamento WHERE id = :id";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':nome', $categoria->getNome());
        $stmt->bindValue(':icone', $categoria->getIcone());
        $stmt->bindValue(':tipo', $categoria->getTipo());
        $stmt->bindValue(':limiteOrcamento', $categoria->getLimiteOrcamento());
        $stmt->bindValue(':id', $categoria->getId());

        return $stmt->execute();
    }

    public function deleteCategoria(int $id): bool
    {
        $sql = "DELETE FROM categorias WHERE id = :id";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':id', $id);

        return $stmt->execute();
    }

    public function contarRegistrosVinculados(int $id): int
    {
        $sql = "SELECT (SELECT COUNT(*) FROM registro_financeiro WHERE categoria_id = :id) + " .
            "(SELECT COUNT(*) FROM parcelamentos WHERE categoria_id = :id)";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':id', $id);
        $stmt->execute();

        return (int) $stmt->fetchColumn();
    }

    public function getCategoria(int $id)
    {
        $sql = "SELECT * FROM categorias WHERE id = :id";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':id', $id);
        $stmt->execute();

        $categoria = $stmt->fetch();

        if ($categoria == null) {
            return false;
        }

        return Categoria::arrayParaObjeto($categoria);
    }
}
