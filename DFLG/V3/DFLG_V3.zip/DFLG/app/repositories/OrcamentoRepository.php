<?php

namespace app\repositories;

use app\database\ConnectionFactory;
use PDO;

/**
 * RF16/RN12: limites de gasto mensal que cada usuário define por categoria
 * (tabela meta_categoria do diagrama de entidade e relacionamento).
 */
class OrcamentoRepository
{
    private PDO $connection;

    public function __construct()
    {
        $this->connection = ConnectionFactory::getConnection();
    }

    public function getOrcamentos(int $usuarioId): array
    {
        $sql = "SELECT mc.id, mc.categoria_id, mc.limite_mensal, c.nome, c.icone " .
            "FROM meta_categoria mc " .
            "INNER JOIN categorias c ON c.id = mc.categoria_id " .
            "WHERE mc.usuario_id = :usuarioId ORDER BY c.nome";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':usuarioId', $usuarioId);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    public function getOrcamento(int $usuarioId, int $categoriaId)
    {
        $sql = "SELECT * FROM meta_categoria WHERE usuario_id = :usuarioId AND categoria_id = :categoriaId";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':usuarioId', $usuarioId);
        $stmt->bindValue(':categoriaId', $categoriaId);
        $stmt->execute();

        $orcamento = $stmt->fetch();

        return $orcamento == null ? false : $orcamento;
    }

    /**
     * Grava o limite da categoria, substituindo o valor anterior quando já existir.
     */
    public function salvarOrcamento(int $usuarioId, int $categoriaId, float $limite): bool
    {
        $sql = "INSERT INTO meta_categoria (usuario_id, categoria_id, limite_mensal) " .
            "VALUES (:usuarioId, :categoriaId, :limite) " .
            "ON DUPLICATE KEY UPDATE limite_mensal = :limite";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':usuarioId', $usuarioId);
        $stmt->bindValue(':categoriaId', $categoriaId);
        $stmt->bindValue(':limite', $limite);

        return $stmt->execute();
    }

    public function excluirOrcamento(int $usuarioId, int $categoriaId): bool
    {
        $sql = "DELETE FROM meta_categoria WHERE usuario_id = :usuarioId AND categoria_id = :categoriaId";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':usuarioId', $usuarioId);
        $stmt->bindValue(':categoriaId', $categoriaId);

        return $stmt->execute();
    }
}
