<?php

namespace app\repositories;

use app\database\ConnectionFactory;
use app\models\SimulacaoInvestimento;
use PDO;

class SimulacaoRepository
{
    private PDO $connection;

    public function __construct()
    {
        $this->connection = ConnectionFactory::getConnection();
    }

    public function getSimulacoesPorUsuario(int $usuarioId): array
    {
        $sql = "SELECT * FROM simulacao_investimento WHERE usuario_id = :usuarioId ORDER BY criado_em DESC";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':usuarioId', $usuarioId);
        $stmt->execute();

        $simulacoes = [];

        foreach ($stmt->fetchAll() as $simulacao) {
            $simulacoes[] = SimulacaoInvestimento::arrayParaObjeto($simulacao);
        }

        return $simulacoes;
    }

    public function saveSimulacao(SimulacaoInvestimento $simulacao): bool
    {
        $sql = "INSERT INTO simulacao_investimento (usuario_id, nome, valor_inicial, aporte_mensal, " .
            "taxa_mensal, periodo_meses, valor_final, total_investido, total_juros) " .
            "VALUES (:usuarioId, :nome, :valorInicial, :aporteMensal, :taxaMensal, :periodoMeses, " .
            ":valorFinal, :totalInvestido, :totalJuros)";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':usuarioId', $simulacao->getUsuarioId());
        $stmt->bindValue(':nome', $simulacao->getNome());
        $stmt->bindValue(':valorInicial', $simulacao->getValorInicial());
        $stmt->bindValue(':aporteMensal', $simulacao->getAporteMensal());
        $stmt->bindValue(':taxaMensal', $simulacao->getTaxaMensal());
        $stmt->bindValue(':periodoMeses', $simulacao->getPeriodoMeses());
        $stmt->bindValue(':valorFinal', $simulacao->getValorFinal());
        $stmt->bindValue(':totalInvestido', $simulacao->getTotalInvestido());
        $stmt->bindValue(':totalJuros', $simulacao->getTotalJuros());

        return $stmt->execute();
    }

    public function deleteSimulacao(int $id, int $usuarioId): bool
    {
        $sql = "DELETE FROM simulacao_investimento WHERE id = :id AND usuario_id = :usuarioId";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':id', $id);
        $stmt->bindValue(':usuarioId', $usuarioId);

        return $stmt->execute();
    }
}
