<?php

namespace app\repositories;

use app\database\ConnectionFactory;
use app\models\Transacao;
use PDO;

class TransacaoRepository
{
    private PDO $connection;

    public function __construct()
    {
        $this->connection = ConnectionFactory::getConnection();
    }

    /**
     * RF09: além de listar, permite filtrar a visualização das finanças por tipo e por categoria.
     */
    public function getTransacoesPorUsuario(int $usuarioId, ?string $tipo = null, ?int $categoriaId = null): array
    {
        $sql = "SELECT r.*, c.nome AS nome_categoria FROM registro_financeiro r " .
            "LEFT JOIN categorias c ON c.id = r.categoria_id " .
            "WHERE r.usuario_id = :usuarioId";

        if ($tipo) {
            $sql .= " AND r.tipo = :tipo";
        }

        if ($categoriaId) {
            $sql .= " AND r.categoria_id = :categoriaId";
        }

        $sql .= " ORDER BY r.data_registro DESC, r.id DESC";

        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':usuarioId', $usuarioId);

        if ($tipo) {
            $stmt->bindValue(':tipo', $tipo);
        }

        if ($categoriaId) {
            $stmt->bindValue(':categoriaId', $categoriaId);
        }

        $stmt->execute();

        $transacoes = [];

        foreach ($stmt->fetchAll() as $transacao) {
            $transacoes[] = Transacao::arrayParaObjeto($transacao);
        }

        return $transacoes;
    }

    /**
     * Sempre filtra pelo dono para que um usuário não acesse a transação de outro.
     */
    public function getTransacao(int $id, int $usuarioId)
    {
        $sql = "SELECT r.*, c.nome AS nome_categoria FROM registro_financeiro r " .
            "LEFT JOIN categorias c ON c.id = r.categoria_id " .
            "WHERE r.id = :id AND r.usuario_id = :usuarioId";

        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':id', $id);
        $stmt->bindValue(':usuarioId', $usuarioId);
        $stmt->execute();

        $transacao = $stmt->fetch();

        if ($transacao == null) {
            return false;
        }

        return Transacao::arrayParaObjeto($transacao);
    }

    public function saveTransacao(Transacao $transacao): bool
    {
        $sql = "INSERT INTO registro_financeiro (usuario_id, categoria_id, tipo, valor, data_registro, descricao) " .
            "VALUES (:usuarioId, :categoriaId, :tipo, :valor, :dataRegistro, :descricao)";

        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':usuarioId', $transacao->getUsuarioId());
        $stmt->bindValue(':categoriaId', $transacao->getCategoriaId());
        $stmt->bindValue(':tipo', $transacao->getTipo());
        $stmt->bindValue(':valor', $transacao->getValor());
        $stmt->bindValue(':dataRegistro', $transacao->getDataRegistro());
        $stmt->bindValue(':descricao', $transacao->getDescricao());

        return $stmt->execute();
    }

    public function updateTransacao(Transacao $transacao): bool
    {
        $sql = "UPDATE registro_financeiro SET categoria_id = :categoriaId, tipo = :tipo, valor = :valor, " .
            "data_registro = :dataRegistro, descricao = :descricao WHERE id = :id AND usuario_id = :usuarioId";

        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':categoriaId', $transacao->getCategoriaId());
        $stmt->bindValue(':tipo', $transacao->getTipo());
        $stmt->bindValue(':valor', $transacao->getValor());
        $stmt->bindValue(':dataRegistro', $transacao->getDataRegistro());
        $stmt->bindValue(':descricao', $transacao->getDescricao());
        $stmt->bindValue(':id', $transacao->getId());
        $stmt->bindValue(':usuarioId', $transacao->getUsuarioId());

        return $stmt->execute();
    }

    public function deleteTransacao(int $id, int $usuarioId): bool
    {
        $sql = "DELETE FROM registro_financeiro WHERE id = :id AND usuario_id = :usuarioId";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':id', $id);
        $stmt->bindValue(':usuarioId', $usuarioId);

        return $stmt->execute();
    }

    /**
     * RF07: total de receitas ou despesas dentro de um mês específico.
     */
    public function getTotalPorTipoNoMes(int $usuarioId, string $tipo, int $ano, int $mes): float
    {
        $sql = "SELECT COALESCE(SUM(valor), 0) FROM registro_financeiro " .
            "WHERE usuario_id = :usuarioId AND tipo = :tipo " .
            "AND YEAR(data_registro) = :ano AND MONTH(data_registro) = :mes";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':usuarioId', $usuarioId);
        $stmt->bindValue(':tipo', $tipo);
        $stmt->bindValue(':ano', $ano, PDO::PARAM_INT);
        $stmt->bindValue(':mes', $mes, PDO::PARAM_INT);
        $stmt->execute();

        return (float) $stmt->fetchColumn();
    }

    /**
     * RF07/RF13: receitas e despesas agrupadas por mês, do mais antigo ao mais recente.
     */
    public function getEvolucaoMensal(int $usuarioId, int $meses = 6): array
    {
        $sql = "SELECT DATE_FORMAT(data_registro, '%Y-%m') AS competencia, " .
            "COALESCE(SUM(CASE WHEN tipo = 'receita' THEN valor END), 0) AS receitas, " .
            "COALESCE(SUM(CASE WHEN tipo = 'despesa' THEN valor END), 0) AS despesas " .
            "FROM registro_financeiro WHERE usuario_id = :usuarioId " .
            "AND data_registro >= (CURDATE() - INTERVAL :meses MONTH) " .
            "GROUP BY competencia ORDER BY competencia";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':usuarioId', $usuarioId);
        $stmt->bindValue(':meses', $meses, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    /**
     * RF13/RN12: despesas agrupadas por categoria em um mês.
     */
    public function getGastoPorCategoria(int $usuarioId, int $ano, int $mes): array
    {
        $sql = "SELECT c.id, c.nome, c.icone, COALESCE(SUM(rf.valor), 0) AS total " .
            "FROM registro_financeiro rf " .
            "INNER JOIN categorias c ON c.id = rf.categoria_id " .
            "WHERE rf.usuario_id = :usuarioId AND rf.tipo = 'despesa' " .
            "AND YEAR(rf.data_registro) = :ano AND MONTH(rf.data_registro) = :mes " .
            "GROUP BY c.id, c.nome, c.icone ORDER BY total DESC";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':usuarioId', $usuarioId);
        $stmt->bindValue(':ano', $ano, PDO::PARAM_INT);
        $stmt->bindValue(':mes', $mes, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    /**
     * RN12: quanto o usuário já gastou em uma categoria no mês corrente.
     */
    public function getGastoDaCategoriaNoMes(int $usuarioId, int $categoriaId, int $ano, int $mes): float
    {
        $sql = "SELECT COALESCE(SUM(valor), 0) FROM registro_financeiro " .
            "WHERE usuario_id = :usuarioId AND categoria_id = :categoriaId AND tipo = 'despesa' " .
            "AND YEAR(data_registro) = :ano AND MONTH(data_registro) = :mes";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':usuarioId', $usuarioId);
        $stmt->bindValue(':categoriaId', $categoriaId);
        $stmt->bindValue(':ano', $ano, PDO::PARAM_INT);
        $stmt->bindValue(':mes', $mes, PDO::PARAM_INT);
        $stmt->execute();

        return (float) $stmt->fetchColumn();
    }

    /**
     * RF13: os 12 meses de um ano, com receitas e despesas de cada um.
     */
    public function getResumoAnual(int $usuarioId, int $ano): array
    {
        $sql = "SELECT MONTH(data_registro) AS mes, " .
            "COALESCE(SUM(CASE WHEN tipo = 'receita' THEN valor END), 0) AS receitas, " .
            "COALESCE(SUM(CASE WHEN tipo = 'despesa' THEN valor END), 0) AS despesas " .
            "FROM registro_financeiro WHERE usuario_id = :usuarioId AND YEAR(data_registro) = :ano " .
            "GROUP BY mes ORDER BY mes";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':usuarioId', $usuarioId);
        $stmt->bindValue(':ano', $ano, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    public function getAnosComRegistros(int $usuarioId): array
    {
        $sql = "SELECT DISTINCT YEAR(data_registro) AS ano FROM registro_financeiro " .
            "WHERE usuario_id = :usuarioId ORDER BY ano DESC";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':usuarioId', $usuarioId);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    public function contarTodas(): int
    {
        $sql = "SELECT COUNT(*) FROM registro_financeiro";
        $stmt = $this->connection->prepare($sql);
        $stmt->execute();

        return (int) $stmt->fetchColumn();
    }

    public function getTotalPorTipo(int $usuarioId, string $tipo): float
    {
        $sql = "SELECT COALESCE(SUM(valor), 0) FROM registro_financeiro WHERE usuario_id = :usuarioId AND tipo = :tipo";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':usuarioId', $usuarioId);
        $stmt->bindValue(':tipo', $tipo);
        $stmt->execute();

        return (float) $stmt->fetchColumn();
    }
}
