<?php

namespace app\repositories;

use app\database\ConnectionFactory;
use app\models\Usuario;
use PDO;

class UsuarioRepository
{
    private PDO $connection;

    public function __construct()
    {
        $this->connection = ConnectionFactory::getConnection();
    }

    public function saveUsuario(Usuario $usuario): bool
    {
        $sql = "INSERT INTO usuarios (nome, nickname, email, senha, data_nascimento, perfil) " .
            "VALUES (:nome, :nickname, :email, :senha, :dataNascimento, :perfil)";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':nome', $usuario->getNome());
        $stmt->bindValue(':nickname', $usuario->getNickname());
        $stmt->bindValue(':email', $usuario->getEmail());
        $stmt->bindValue(':senha', password_hash($usuario->getSenha(), PASSWORD_BCRYPT));
        $stmt->bindValue(':dataNascimento', $usuario->getDataNascimento());
        $stmt->bindValue(':perfil', $usuario->getPerfil());

        return $stmt->execute();
    }

    public function getUsuarios(?string $busca = null): array
    {
        $sql = "SELECT * FROM usuarios";

        if ($busca) {
            $sql .= " WHERE nome LIKE :busca OR nickname LIKE :busca OR email LIKE :busca";
        }

        $sql .= " ORDER BY nome";

        $stmt = $this->connection->prepare($sql);

        if ($busca) {
            $stmt->bindValue(':busca', '%' . $busca . '%');
        }

        $stmt->execute();

        $lista = [];

        foreach ($stmt->fetchAll() as $usuario) {
            $lista[] = Usuario::arrayParaObjeto($usuario);
        }

        return $lista;
    }

    public function updateUsuario(Usuario $usuario): bool
    {
        $sql = "UPDATE usuarios SET nome = :nome, nickname = :nickname, email = :email, " .
            "data_nascimento = :dataNascimento, perfil = :perfil, status = :status WHERE id = :id";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':nome', $usuario->getNome());
        $stmt->bindValue(':nickname', $usuario->getNickname());
        $stmt->bindValue(':email', $usuario->getEmail());
        $stmt->bindValue(':dataNascimento', $usuario->getDataNascimento());
        $stmt->bindValue(':perfil', $usuario->getPerfil());
        $stmt->bindValue(':status', $usuario->getStatus());
        $stmt->bindValue(':id', $usuario->getId());

        return $stmt->execute();
    }

    /**
     * RF04: edição feita pelo próprio usuário — não altera perfil nem status.
     */
    public function updatePerfil(Usuario $usuario): bool
    {
        $sql = "UPDATE usuarios SET nome = :nome, nickname = :nickname, email = :email, " .
            "data_nascimento = :dataNascimento WHERE id = :id";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':nome', $usuario->getNome());
        $stmt->bindValue(':nickname', $usuario->getNickname());
        $stmt->bindValue(':email', $usuario->getEmail());
        $stmt->bindValue(':dataNascimento', $usuario->getDataNascimento());
        $stmt->bindValue(':id', $usuario->getId());

        return $stmt->execute();
    }

    public function atualizarFoto(int $id, ?string $foto): bool
    {
        $sql = "UPDATE usuarios SET foto = :foto WHERE id = :id";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':foto', $foto);
        $stmt->bindValue(':id', $id);

        return $stmt->execute();
    }

    public function atualizarSenha(int $id, string $senhaHash): bool
    {
        $sql = "UPDATE usuarios SET senha = :senha WHERE id = :id";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':senha', $senhaHash);
        $stmt->bindValue(':id', $id);

        return $stmt->execute();
    }

    public function atualizarStatus(int $id, string $status): bool
    {
        $sql = "UPDATE usuarios SET status = :status WHERE id = :id";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':status', $status);
        $stmt->bindValue(':id', $id);

        return $stmt->execute();
    }

    public function deleteUsuario(int $id): bool
    {
        $sql = "DELETE FROM usuarios WHERE id = :id";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':id', $id);

        return $stmt->execute();
    }

    public function contarAdminsAtivos(): int
    {
        $sql = "SELECT COUNT(*) FROM usuarios WHERE perfil = 'administrador' AND status = 'ativo'";
        $stmt = $this->connection->prepare($sql);
        $stmt->execute();

        return (int) $stmt->fetchColumn();
    }

    public function contarUsuarios(): int
    {
        $sql = "SELECT COUNT(*) FROM usuarios";
        $stmt = $this->connection->prepare($sql);
        $stmt->execute();

        return (int) $stmt->fetchColumn();
    }

    public function contarPorStatus(string $status): int
    {
        $sql = "SELECT COUNT(*) FROM usuarios WHERE status = :status";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':status', $status);
        $stmt->execute();

        return (int) $stmt->fetchColumn();
    }

    public function contarNovosUsuarios(int $dias): int
    {
        $sql = "SELECT COUNT(*) FROM usuarios WHERE criado_em >= (CURDATE() - INTERVAL :dias DAY)";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':dias', $dias, PDO::PARAM_INT);
        $stmt->execute();

        return (int) $stmt->fetchColumn();
    }

    public function getDistribuicaoNiveis(): array
    {
        $sql = "SELECT uc.nivel, COUNT(*) AS total FROM usuario_comum uc " .
            "INNER JOIN usuarios u ON u.id = uc.usuario_id GROUP BY uc.nivel ORDER BY uc.nivel";
        $stmt = $this->connection->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    public function getMaioresStreaks(int $limite = 5): array
    {
        $sql = "SELECT u.nome, u.nickname, uc.streak_atual, uc.maior_streak FROM usuario_comum uc " .
            "INNER JOIN usuarios u ON u.id = uc.usuario_id " .
            "ORDER BY uc.maior_streak DESC, uc.streak_atual DESC LIMIT :limite";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':limite', $limite, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    public function getUsuarioById(int $id)
    {
        $sql = "SELECT * FROM usuarios WHERE id = :id";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':id', $id);
        $stmt->execute();
        $usuario = $stmt->fetch();

        if ($usuario == null) {
            return false;
        }

        return Usuario::arrayParaObjeto($usuario);
    }

    public function getUsuarioByEmail(string $email)
    {
        $sql = "SELECT * FROM usuarios WHERE email = :email";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':email', $email);
        $stmt->execute();
        $usuario = $stmt->fetch();

        if ($usuario == null) {
            return false;
        }

        return Usuario::arrayParaObjeto($usuario);
    }

    public function getUsuarioByNickname(string $nickname)
    {
        $sql = "SELECT * FROM usuarios WHERE nickname = :nickname";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':nickname', $nickname);
        $stmt->execute();
        $usuario = $stmt->fetch();

        if ($usuario == null) {
            return false;
        }

        return Usuario::arrayParaObjeto($usuario);
    }
}
