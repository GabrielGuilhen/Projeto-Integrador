<?php

namespace app\repositories;

use app\database\ConnectionFactory;
use PDO;

/**
 * RN10: guarda cada ganho de XP com a data, permitindo apurar
 * os rankings semanal e mensal por período.
 */
class XpHistoricoRepository
{
    private PDO $connection;

    public function __construct()
    {
        $this->connection = ConnectionFactory::getConnection();
    }

    public function registrar(int $usuarioId, int $pontos, string $origem, string $dataGanho): bool
    {
        $sql = "INSERT INTO xp_historico (usuario_id, pontos, origem, data_ganho) " .
            "VALUES (:usuarioId, :pontos, :origem, :dataGanho)";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':usuarioId', $usuarioId);
        $stmt->bindValue(':pontos', $pontos);
        $stmt->bindValue(':origem', $origem);
        $stmt->bindValue(':dataGanho', $dataGanho);

        return $stmt->execute();
    }

    public function getTotalNoPeriodo(int $usuarioId, string $dataInicio): int
    {
        $sql = "SELECT COALESCE(SUM(pontos), 0) FROM xp_historico " .
            "WHERE usuario_id = :usuarioId AND data_ganho >= :dataInicio";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':usuarioId', $usuarioId);
        $stmt->bindValue(':dataInicio', $dataInicio);
        $stmt->execute();

        return (int) $stmt->fetchColumn();
    }

    /**
     * Ranking por período: soma o XP ganho a partir da data informada.
     * Passar null em $dataInicio produz o ranking geral (todo o histórico).
     */
    public function getRankingPorPeriodo(?string $dataInicio = null, int $limite = 20): array
    {
        $sql = "SELECT u.id, u.nome, u.nickname, u.foto, uc.nivel, uc.xp_total, uc.streak_atual, " .
            "COALESCE(SUM(xh.pontos), 0) AS pontos_periodo " .
            "FROM usuario_comum uc " .
            "INNER JOIN usuarios u ON u.id = uc.usuario_id " .
            "LEFT JOIN xp_historico xh ON xh.usuario_id = uc.usuario_id";

        if ($dataInicio) {
            $sql .= " AND xh.data_ganho >= :dataInicio";
        }

        // RF04: usuários que ocultaram o perfil não aparecem no ranking
        $sql .= " WHERE uc.visibilidade_ranking = 1 AND u.status = 'ativo' " .
            "GROUP BY u.id, u.nome, u.nickname, u.foto, uc.nivel, uc.xp_total, uc.streak_atual " .
            "ORDER BY pontos_periodo DESC, uc.xp_total DESC, u.nome LIMIT :limite";

        $stmt = $this->connection->prepare($sql);

        if ($dataInicio) {
            $stmt->bindValue(':dataInicio', $dataInicio);
        }

        $stmt->bindValue(':limite', $limite, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    public function getHistoricoRecente(int $usuarioId, int $limite = 10): array
    {
        $sql = "SELECT pontos, origem, data_ganho FROM xp_historico " .
            "WHERE usuario_id = :usuarioId ORDER BY data_ganho DESC, id DESC LIMIT :limite";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':usuarioId', $usuarioId);
        $stmt->bindValue(':limite', $limite, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll();
    }
}
