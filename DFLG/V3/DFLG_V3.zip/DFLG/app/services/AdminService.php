<?php

namespace app\services;

use app\repositories\MetaRepository;
use app\repositories\TransacaoRepository;
use app\repositories\UsuarioRepository;

/**
 * RF05: reúne os indicadores exibidos no painel administrativo.
 */
class AdminService
{
    private UsuarioRepository $usuarioRepository;
    private TransacaoRepository $transacaoRepository;
    private MetaRepository $metaRepository;

    public function __construct()
    {
        $this->usuarioRepository = new UsuarioRepository();
        $this->transacaoRepository = new TransacaoRepository();
        $this->metaRepository = new MetaRepository();
    }

    public function getIndicadores(): array
    {
        return [
            'totalUsuarios' => $this->usuarioRepository->contarUsuarios(),
            'usuariosAtivos' => $this->usuarioRepository->contarPorStatus('ativo'),
            'usuariosBloqueados' => $this->usuarioRepository->contarPorStatus('bloqueado'),
            'novosUsuarios' => $this->usuarioRepository->contarNovosUsuarios(30),
            'totalTransacoes' => $this->transacaoRepository->contarTodas(),
            'totalMetas' => $this->metaRepository->contarTodas(),
        ];
    }

    public function getDistribuicaoNiveis(): array
    {
        return $this->usuarioRepository->getDistribuicaoNiveis();
    }

    public function getMaioresStreaks(int $limite = 5): array
    {
        return $this->usuarioRepository->getMaioresStreaks($limite);
    }
}
