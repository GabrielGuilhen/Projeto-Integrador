<?php

namespace app\services;

use app\repositories\UsuarioRepository;

class AutenticacaoService {

    private UsuarioRepository $usuarioRepository;
    private GamificacaoService $gamificacaoService;
    private ?string $erro = null;

    public function __construct(){
        $this->usuarioRepository = new UsuarioRepository();
        $this->gamificacaoService = new GamificacaoService();
    }


    public function logar(string $email, string $senha) : bool {

        $usuario = $this->usuarioRepository->getUsuarioByEmail($email);

        if (!$usuario || !password_verify($senha, $usuario->getSenha())) {

            $this->erro = "E-mail ou senha inválidos";
            return false;
        }

        // RF02: contas bloqueadas pelo administrador não podem acessar o sistema
        if ($usuario->getStatus() === 'bloqueado') {

            $this->erro = "Esta conta está bloqueada. Entre em contato com o administrador.";
            return false;
        }

        $_SESSION['usuario_logado'] = $usuario;

        // RF11/RN03: registra a sequência de acesso diário
        $mensagemStreak = $this->gamificacaoService->registrarAcesso($usuario->getId());

        if ($mensagemStreak !== null) {
            $_SESSION['flash_streak'] = $mensagemStreak;
        }

        return true;
    }

    public function logout(){
        session_destroy();
    }

    public function getErro() : ?string {
        return $this->erro;
    }

}
