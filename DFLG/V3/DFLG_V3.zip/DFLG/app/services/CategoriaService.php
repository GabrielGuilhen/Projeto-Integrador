<?php

namespace app\services;

use app\models\Categoria;
use app\repositories\CategoriaRepository;
use app\repositories\OrcamentoRepository;
use app\repositories\TransacaoRepository;

class CategoriaService
{
    // RN12: percentual a partir do qual o usuário passa a ser avisado
    public const LIMITE_ATENCAO = 80;

    private CategoriaRepository $repository;
    private OrcamentoRepository $orcamentoRepository;
    private TransacaoRepository $transacaoRepository;
    private array $erros = [];

    public function __construct()
    {
        $this->repository = new CategoriaRepository();
        $this->orcamentoRepository = new OrcamentoRepository();
        $this->transacaoRepository = new TransacaoRepository();
    }

    public function getCategorias(): array
    {
        return $this->repository->getCategorias();
    }

    public function getCategoriasPorTipo(string $tipo): array
    {
        return $this->repository->getCategoriasPorTipo($tipo);
    }

    public function getCategoria(int $id)
    {
        return $this->repository->getCategoria($id);
    }

    public function existeCategoria(int $id): bool
    {
        return $this->repository->getCategoria($id) !== false;
    }

    // RF16: gestão das categorias pelo administrador

    public function saveCategoria(Categoria $categoria): bool
    {
        if (!$this->validar($categoria)) {
            return false;
        }

        return $this->repository->saveCategoria($categoria);
    }

    public function updateCategoria(Categoria $categoria): bool
    {
        if (!$this->repository->getCategoria($categoria->getId())) {
            $this->erros['categoria'] = "Categoria não encontrada.";

            return false;
        }

        if (!$this->validar($categoria)) {
            return false;
        }

        return $this->repository->updateCategoria($categoria);
    }

    /**
     * Categorias com lançamentos vinculados não são excluídas, para não
     * apagar o histórico financeiro dos usuários.
     */
    public function deleteCategoria(int $id): bool
    {
        $this->erros = [];

        if (!$this->repository->getCategoria($id)) {
            $this->erros['categoria'] = "Categoria não encontrada.";

            return false;
        }

        $vinculados = $this->repository->contarRegistrosVinculados($id);

        if ($vinculados > 0) {
            $this->erros['categoria'] = "Esta categoria possui $vinculados lançamento(s) vinculado(s) " .
                "e não pode ser excluída.";

            return false;
        }

        return $this->repository->deleteCategoria($id);
    }

    // RF16/RN12: orçamento mensal por categoria

    public function getOrcamentos(int $usuarioId): array
    {
        $ano = (int) date('Y');
        $mes = (int) date('n');

        $orcamentos = [];

        foreach ($this->orcamentoRepository->getOrcamentos($usuarioId) as $orcamento) {

            $gasto = $this->transacaoRepository->getGastoDaCategoriaNoMes(
                $usuarioId,
                (int) $orcamento['categoria_id'],
                $ano,
                $mes
            );

            $orcamento['gasto'] = $gasto;
            $orcamento['percentual'] = $this->calcularPercentual($gasto, (float) $orcamento['limite_mensal']);
            $orcamento['situacao'] = $this->classificar($orcamento['percentual']);

            $orcamentos[] = $orcamento;
        }

        return $orcamentos;
    }

    public function salvarOrcamento(int $usuarioId, int $categoriaId, float $limite): bool
    {
        $this->erros = [];

        if ($limite <= 0) {
            $this->erros['limite'] = "O limite mensal deve ser maior que zero.";

            return false;
        }

        $categoria = $this->repository->getCategoria($categoriaId);

        if (!$categoria) {
            $this->erros['categoria'] = "Categoria não encontrada.";

            return false;
        }

        if ($categoria->getTipo() !== 'despesa') {
            $this->erros['categoria'] = "Só é possível definir limite para categorias de despesa.";

            return false;
        }

        return $this->orcamentoRepository->salvarOrcamento($usuarioId, $categoriaId, $limite);
    }

    public function excluirOrcamento(int $usuarioId, int $categoriaId): bool
    {
        return $this->orcamentoRepository->excluirOrcamento($usuarioId, $categoriaId);
    }

    /**
     * RN12: devolve as categorias que atingiram 80% ou estouraram o limite
     * do mês, para que o usuário seja notificado ativamente.
     */
    public function getAlertasOrcamento(int $usuarioId): array
    {
        $alertas = [];

        foreach ($this->getOrcamentos($usuarioId) as $orcamento) {

            if ($orcamento['situacao'] === 'ok') {
                continue;
            }

            $alertas[] = $orcamento;
        }

        return $alertas;
    }

    public function getErros(): array
    {
        return $this->erros;
    }

    private function calcularPercentual(float $gasto, float $limite): float
    {
        if ($limite <= 0) {
            return 0.0;
        }

        return round($gasto / $limite * 100, 1);
    }

    private function classificar(float $percentual): string
    {
        if ($percentual >= 100) {
            return 'estourado';
        }

        if ($percentual >= self::LIMITE_ATENCAO) {
            return 'atencao';
        }

        return 'ok';
    }

    private function validar(Categoria $categoria): bool
    {
        $this->erros = [];

        if (trim($categoria->getNome()) === '') {
            $this->erros['nome'] = "Informe o nome da categoria.";
        }

        if (!in_array($categoria->getTipo(), ['receita', 'despesa'])) {
            $this->erros['tipo'] = "O tipo deve ser receita ou despesa.";
        }

        $existente = $this->repository->getCategoriaPorNome($categoria->getNome(), $categoria->getTipo());

        if ($existente && $existente->getId() !== $categoria->getId()) {
            $this->erros['nome'] = "Já existe uma categoria com esse nome para este tipo.";
        }

        return empty($this->erros);
    }
}
