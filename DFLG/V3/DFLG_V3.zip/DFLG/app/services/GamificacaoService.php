<?php

namespace app\services;

use app\repositories\UsuarioComumRepository;
use app\repositories\XpHistoricoRepository;
use DateTimeImmutable;

class GamificacaoService
{
    // RN04: as três origens de experiência previstas para o sistema
    public const XP_ACESSO_DIARIO = 5;
    public const XP_REGISTRO_FINANCEIRO = 10;
    public const XP_META_CONCLUIDA = 50;

    // Quantidade de XP necessária para avançar um nível
    public const XP_POR_NIVEL = 100;

    private UsuarioComumRepository $repository;
    private XpHistoricoRepository $xpHistoricoRepository;

    public function __construct()
    {
        $this->repository = new UsuarioComumRepository();
        $this->xpHistoricoRepository = new XpHistoricoRepository();
    }

    /**
     * RN07: XP de registro financeiro só pode ser concedido no primeiro
     * registro do dia, verificando a coluna data_ultimo_xp antes de somar pontos.
     */
    public function adicionarPontos(int $usuarioId, int $pontos = self::XP_REGISTRO_FINANCEIRO): bool
    {
        $usuarioComum = $this->repository->getPorUsuarioId($usuarioId);

        if (!$usuarioComum) {
            return false;
        }

        $hoje = (new DateTimeImmutable())->format('Y-m-d');

        if ($usuarioComum->getDataUltimoXp() === $hoje) {
            return false;
        }

        $usuarioComum->setDataUltimoXp($hoje);
        $this->repository->atualizarDataUltimoXp($usuarioComum);

        return $this->creditar($usuarioId, $pontos, 'registro_financeiro');
    }

    /**
     * RN04: metas cumpridas também geram experiência.
     * O controle de meta já pontuada é feito pelo MetaService.
     */
    public function pontuarMetaConcluida(int $usuarioId): bool
    {
        return $this->creditar($usuarioId, self::XP_META_CONCLUIDA, 'meta_concluida');
    }

    /**
     * RF11/RN03: registra o acesso diário do usuário e mantém a sequência (streak).
     * RN04: o acesso diário também rende experiência.
     * Retorna a mensagem de quebra de sequência quando ela é interrompida, ou null.
     */
    public function registrarAcesso(int $usuarioId): ?string
    {
        $usuarioComum = $this->repository->getPorUsuarioId($usuarioId);

        if (!$usuarioComum) {
            return null;
        }

        $hoje = new DateTimeImmutable('today');
        $ultimoAcesso = $usuarioComum->getDataUltimoAcesso();

        // O acesso de hoje já foi registrado, nada muda
        if ($ultimoAcesso === $hoje->format('Y-m-d')) {
            return null;
        }

        $mensagem = null;

        if ($ultimoAcesso === null) {
            // Primeiro acesso do usuário
            $usuarioComum->setStreakAtual(1);
        } else {
            $ontem = $hoje->modify('-1 day')->format('Y-m-d');

            if ($ultimoAcesso === $ontem) {
                $usuarioComum->setStreakAtual($usuarioComum->getStreakAtual() + 1);
            } else {
                // RN03: a sequência foi interrompida e precisa ser reiniciada
                $sequenciaPerdida = $usuarioComum->getStreakAtual();

                if ($sequenciaPerdida > 1) {
                    $mensagem = "Sua sequência de $sequenciaPerdida dias foi interrompida! " .
                        "Acesse todos os dias para mantê-la.";
                }

                $usuarioComum->setStreakAtual(1);
            }
        }

        if ($usuarioComum->getStreakAtual() > $usuarioComum->getMaiorStreak()) {
            $usuarioComum->setMaiorStreak($usuarioComum->getStreakAtual());
        }

        $usuarioComum->setDataUltimoAcesso($hoje->format('Y-m-d'));

        $this->repository->atualizarAcesso($usuarioComum);

        // RN04: cada dia de acesso rende experiência
        $this->creditar($usuarioId, self::XP_ACESSO_DIARIO, 'acesso_diario');

        return $mensagem;
    }

    public function getGamificacao(int $usuarioId)
    {
        return $this->repository->getPorUsuarioId($usuarioId);
    }

    public function getHistoricoRecente(int $usuarioId, int $limite = 10): array
    {
        return $this->xpHistoricoRepository->getHistoricoRecente($usuarioId, $limite);
    }

    /**
     * Progresso dentro do nível atual, em porcentagem, para as barras da interface.
     */
    public function getProgressoNivel(int $xpTotal): float
    {
        return round(($xpTotal % self::XP_POR_NIVEL) / self::XP_POR_NIVEL * 100, 1);
    }

    public function getXpParaProximoNivel(int $xpTotal): int
    {
        return self::XP_POR_NIVEL - ($xpTotal % self::XP_POR_NIVEL);
    }

    /**
     * Soma os pontos ao total do usuário, recalcula o nível e
     * grava o ganho no histórico (RN10).
     */
    private function creditar(int $usuarioId, int $pontos, string $origem): bool
    {
        $usuarioComum = $this->repository->getPorUsuarioId($usuarioId);

        if (!$usuarioComum) {
            return false;
        }

        $usuarioComum->setXpTotal($usuarioComum->getXpTotal() + $pontos);
        $usuarioComum->setNivel(intdiv($usuarioComum->getXpTotal(), self::XP_POR_NIVEL) + 1);

        if (!$this->repository->atualizarXp($usuarioComum)) {
            return false;
        }

        return $this->xpHistoricoRepository->registrar(
            $usuarioId,
            $pontos,
            $origem,
            (new DateTimeImmutable())->format('Y-m-d')
        );
    }
}
