<?php

namespace app\services;

use app\models\Meta;
use app\repositories\MetaRepository;
use DateTimeImmutable;

class MetaService
{
    private MetaRepository $repository;
    private GamificacaoService $gamificacaoService;
    private array $erros = [];
    private bool $metaConcluidaAgora = false;

    public function __construct()
    {
        $this->repository = new MetaRepository();
        $this->gamificacaoService = new GamificacaoService();
    }

    public function getMetas(int $usuarioId): array
    {
        return $this->repository->getMetasPorUsuario($usuarioId);
    }

    public function getMeta(int $id, int $usuarioId)
    {
        return $this->repository->getMeta($id, $usuarioId);
    }

    public function saveMeta(Meta $meta): bool
    {
        if (!$this->validar($meta)) {
            return false;
        }

        return $this->repository->saveMeta($meta);
    }

    public function updateMeta(Meta $meta): bool
    {
        if (!$this->repository->getMeta($meta->getId(), $meta->getUsuarioId())) {
            $this->erros['meta'] = "Meta não encontrada";

            return false;
        }

        if (!$this->validar($meta)) {
            return false;
        }

        if (!$this->repository->updateMeta($meta)) {
            return false;
        }

        $this->verificarConclusao($meta->getId(), $meta->getUsuarioId());

        return true;
    }

    /**
     * RF19: registra um aporte na meta e, ao atingir o valor alvo,
     * concede a experiência prevista na RN04.
     */
    public function adicionarValor(int $id, int $usuarioId, float $valor): bool
    {
        $this->erros = [];
        $this->metaConcluidaAgora = false;

        if ($valor <= 0) {
            $this->erros['valor'] = "O valor do aporte deve ser maior que zero";

            return false;
        }

        $meta = $this->repository->getMeta($id, $usuarioId);

        if (!$meta) {
            $this->erros['meta'] = "Meta não encontrada";

            return false;
        }

        if (!$this->repository->adicionarValor($id, $usuarioId, $valor)) {
            return false;
        }

        $this->verificarConclusao($id, $usuarioId);

        return true;
    }

    public function metaConcluidaAgora(): bool
    {
        return $this->metaConcluidaAgora;
    }

    public function getTotalGuardado(int $usuarioId): float
    {
        return $this->repository->getTotalGuardado($usuarioId);
    }

    public function contarMetas(int $usuarioId, bool $somenteConcluidas = false): int
    {
        return $this->repository->contarPorUsuario($usuarioId, $somenteConcluidas);
    }

    public function deleteMeta(int $id, int $usuarioId): bool
    {
        return $this->repository->deleteMeta($id, $usuarioId);
    }

    public function getErros(): array
    {
        return $this->erros;
    }

    /**
     * RN04: a primeira vez que uma meta atinge o valor alvo rende XP ao usuário.
     * A coluna xp_concedido garante que a pontuação não seja repetida.
     */
    private function verificarConclusao(int $id, int $usuarioId): void
    {
        $meta = $this->repository->getMeta($id, $usuarioId);

        if (!$meta || !$meta->eConcluida() || $meta->getXpConcedido()) {
            return;
        }

        $this->gamificacaoService->pontuarMetaConcluida($usuarioId);
        $this->repository->marcarXpConcedido($id, $usuarioId);

        $this->metaConcluidaAgora = true;
    }

    /**
     * RN08: a data limite de uma meta precisa ser sempre posterior à data atual.
     * O valor alvo também precisa ser maior que zero para a meta fazer sentido.
     */
    private function validar(Meta $meta): bool
    {
        $this->erros = [];

        if ($meta->getValorAlvo() <= 0) {
            $this->erros['valorAlvo'] = "O valor alvo deve ser maior que zero";
        }

        if ($meta->getValorAtual() < 0) {
            $this->erros['valorAtual'] = "O valor atual não pode ser negativo";
        }

        $hoje = new DateTimeImmutable('today');
        $dataLimite = DateTimeImmutable::createFromFormat('Y-m-d', $meta->getDataLimite());

        if (!$dataLimite) {
            $this->erros['dataLimite'] = "Informe uma data limite válida";
        } elseif ($dataLimite->setTime(0, 0) <= $hoje) {
            $this->erros['dataLimite'] = "A data limite deve ser posterior à data de hoje";
        }

        return empty($this->erros);
    }
}
