<?php

namespace app\services;

use app\repositories\XpHistoricoRepository;
use DateTimeImmutable;

/**
 * RF12/RN10: rankings de progresso dos usuários por período.
 */
class RankingService
{
    private XpHistoricoRepository $repository;

    public function __construct()
    {
        $this->repository = new XpHistoricoRepository();
    }

    /**
     * Períodos aceitos: 'geral', 'mensal' e 'semanal'.
     */
    public function getRanking(string $periodo = 'geral', int $limite = 20): array
    {
        $lista = $this->repository->getRankingPorPeriodo($this->getDataInicio($periodo), $limite);

        // A posição é atribuída aqui para que a View não precise controlar contadores
        $posicao = 1;

        foreach ($lista as &$linha) {
            $linha['posicao'] = $posicao++;
        }

        return $lista;
    }

    /**
     * Posição do usuário informado dentro do ranking do período,
     * ou null quando ele não aparece na listagem (perfil oculto, por exemplo).
     */
    public function getPosicaoUsuario(int $usuarioId, string $periodo = 'geral'): ?int
    {
        foreach ($this->getRanking($periodo, 1000) as $linha) {

            if ((int) $linha['id'] === $usuarioId) {
                return $linha['posicao'];
            }
        }

        return null;
    }

    public function getPeriodosDisponiveis(): array
    {
        return [
            'geral' => 'Geral',
            'mensal' => 'Mensal',
            'semanal' => 'Semanal',
        ];
    }

    /**
     * Converte o período em uma data de corte. O ranking geral não tem corte.
     */
    private function getDataInicio(string $periodo): ?string
    {
        $hoje = new DateTimeImmutable('today');

        if ($periodo === 'mensal') {
            return $hoje->modify('first day of this month')->format('Y-m-d');
        }

        if ($periodo === 'semanal') {
            return $hoje->modify('monday this week')->format('Y-m-d');
        }

        return null;
    }
}
