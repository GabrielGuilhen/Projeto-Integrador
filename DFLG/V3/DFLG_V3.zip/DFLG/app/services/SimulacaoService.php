<?php

namespace app\services;

use app\models\SimulacaoInvestimento;
use app\repositories\SimulacaoRepository;

/**
 * RF10: cálculo de juros compostos com aportes mensais.
 */
class SimulacaoService
{
    private SimulacaoRepository $repository;
    private array $erros = [];

    public function __construct()
    {
        $this->repository = new SimulacaoRepository();
    }

    public function getSimulacoes(int $usuarioId): array
    {
        return $this->repository->getSimulacoesPorUsuario($usuarioId);
    }

    /**
     * Projeta o crescimento mês a mês e preenche os totais da simulação.
     *
     * Fórmula aplicada a cada mês:
     *   saldo = saldo * (1 + taxa) + aporte
     *
     * Devolve a lista com a evolução mensal para exibição na tela.
     */
    public function calcular(SimulacaoInvestimento $simulacao): array
    {
        $taxa = $simulacao->getTaxaMensal() / 100;

        $saldo = $simulacao->getValorInicial();
        $investido = $simulacao->getValorInicial();

        $evolucao = [];

        for ($mes = 1; $mes <= $simulacao->getPeriodoMeses(); $mes++) {

            $saldo = $saldo * (1 + $taxa) + $simulacao->getAporteMensal();
            $investido += $simulacao->getAporteMensal();

            $evolucao[] = [
                'mes' => $mes,
                'saldo' => round($saldo, 2),
                'investido' => round($investido, 2),
                'juros' => round($saldo - $investido, 2),
            ];
        }

        $simulacao->setValorFinal(round($saldo, 2));
        $simulacao->setTotalInvestido(round($investido, 2));
        $simulacao->setTotalJuros(round($saldo - $investido, 2));

        return $evolucao;
    }

    public function salvar(SimulacaoInvestimento $simulacao): bool
    {
        if (!$this->validar($simulacao)) {
            return false;
        }

        $this->calcular($simulacao);

        return $this->repository->saveSimulacao($simulacao);
    }

    public function excluir(int $id, int $usuarioId): bool
    {
        return $this->repository->deleteSimulacao($id, $usuarioId);
    }

    public function getErros(): array
    {
        return $this->erros;
    }

    public function validar(SimulacaoInvestimento $simulacao): bool
    {
        $this->erros = [];

        if (trim($simulacao->getNome()) === '') {
            $this->erros['nome'] = "Dê um nome para a simulação.";
        }

        if ($simulacao->getValorInicial() < 0) {
            $this->erros['valorInicial'] = "O valor inicial não pode ser negativo.";
        }

        if ($simulacao->getAporteMensal() < 0) {
            $this->erros['aporteMensal'] = "O aporte mensal não pode ser negativo.";
        }

        if ($simulacao->getValorInicial() <= 0 && $simulacao->getAporteMensal() <= 0) {
            $this->erros['valorInicial'] = "Informe um valor inicial ou um aporte mensal maior que zero.";
        }

        if ($simulacao->getTaxaMensal() <= 0) {
            $this->erros['taxaMensal'] = "A taxa mensal deve ser maior que zero.";
        }

        if ($simulacao->getPeriodoMeses() < 1 || $simulacao->getPeriodoMeses() > 600) {
            $this->erros['periodoMeses'] = "O período deve estar entre 1 e 600 meses.";
        }

        return empty($this->erros);
    }
}
