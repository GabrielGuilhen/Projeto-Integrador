<?php

namespace app\services;

use app\models\Transacao;
use app\repositories\TransacaoRepository;

class TransacaoService
{
    private TransacaoRepository $repository;
    private CategoriaService $categoriaService;
    private GamificacaoService $gamificacaoService;
    private array $erros = [];
    private bool $ganhouXp = false;

    public function __construct()
    {
        $this->repository = new TransacaoRepository();
        $this->categoriaService = new CategoriaService();
        $this->gamificacaoService = new GamificacaoService();
    }

    public function getTransacoes(int $usuarioId, ?string $tipo = null, ?int $categoriaId = null): array
    {
        return $this->repository->getTransacoesPorUsuario($usuarioId, $tipo, $categoriaId);
    }

    public function getTransacao(int $id, int $usuarioId)
    {
        return $this->repository->getTransacao($id, $usuarioId);
    }

    public function saveTransacao(Transacao $transacao): bool
    {
        if (!$this->validar($transacao)) {
            return false;
        }

        if (!$this->repository->saveTransacao($transacao)) {
            return false;
        }

        // RN04/RN07: o registro financeiro gera XP, mas o GamificacaoService
        // só concede a pontuação no primeiro registro do dia.
        $this->ganhouXp = $this->gamificacaoService->adicionarPontos($transacao->getUsuarioId());

        return true;
    }

    public function updateTransacao(Transacao $transacao): bool
    {
        if (!$this->repository->getTransacao($transacao->getId(), $transacao->getUsuarioId())) {
            $this->erros['transacao'] = "Transação não encontrada";

            return false;
        }

        if (!$this->validar($transacao)) {
            return false;
        }

        return $this->repository->updateTransacao($transacao);
    }

    public function deleteTransacao(int $id, int $usuarioId): bool
    {
        return $this->repository->deleteTransacao($id, $usuarioId);
    }

    public function getTotalReceitas(int $usuarioId): float
    {
        return $this->repository->getTotalPorTipo($usuarioId, 'receita');
    }

    public function getTotalDespesas(int $usuarioId): float
    {
        return $this->repository->getTotalPorTipo($usuarioId, 'despesa');
    }

    public function getSaldo(int $usuarioId): float
    {
        return $this->getTotalReceitas($usuarioId) - $this->getTotalDespesas($usuarioId);
    }

    /**
     * RF07: saldo considerando apenas os registros do mês informado.
     */
    public function getSaldoDoMes(int $usuarioId, int $ano, int $mes): float
    {
        return $this->repository->getTotalPorTipoNoMes($usuarioId, 'receita', $ano, $mes)
            - $this->repository->getTotalPorTipoNoMes($usuarioId, 'despesa', $ano, $mes);
    }

    public function getTotalPorTipoNoMes(int $usuarioId, string $tipo, int $ano, int $mes): float
    {
        return $this->repository->getTotalPorTipoNoMes($usuarioId, $tipo, $ano, $mes);
    }

    public function getEvolucaoMensal(int $usuarioId, int $meses = 6): array
    {
        return $this->repository->getEvolucaoMensal($usuarioId, $meses);
    }

    public function getGastoPorCategoria(int $usuarioId, int $ano, int $mes): array
    {
        return $this->repository->getGastoPorCategoria($usuarioId, $ano, $mes);
    }

    public function getResumoAnual(int $usuarioId, int $ano): array
    {
        return $this->repository->getResumoAnual($usuarioId, $ano);
    }

    public function getAnosComRegistros(int $usuarioId): array
    {
        return $this->repository->getAnosComRegistros($usuarioId);
    }

    public function ganhouXp(): bool
    {
        return $this->ganhouXp;
    }

    public function getErros(): array
    {
        return $this->erros;
    }

    /**
     * RN05: todo registro de gasto ou ganho precisa de valor estritamente maior que zero.
     * RN06: receitas e despesas precisam estar categorizadas.
     */
    private function validar(Transacao $transacao): bool
    {
        $this->erros = [];

        if ($transacao->getValor() <= 0) {
            $this->erros['valor'] = "O valor deve ser maior que zero";
        }

        if (!in_array($transacao->getTipo(), ['receita', 'despesa'])) {
            $this->erros['tipo'] = "Selecione um tipo válido (receita ou despesa)";
        }

        if (!$transacao->getCategoriaId() || !$this->categoriaService->existeCategoria($transacao->getCategoriaId())) {
            $this->erros['categoriaId'] = "Selecione uma categoria válida";
        }

        if (!$transacao->getDataRegistro()) {
            $this->erros['dataRegistro'] = "Informe a data do registro";
        }

        return empty($this->erros);
    }
}
