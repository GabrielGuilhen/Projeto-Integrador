<?php

namespace app\services;

use Exception;

/**
 * RF04: envio da foto de perfil do usuário.
 */
class UploadService
{
    private array $extensoesPermitidas = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    private int $tamanhoMaximo = 2 * 1024 * 1024; // 2MB

    private string $uploadPath;

    public function __construct(?string $path = null)
    {
        $this->uploadPath = $path ?? UPLOAD_PATH;

        if (!is_dir($this->uploadPath)) {
            mkdir($this->uploadPath, 0777, true);
        }
    }

    /**
     * Recebe um item de $_FILES e devolve o nome do arquivo gravado.
     */
    public function upload(array $file): string
    {
        if (!isset($file['error']) || $file['error'] !== UPLOAD_ERR_OK) {
            throw new Exception("Não foi possível enviar a imagem.");
        }

        if ($file['size'] > $this->tamanhoMaximo) {
            throw new Exception("Imagem muito grande. Tamanho máximo permitido: 2MB.");
        }

        $extensao = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

        if (!in_array($extensao, $this->extensoesPermitidas)) {
            throw new Exception("Tipo de arquivo não permitido. Envie uma imagem JPG, PNG, GIF ou WEBP.");
        }

        // Confirma que o arquivo é mesmo uma imagem, e não apenas um nome com extensão de imagem
        if (getimagesize($file['tmp_name']) === false) {
            throw new Exception("O arquivo enviado não é uma imagem válida.");
        }

        $novaImagem = bin2hex(random_bytes(16)) . '.' . $extensao;
        $destino = $this->uploadPath . '/' . $novaImagem;

        if (!move_uploaded_file($file['tmp_name'], $destino)) {
            throw new Exception("Falha ao gravar a imagem no servidor.");
        }

        return $novaImagem;
    }

    public function remover(?string $arquivo): void
    {
        if (!$arquivo) {
            return;
        }

        $caminho = $this->uploadPath . '/' . $arquivo;

        if (is_file($caminho)) {
            unlink($caminho);
        }
    }
}
