<?php

namespace app\services;

use app\models\Usuario;
use app\repositories\UsuarioRepository;
use app\repositories\UsuarioComumRepository;

class UsuarioService
{
    private UsuarioRepository $repository;
    private UsuarioComumRepository $usuarioComumRepository;
    private array $erros = [];

    public function __construct()
    {
        $this->repository = new UsuarioRepository();
        $this->usuarioComumRepository = new UsuarioComumRepository();
    }

    public function cadastrar(Usuario $usuario): bool
    {
        // RN02/RF01: e-mail e nickname precisam ser únicos
        if ($this->repository->getUsuarioByEmail($usuario->getEmail())) {
            return false;
        }

        if ($this->repository->getUsuarioByNickname($usuario->getNickname())) {
            return false;
        }

        if (!$this->repository->saveUsuario($usuario)) {
            return false;
        }

        $usuarioCriado = $this->repository->getUsuarioByEmail($usuario->getEmail());
        $this->usuarioComumRepository->criarParaUsuario($usuarioCriado->getId());

        return true;
    }

    public function getUsuarioById(int $id)
    {
        return $this->repository->getUsuarioById($id);
    }

    public function getUsuarios(?string $busca = null): array
    {
        return $this->repository->getUsuarios($busca);
    }

    /**
     * RF02: atualização de dados de um usuário pelo administrador.
     * RN02: e-mail e nickname continuam únicos, ignorando o próprio registro.
     */
    public function atualizar(Usuario $usuario): bool
    {
        $this->erros = [];

        $usuarioAtual = $this->repository->getUsuarioById($usuario->getId());

        if (!$usuarioAtual) {
            $this->erros['usuario'] = "Usuário não encontrado.";

            return false;
        }

        $porEmail = $this->repository->getUsuarioByEmail($usuario->getEmail());

        if ($porEmail && $porEmail->getId() !== $usuario->getId()) {
            $this->erros['email'] = "Este e-mail já está sendo usado por outro usuário.";
        }

        $porNickname = $this->repository->getUsuarioByNickname($usuario->getNickname());

        if ($porNickname && $porNickname->getId() !== $usuario->getId()) {
            $this->erros['nickname'] = "Este nickname já está sendo usado por outro usuário.";
        }

        // RN09: o painel não pode ficar sem gestão
        if (
            $usuarioAtual->eAdmin()
            && (!$usuario->eAdmin() || $usuario->getStatus() === 'bloqueado')
            && $this->repository->contarAdminsAtivos() <= 1
        ) {
            $this->erros['perfil'] = "Este é o último administrador ativo: ele não pode ser rebaixado nem bloqueado.";
        }

        if ($this->temErros()) {
            return false;
        }

        return $this->repository->updateUsuario($usuario);
    }

    /**
     * RF04: o próprio usuário edita seus dados. Perfil e status não são
     * alteráveis por aqui — apenas pelo administrador.
     */
    public function atualizarPerfil(Usuario $usuario): bool
    {
        $this->erros = [];

        if (!$this->repository->getUsuarioById($usuario->getId())) {
            $this->erros['usuario'] = "Usuário não encontrado.";

            return false;
        }

        $porEmail = $this->repository->getUsuarioByEmail($usuario->getEmail());

        if ($porEmail && $porEmail->getId() !== $usuario->getId()) {
            $this->erros['email'] = "Este e-mail já está sendo usado por outro usuário.";
        }

        $porNickname = $this->repository->getUsuarioByNickname($usuario->getNickname());

        if ($porNickname && $porNickname->getId() !== $usuario->getId()) {
            $this->erros['nickname'] = "Este nickname já está sendo usado por outro usuário.";
        }

        if ($this->temErros()) {
            return false;
        }

        return $this->repository->updatePerfil($usuario);
    }

    public function atualizarFoto(int $id, ?string $foto): bool
    {
        return $this->repository->atualizarFoto($id, $foto);
    }

    /**
     * RF04: troca de senha exigindo a senha atual como confirmação.
     */
    public function alterarSenha(int $id, string $senhaAtual, string $novaSenha, string $confirmacao): bool
    {
        $this->erros = [];

        $usuario = $this->repository->getUsuarioById($id);

        if (!$usuario) {
            $this->erros['usuario'] = "Usuário não encontrado.";

            return false;
        }

        if (!password_verify($senhaAtual, $usuario->getSenha())) {
            $this->erros['senhaAtual'] = "A senha atual está incorreta.";
        }

        if (strlen($novaSenha) < 6) {
            $this->erros['novaSenha'] = "A nova senha deve ter pelo menos 6 caracteres.";
        }

        if ($novaSenha !== $confirmacao) {
            $this->erros['confirmacao'] = "A confirmação não confere com a nova senha.";
        }

        if ($this->temErros()) {
            return false;
        }

        return $this->repository->atualizarSenha($id, password_hash($novaSenha, PASSWORD_BCRYPT));
    }

    public function alterarVisibilidadeRanking(int $id, bool $visivel): bool
    {
        return $this->usuarioComumRepository->atualizarVisibilidadeRanking($id, $visivel);
    }

    public function bloquear(int $id): bool
    {
        $this->erros = [];

        $usuario = $this->repository->getUsuarioById($id);

        if (!$usuario) {
            $this->erros['usuario'] = "Usuário não encontrado.";

            return false;
        }

        // RN09: bloquear o último administrador ativo deixaria o sistema sem gestão
        if ($usuario->eAdmin() && $this->repository->contarAdminsAtivos() <= 1) {
            $this->erros['status'] = "Este é o último administrador ativo e não pode ser bloqueado.";

            return false;
        }

        return $this->repository->atualizarStatus($id, 'bloqueado');
    }

    public function desbloquear(int $id): bool
    {
        $this->erros = [];

        if (!$this->repository->getUsuarioById($id)) {
            $this->erros['usuario'] = "Usuário não encontrado.";

            return false;
        }

        return $this->repository->atualizarStatus($id, 'ativo');
    }

    /**
     * RN09: impede a exclusão da conta do último administrador ativo,
     * garantindo que o painel de controle nunca fique sem gestão.
     */
    public function excluir(int $id, int $idLogado): bool
    {
        $this->erros = [];

        $usuario = $this->repository->getUsuarioById($id);

        if (!$usuario) {
            $this->erros['usuario'] = "Usuário não encontrado.";

            return false;
        }

        if ($usuario->eAdmin() && $this->repository->contarAdminsAtivos() <= 1) {

            $mensagem = $id === $idLogado
                ? "Você é o último administrador ativo e não pode excluir a própria conta."
                : "Este é o último administrador ativo e não pode ser excluído.";

            $this->erros['usuario'] = $mensagem;

            return false;
        }

        return $this->repository->deleteUsuario($id);
    }

    public function temErros(): bool
    {
        return count($this->erros) > 0;
    }

    public function getErros(): array
    {
        return $this->erros;
    }
}
