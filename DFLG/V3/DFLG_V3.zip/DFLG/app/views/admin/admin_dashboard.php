<?php

$titulo = 'Painel Administrativo';
$paginaAtiva = 'admin';

require __DIR__ . '/../partials/header.php';

?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="mb-0"><i class="bi bi-shield-lock me-2"></i>Painel Administrativo</h2>
    <a href="<?= URL_BASE ?>/admin/usuarios" class="btn btn-primary">
        <i class="bi bi-people"></i> Gerenciar Usuários
    </a>
</div>

<div class="row g-3">
    <div class="col-md-4">
        <div class="card stat-card shadow-sm h-100">
            <div class="card-body">
                <p class="text-muted small mb-1"><i class="bi bi-people me-1"></i>Total de usuários</p>
                <h3 class="mb-0"><?= $indicadores['totalUsuarios'] ?></h3>
                <small class="text-muted">
                    <?= $indicadores['usuariosAtivos'] ?> ativos
                    &bull; <?= $indicadores['usuariosBloqueados'] ?> bloqueados
                </small>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card stat-card shadow-sm h-100">
            <div class="card-body">
                <p class="text-muted small mb-1"><i class="bi bi-person-plus me-1"></i>Novos cadastros</p>
                <h3 class="mb-0"><?= $indicadores['novosUsuarios'] ?></h3>
                <small class="text-muted">nos últimos 30 dias</small>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card stat-card shadow-sm h-100">
            <div class="card-body">
                <p class="text-muted small mb-1"><i class="bi bi-cash-stack me-1"></i>Registros financeiros</p>
                <h3 class="mb-0"><?= $indicadores['totalTransacoes'] ?></h3>
                <small class="text-muted"><?= $indicadores['totalMetas'] ?> metas criadas</small>
            </div>
        </div>
    </div>
</div>

<div class="row g-3 mt-2">

    <div class="col-md-6">
        <div class="card stat-card shadow-sm h-100">
            <div class="card-body">
                <h5 class="mb-3"><i class="bi bi-bar-chart me-2 text-primary"></i>Distribuição de níveis</h5>

                <?php if (empty($distribuicaoNiveis)): ?>
                    <p class="text-muted mb-0">Nenhum usuário comum cadastrado ainda.</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-sm mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Nível</th>
                                    <th class="text-end">Usuários</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($distribuicaoNiveis as $faixa): ?>
                                    <tr>
                                        <td>Nível <?= (int) $faixa['nivel'] ?></td>
                                        <td class="text-end"><?= (int) $faixa['total'] ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="col-md-6">
        <div class="card stat-card shadow-sm h-100">
            <div class="card-body">
                <h5 class="mb-3"><i class="bi bi-fire me-2 text-danger"></i>Maiores sequências</h5>

                <?php if (empty($maioresStreaks)): ?>
                    <p class="text-muted mb-0">Nenhuma sequência registrada ainda.</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-sm mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Usuário</th>
                                    <th class="text-end">Atual</th>
                                    <th class="text-end">Recorde</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($maioresStreaks as $streak): ?>
                                    <tr>
                                        <td>
                                            <?= htmlspecialchars($streak['nome']) ?>
                                            <small class="text-muted">@<?= htmlspecialchars($streak['nickname']) ?></small>
                                        </td>
                                        <td class="text-end"><?= (int) $streak['streak_atual'] ?></td>
                                        <td class="text-end"><?= (int) $streak['maior_streak'] ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

</div>

<?php require __DIR__ . '/../partials/footer.php'; ?>
