<?php

$titulo = 'Editar Usuário';
$paginaAtiva = 'admin';

require __DIR__ . '/../partials/header.php';

?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="mb-0"><i class="bi bi-person-gear me-2"></i>Editar Usuário</h2>
    <a href="<?= URL_BASE ?>/admin/usuarios" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left"></i> Voltar
    </a>
</div>

<?php if (isset($erros)): ?>
    <div class="alert alert-danger">
        <i class="bi bi-exclamation-triangle me-2"></i>
        <?= is_array($erros) ? implode('<br>', $erros) : $erros ?>
    </div>
<?php endif; ?>

<div class="card shadow-sm">
    <div class="card-body">
        <form method="post" action="<?= URL_BASE ?>/admin/usuarios/atualizar">

            <input type="hidden" name="id" value="<?= $usuario->getId() ?>">

            <div class="row g-3">

                <div class="col-md-6">
                    <label for="nome" class="form-label">Nome</label>
                    <input type="text" class="form-control" id="nome" name="nome"
                        value="<?= htmlspecialchars($usuario->getNome()) ?>" required>
                </div>

                <div class="col-md-6">
                    <label for="nickname" class="form-label">Nickname</label>
                    <input type="text" class="form-control" id="nickname" name="nickname"
                        value="<?= htmlspecialchars($usuario->getNickname()) ?>" required>
                </div>

                <div class="col-md-6">
                    <label for="email" class="form-label">E-mail</label>
                    <input type="email" class="form-control" id="email" name="email"
                        value="<?= htmlspecialchars($usuario->getEmail()) ?>" required>
                </div>

                <div class="col-md-6">
                    <label for="dataNascimento" class="form-label">Data de nascimento</label>
                    <input type="date" class="form-control" id="dataNascimento" name="dataNascimento"
                        value="<?= htmlspecialchars($usuario->getDataNascimento()) ?>" required>
                </div>

                <div class="col-md-6">
                    <label for="perfil" class="form-label">Perfil</label>
                    <select class="form-select" id="perfil" name="perfil">
                        <option value="comum" <?= $usuario->getPerfil() === 'comum' ? 'selected' : '' ?>>Comum</option>
                        <option value="administrador" <?= $usuario->getPerfil() === 'administrador' ? 'selected' : '' ?>>Administrador</option>
                    </select>
                    <!-- RN01: novos administradores só podem ser definidos por outro administrador -->
                    <div class="form-text">Promover um usuário a administrador dá acesso total ao painel.</div>
                </div>

                <div class="col-md-6">
                    <label for="status" class="form-label">Status</label>
                    <select class="form-select" id="status" name="status">
                        <option value="ativo" <?= $usuario->getStatus() === 'ativo' ? 'selected' : '' ?>>Ativo</option>
                        <option value="bloqueado" <?= $usuario->getStatus() === 'bloqueado' ? 'selected' : '' ?>>Bloqueado</option>
                    </select>
                    <div class="form-text">Contas bloqueadas não conseguem acessar o sistema.</div>
                </div>

            </div>

            <div class="alert alert-secondary mt-4 mb-0">
                <i class="bi bi-info-circle me-2"></i>
                A senha do usuário não é alterada por esta tela.
            </div>

            <div class="mt-4">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-check-lg"></i> Salvar alterações
                </button>
                <a href="<?= URL_BASE ?>/admin/usuarios" class="btn btn-light">Cancelar</a>
            </div>

        </form>
    </div>
</div>

<?php require __DIR__ . '/../partials/footer.php'; ?>
