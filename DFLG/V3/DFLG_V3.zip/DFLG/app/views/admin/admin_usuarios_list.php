<?php

$titulo = 'Usuários';
$paginaAtiva = 'admin';

require __DIR__ . '/../partials/header.php';

?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="mb-0"><i class="bi bi-people me-2"></i>Usuários</h2>
    <a href="<?= URL_BASE ?>/admin" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left"></i> Painel
    </a>
</div>

<?php if (isset($sucesso)): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="bi bi-check-circle me-2"></i><?= htmlspecialchars($sucesso) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<?php if (isset($erros)): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="bi bi-exclamation-triangle me-2"></i>
        <?= is_array($erros) ? implode('<br>', $erros) : $erros ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<form method="get" action="<?= URL_BASE ?>/admin/usuarios" class="mb-3">
    <div class="input-group">
        <input type="text" name="busca" class="form-control" placeholder="Buscar por nome, nickname ou e-mail"
            value="<?= htmlspecialchars($busca ?? '') ?>">
        <button class="btn btn-outline-primary" type="submit">
            <i class="bi bi-search"></i> Buscar
        </button>
        <?php if (!empty($busca)): ?>
            <a href="<?= URL_BASE ?>/admin/usuarios" class="btn btn-outline-secondary">Limpar</a>
        <?php endif; ?>
    </div>
</form>

<?php if (empty($lista)): ?>
    <div class="alert alert-info">
        <i class="bi bi-info-circle me-2"></i>Nenhum usuário encontrado.
    </div>
<?php else: ?>
    <div class="card shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0 align-middle">
                    <thead class="table-light">
                        <tr>
                            <th class="px-4 py-3">Nome</th>
                            <th class="px-4 py-3">Nickname</th>
                            <th class="px-4 py-3">E-mail</th>
                            <th class="px-4 py-3">Perfil</th>
                            <th class="px-4 py-3">Status</th>
                            <th class="px-4 py-3 text-end">Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($lista as $usuario): ?>
                            <tr>
                                <td class="px-4 py-3">
                                    <?= htmlspecialchars($usuario->getNome()) ?>
                                    <?php if ($usuario->getId() === $usuarioLogadoId): ?>
                                        <span class="badge bg-primary ms-1">Você</span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-4 py-3">@<?= htmlspecialchars($usuario->getNickname()) ?></td>
                                <td class="px-4 py-3"><?= htmlspecialchars($usuario->getEmail()) ?></td>
                                <td class="px-4 py-3">
                                    <span class="badge <?= $usuario->eAdmin() ? 'bg-warning text-dark' : 'bg-secondary' ?> text-capitalize">
                                        <?= htmlspecialchars($usuario->getPerfil()) ?>
                                    </span>
                                </td>
                                <td class="px-4 py-3">
                                    <span class="badge <?= $usuario->getStatus() === 'ativo' ? 'bg-success' : 'bg-danger' ?> text-capitalize">
                                        <?= htmlspecialchars($usuario->getStatus()) ?>
                                    </span>
                                </td>
                                <td class="px-4 py-3 text-end text-nowrap">
                                    <a href="<?= URL_BASE ?>/admin/usuarios/editar?id=<?= $usuario->getId() ?>"
                                        class="btn btn-sm btn-outline-primary">
                                        <i class="bi bi-pencil"></i> Editar
                                    </a>

                                    <?php if ($usuario->getStatus() === 'ativo'): ?>
                                        <a href="<?= URL_BASE ?>/admin/usuarios/bloquear?id=<?= $usuario->getId() ?>"
                                            class="btn btn-sm btn-outline-warning"
                                            onclick="return confirm('Deseja realmente bloquear este usuário?')">
                                            <i class="bi bi-lock"></i> Bloquear
                                        </a>
                                    <?php else: ?>
                                        <a href="<?= URL_BASE ?>/admin/usuarios/desbloquear?id=<?= $usuario->getId() ?>"
                                            class="btn btn-sm btn-outline-success">
                                            <i class="bi bi-unlock"></i> Desbloquear
                                        </a>
                                    <?php endif; ?>

                                    <a href="<?= URL_BASE ?>/admin/usuarios/excluir?id=<?= $usuario->getId() ?>"
                                        class="btn btn-sm btn-outline-danger"
                                        onclick="return confirm('Deseja realmente excluir este usuário? Todos os dados financeiros dele serão apagados.')">
                                        <i class="bi bi-trash"></i> Excluir
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php require __DIR__ . '/../partials/footer.php'; ?>
