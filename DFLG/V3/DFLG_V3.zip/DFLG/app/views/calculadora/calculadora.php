<?php

$titulo = 'Calculadora de Investimentos';
$paginaAtiva = 'calculadora';

require __DIR__ . '/../partials/header.php';

$valorNome = isset($simulacao) ? $simulacao->getNome() : '';
$valorInicial = isset($simulacao) ? $simulacao->getValorInicial() : '';
$valorAporte = isset($simulacao) ? $simulacao->getAporteMensal() : '';
$valorTaxa = isset($simulacao) ? $simulacao->getTaxaMensal() : '';
$valorPeriodo = isset($simulacao) ? $simulacao->getPeriodoMeses() : '';

?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="mb-0"><i class="bi bi-calculator me-2"></i>Calculadora de Investimentos</h2>
</div>

<?php if (isset($_SESSION['flash_simulacao_sucesso'])): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="bi bi-check-circle me-2"></i><?= htmlspecialchars($_SESSION['flash_simulacao_sucesso']) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
    <?php unset($_SESSION['flash_simulacao_sucesso']); ?>
<?php endif; ?>

<?php if (isset($erros)): ?>
    <div class="alert alert-danger">
        <i class="bi bi-exclamation-triangle me-2"></i>
        <?= is_array($erros) ? implode('<br>', $erros) : $erros ?>
    </div>
<?php endif; ?>

<div class="row g-3">

    <!-- Formulário da simulação -->
    <div class="col-lg-5">
        <div class="card stat-card shadow-sm">
            <div class="card-body">
                <h5 class="mb-3">Simular</h5>

                <form method="post" action="<?= URL_BASE ?>/calculadora/calcular">

                    <div class="mb-3">
                        <label for="nome" class="form-label">Nome da simulação</label>
                        <input type="text" class="form-control" id="nome" name="nome"
                            value="<?= htmlspecialchars($valorNome) ?>" placeholder="Aposentadoria" required>
                    </div>

                    <div class="mb-3">
                        <label for="valorInicial" class="form-label">Valor inicial (R$)</label>
                        <input type="number" step="0.01" min="0" class="form-control" id="valorInicial"
                            name="valorInicial" value="<?= $valorInicial ?>" placeholder="1000">
                    </div>

                    <div class="mb-3">
                        <label for="aporteMensal" class="form-label">Aporte mensal (R$)</label>
                        <input type="number" step="0.01" min="0" class="form-control" id="aporteMensal"
                            name="aporteMensal" value="<?= $valorAporte ?>" placeholder="300">
                    </div>

                    <div class="mb-3">
                        <label for="taxaMensal" class="form-label">Taxa de juros mensal (%)</label>
                        <input type="number" step="0.001" min="0.001" class="form-control" id="taxaMensal"
                            name="taxaMensal" value="<?= $valorTaxa ?>" placeholder="0.85" required>
                        <div class="form-text">Ex.: 0,85% ao mês equivale a aproximadamente 10,7% ao ano.</div>
                    </div>

                    <div class="mb-3">
                        <label for="periodoMeses" class="form-label">Período (meses)</label>
                        <input type="number" min="1" max="600" class="form-control" id="periodoMeses"
                            name="periodoMeses" value="<?= $valorPeriodo ?>" placeholder="120" required>
                    </div>

                    <button type="submit" class="btn btn-primary w-100">
                        <i class="bi bi-graph-up-arrow"></i> Calcular
                    </button>

                    <?php if (isset($resultado)): ?>
                        <button type="submit" formaction="<?= URL_BASE ?>/calculadora/salvar"
                            class="btn btn-outline-success w-100 mt-2">
                            <i class="bi bi-save"></i> Salvar simulação
                        </button>
                    <?php endif; ?>

                </form>
            </div>
        </div>
    </div>

    <!-- Resultado -->
    <div class="col-lg-7">
        <?php if (isset($resultado)): ?>
            <div class="card stat-card shadow-sm mb-3">
                <div class="card-body">
                    <h5 class="mb-3"><?= htmlspecialchars($resultado->getNome()) ?></h5>

                    <div class="row text-center g-3">
                        <div class="col-4">
                            <div class="fs-5 fw-bold text-primary">
                                R$ <?= number_format($resultado->getValorFinal(), 2, ',', '.') ?>
                            </div>
                            <small class="text-muted">Valor final</small>
                        </div>
                        <div class="col-4">
                            <div class="fs-5 fw-bold">
                                R$ <?= number_format($resultado->getTotalInvestido(), 2, ',', '.') ?>
                            </div>
                            <small class="text-muted">Total investido</small>
                        </div>
                        <div class="col-4">
                            <div class="fs-5 fw-bold text-success">
                                R$ <?= number_format($resultado->getTotalJuros(), 2, ',', '.') ?>
                            </div>
                            <small class="text-muted">Juros ganhos</small>
                        </div>
                    </div>

                    <hr>

                    <small class="text-muted">
                        <?= $resultado->getPeriodoMeses() ?> meses a
                        <?= number_format($resultado->getTaxaMensal(), 3, ',', '.') ?>% ao mês
                        (<?= number_format($resultado->getTaxaAnual(), 2, ',', '.') ?>% ao ano).
                    </small>
                </div>
            </div>

            <!-- Projeção ano a ano -->
            <div class="card stat-card shadow-sm">
                <div class="card-body">
                    <h5 class="mb-3">Projeção</h5>
                    <div class="table-responsive" style="max-height: 340px;">
                        <table class="table table-sm mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Mês</th>
                                    <th class="text-end">Investido</th>
                                    <th class="text-end">Juros</th>
                                    <th class="text-end">Saldo</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($evolucao as $linha): ?>
                                    <?php if ($linha['mes'] % 12 !== 0 && $linha['mes'] !== count($evolucao)) continue; ?>
                                    <tr>
                                        <td><?= $linha['mes'] ?></td>
                                        <td class="text-end">R$ <?= number_format($linha['investido'], 2, ',', '.') ?></td>
                                        <td class="text-end text-success">R$ <?= number_format($linha['juros'], 2, ',', '.') ?></td>
                                        <td class="text-end fw-bold">R$ <?= number_format($linha['saldo'], 2, ',', '.') ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <small class="text-muted">Exibindo o saldo a cada 12 meses e no último mês do período.</small>
                </div>
            </div>
        <?php else: ?>
            <div class="card stat-card shadow-sm">
                <div class="card-body text-center text-muted py-5">
                    <i class="bi bi-graph-up-arrow fs-1"></i>
                    <p class="mt-3 mb-0">Preencha os dados ao lado para ver a projeção do seu investimento.</p>
                </div>
            </div>
        <?php endif; ?>
    </div>

</div>

<!-- Simulações salvas -->
<?php if (!empty($salvas)): ?>
    <div class="card stat-card shadow-sm mt-3">
        <div class="card-body">
            <h5 class="mb-3"><i class="bi bi-bookmark me-2 text-primary"></i>Simulações salvas</h5>
            <div class="table-responsive">
                <table class="table table-hover mb-0 align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Nome</th>
                            <th class="text-end">Aporte</th>
                            <th class="text-end">Taxa</th>
                            <th class="text-end">Período</th>
                            <th class="text-end">Valor final</th>
                            <th class="text-end">Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($salvas as $item): ?>
                            <tr>
                                <td><?= htmlspecialchars($item->getNome()) ?></td>
                                <td class="text-end">R$ <?= number_format($item->getAporteMensal(), 2, ',', '.') ?></td>
                                <td class="text-end"><?= number_format($item->getTaxaMensal(), 3, ',', '.') ?>%</td>
                                <td class="text-end"><?= $item->getPeriodoMeses() ?> meses</td>
                                <td class="text-end fw-bold text-primary">
                                    R$ <?= number_format($item->getValorFinal(), 2, ',', '.') ?>
                                </td>
                                <td class="text-end">
                                    <a href="<?= URL_BASE ?>/calculadora/excluir?id=<?= $item->getId() ?>"
                                        class="btn btn-sm btn-outline-danger"
                                        onclick="return confirm('Excluir esta simulação?')">
                                        <i class="bi bi-trash"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php require __DIR__ . '/../partials/footer.php'; ?>
