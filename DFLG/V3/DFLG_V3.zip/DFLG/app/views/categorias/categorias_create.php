<?php

$titulo = 'Nova Categoria';
$paginaAtiva = 'admin';

require __DIR__ . '/../partials/header.php';

$valorNome = isset($categoria) ? $categoria->getNome() : '';
$valorIcone = isset($categoria) ? $categoria->getIcone() : '';
$valorTipo = isset($categoria) ? $categoria->getTipo() : 'despesa';

?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="mb-0"><i class="bi bi-tag me-2"></i>Nova Categoria</h2>
    <a href="<?= URL_BASE ?>/categorias" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left"></i> Voltar
    </a>
</div>

<?php if (isset($erros)): ?>
    <div class="alert alert-danger">
        <i class="bi bi-exclamation-triangle me-2"></i>
        <?= is_array($erros) ? implode('<br>', $erros) : $erros ?>
    </div>
<?php endif; ?>

<div class="card shadow-sm">
    <div class="card-body">
        <form method="post" action="<?= URL_BASE ?>/categorias/salvar">

            <div class="row g-3">

                <div class="col-md-6">
                    <label for="nome" class="form-label">Nome</label>
                    <input type="text" class="form-control" id="nome" name="nome"
                        value="<?= htmlspecialchars($valorNome) ?>" required>
                </div>

                <div class="col-md-6">
                    <label for="tipo" class="form-label">Tipo</label>
                    <select class="form-select" id="tipo" name="tipo">
                        <option value="despesa" <?= $valorTipo === 'despesa' ? 'selected' : '' ?>>Despesa</option>
                        <option value="receita" <?= $valorTipo === 'receita' ? 'selected' : '' ?>>Receita</option>
                    </select>
                </div>

                <div class="col-md-6">
                    <label for="icone" class="form-label">Ícone (opcional)</label>
                    <input type="text" class="form-control" id="icone" name="icone"
                        value="<?= htmlspecialchars($valorIcone ?? '') ?>" placeholder="bi-basket">
                    <div class="form-text">
                        Nome de um ícone do Bootstrap Icons, como <code>bi-basket</code> ou <code>bi-house-door</code>.
                    </div>
                </div>

            </div>

            <div class="mt-4">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-check-lg"></i> Salvar
                </button>
                <a href="<?= URL_BASE ?>/categorias" class="btn btn-light">Cancelar</a>
            </div>

        </form>
    </div>
</div>

<?php require __DIR__ . '/../partials/footer.php'; ?>
