<?php

$titulo = 'Categorias';
$paginaAtiva = 'admin';

require __DIR__ . '/../partials/header.php';

?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="mb-0"><i class="bi bi-tags me-2"></i>Categorias</h2>
    <div>
        <a href="<?= URL_BASE ?>/admin" class="btn btn-outline-secondary me-1">
            <i class="bi bi-arrow-left"></i> Painel
        </a>
        <a href="<?= URL_BASE ?>/categorias/cadastrar" class="btn btn-primary">
            <i class="bi bi-plus-circle"></i> Nova Categoria
        </a>
    </div>
</div>

<?php if (isset($sucesso)): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="bi bi-check-circle me-2"></i><?= htmlspecialchars($sucesso) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<?php if (isset($erros)): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="bi bi-exclamation-triangle me-2"></i>
        <?= is_array($erros) ? implode('<br>', $erros) : $erros ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<div class="card shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0 align-middle">
                <thead class="table-light">
                    <tr>
                        <th class="px-4 py-3">Categoria</th>
                        <th class="px-4 py-3">Tipo</th>
                        <th class="px-4 py-3">Ícone</th>
                        <th class="px-4 py-3 text-end">Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($lista as $categoria): ?>
                        <tr>
                            <td class="px-4 py-3">
                                <?php if ($categoria->getIcone()): ?>
                                    <i class="bi <?= htmlspecialchars($categoria->getIcone()) ?> me-2"></i>
                                <?php endif; ?>
                                <?= htmlspecialchars($categoria->getNome()) ?>
                            </td>
                            <td class="px-4 py-3">
                                <span class="badge <?= $categoria->getTipo() === 'receita' ? 'bg-success' : 'bg-danger' ?> text-capitalize">
                                    <?= htmlspecialchars($categoria->getTipo()) ?>
                                </span>
                            </td>
                            <td class="px-4 py-3">
                                <small class="text-muted"><?= htmlspecialchars($categoria->getIcone() ?? '—') ?></small>
                            </td>
                            <td class="px-4 py-3 text-end text-nowrap">
                                <a href="<?= URL_BASE ?>/categorias/editar?id=<?= $categoria->getId() ?>"
                                    class="btn btn-sm btn-outline-primary">
                                    <i class="bi bi-pencil"></i> Editar
                                </a>
                                <a href="<?= URL_BASE ?>/categorias/excluir?id=<?= $categoria->getId() ?>"
                                    class="btn btn-sm btn-outline-danger"
                                    onclick="return confirm('Deseja realmente excluir esta categoria?')">
                                    <i class="bi bi-trash"></i> Excluir
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require __DIR__ . '/../partials/footer.php'; ?>
