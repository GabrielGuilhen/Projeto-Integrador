<?php

$titulo = 'Orçamento por Categoria';
$paginaAtiva = 'orcamentos';

require __DIR__ . '/../partials/header.php';

?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="mb-0"><i class="bi bi-pie-chart me-2"></i>Orçamento por Categoria</h2>
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#orcamentoModal">
        <i class="bi bi-plus-circle"></i> Definir limite
    </button>
</div>

<?php if (isset($sucesso)): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="bi bi-check-circle me-2"></i><?= htmlspecialchars($sucesso) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<?php if (isset($erros)): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="bi bi-exclamation-triangle me-2"></i>
        <?= is_array($erros) ? implode('<br>', $erros) : $erros ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<p class="text-muted">
    Defina quanto pretende gastar por mês em cada categoria de despesa.
    O sistema avisa quando o gasto chega a <?= app\services\CategoriaService::LIMITE_ATENCAO ?>%
    e quando o limite é ultrapassado.
</p>

<?php if (empty($orcamentos)): ?>
    <div class="alert alert-info">
        <i class="bi bi-info-circle me-2"></i>
        Você ainda não definiu nenhum limite mensal.
    </div>
<?php else: ?>
    <div class="row g-3">
        <?php foreach ($orcamentos as $orcamento): ?>
            <?php
            $cor = $orcamento['situacao'] === 'estourado'
                ? 'danger'
                : ($orcamento['situacao'] === 'atencao' ? 'warning' : 'success');
            $largura = min($orcamento['percentual'], 100);
            ?>
            <div class="col-md-6">
                <div class="card stat-card shadow-sm h-100">
                    <div class="card-body">

                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <h5 class="mb-0">
                                <?php if (!empty($orcamento['icone'])): ?>
                                    <i class="bi <?= htmlspecialchars($orcamento['icone']) ?> me-2"></i>
                                <?php endif; ?>
                                <?= htmlspecialchars($orcamento['nome']) ?>
                            </h5>
                            <a href="<?= URL_BASE ?>/orcamentos/excluir?categoriaId=<?= $orcamento['categoria_id'] ?>"
                                class="btn btn-sm btn-outline-danger"
                                onclick="return confirm('Remover o limite desta categoria?')">
                                <i class="bi bi-trash"></i>
                            </a>
                        </div>

                        <div class="progress mb-2" style="height: 10px;">
                            <div class="progress-bar bg-<?= $cor ?>" role="progressbar"
                                style="width: <?= $largura ?>%"></div>
                        </div>

                        <div class="d-flex justify-content-between small">
                            <span class="text-<?= $cor ?> fw-bold"><?= $orcamento['percentual'] ?>%</span>
                            <span class="text-muted">
                                R$ <?= number_format($orcamento['gasto'], 2, ',', '.') ?>
                                de R$ <?= number_format($orcamento['limite_mensal'], 2, ',', '.') ?>
                            </span>
                        </div>

                        <?php if ($orcamento['situacao'] === 'estourado'): ?>
                            <div class="alert alert-danger py-2 px-3 mt-3 mb-0 small">
                                <i class="bi bi-exclamation-octagon me-1"></i>
                                Limite ultrapassado em
                                R$ <?= number_format($orcamento['gasto'] - $orcamento['limite_mensal'], 2, ',', '.') ?>.
                            </div>
                        <?php elseif ($orcamento['situacao'] === 'atencao'): ?>
                            <div class="alert alert-warning py-2 px-3 mt-3 mb-0 small">
                                <i class="bi bi-exclamation-triangle me-1"></i>
                                Você já usou <?= $orcamento['percentual'] ?>% do limite deste mês.
                            </div>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<!-- Definir ou atualizar o limite de uma categoria -->
<div class="modal fade" id="orcamentoModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form method="post" action="<?= URL_BASE ?>/orcamentos/salvar">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-pie-chart me-2"></i>Definir limite mensal</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                </div>
                <div class="modal-body">

                    <div class="mb-3">
                        <label for="categoriaId" class="form-label">Categoria de despesa</label>
                        <select class="form-select" id="categoriaId" name="categoriaId" required>
                            <?php foreach ($categorias as $categoria): ?>
                                <option value="<?= $categoria->getId() ?>"><?= htmlspecialchars($categoria->getNome()) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <label for="limiteMensal" class="form-label">Limite mensal (R$)</label>
                        <input type="number" step="0.01" min="0.01" class="form-control"
                            id="limiteMensal" name="limiteMensal" required>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-check-lg"></i> Salvar
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require __DIR__ . '/../partials/footer.php'; ?>
