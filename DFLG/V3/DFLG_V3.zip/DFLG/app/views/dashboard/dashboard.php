<?php

$titulo = 'Dashboard';
$paginaAtiva = 'dashboard';

require __DIR__ . '/../partials/header.php';

$meses = ['', 'Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];

// Maior valor da série, usado para dimensionar as barras da evolução
$maiorValor = 0;

foreach ($evolucao as $linha) {
    $maiorValor = max($maiorValor, (float) $linha['receitas'], (float) $linha['despesas']);
}

?>

<?php if (isset($_SESSION['flash_streak'])): ?>
    <!-- RN03: aviso de quebra da sequência de acesso -->
    <div class="alert alert-warning alert-dismissible fade show" role="alert">
        <i class="bi bi-fire me-2"></i><?= htmlspecialchars($_SESSION['flash_streak']) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
    <?php unset($_SESSION['flash_streak']); ?>
<?php endif; ?>

<!-- RN12: alerta ativo de categorias no limite ou estouradas -->
<?php foreach ($alertasCategoria as $alerta): ?>
    <div class="alert alert-<?= $alerta['situacao'] === 'estourado' ? 'danger' : 'warning' ?> alert-dismissible fade show"
        role="alert">
        <i class="bi bi-<?= $alerta['situacao'] === 'estourado' ? 'exclamation-octagon' : 'exclamation-triangle' ?> me-2"></i>
        <?php if ($alerta['situacao'] === 'estourado'): ?>
            Você ultrapassou o limite mensal de <strong><?= htmlspecialchars($alerta['nome']) ?></strong>:
            gastou R$ <?= number_format($alerta['gasto'], 2, ',', '.') ?>
            de R$ <?= number_format($alerta['limite_mensal'], 2, ',', '.') ?> (<?= $alerta['percentual'] ?>%).
        <?php else: ?>
            Atenção: você já usou <?= $alerta['percentual'] ?>% do limite mensal de
            <strong><?= htmlspecialchars($alerta['nome']) ?></strong>.
        <?php endif; ?>
        <a href="<?= URL_BASE ?>/orcamentos" class="alert-link">Ver orçamento</a>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endforeach; ?>

<div class="d-flex justify-content-between align-items-center mb-1">
    <h4 class="mb-0">Olá, <?= htmlspecialchars($usuario->getNome()) ?> 👋</h4>
    <?php if ($posicao !== null): ?>
        <a href="<?= URL_BASE ?>/ranking" class="badge bg-primary text-decoration-none fs-6">
            <i class="bi bi-trophy me-1"></i><?= $posicao ?>º no ranking
        </a>
    <?php endif; ?>
</div>
<p class="text-muted">@<?= htmlspecialchars($usuario->getNickname()) ?></p>

<!-- RF07: resumo financeiro -->
<div class="row g-3 mt-1">
    <div class="col-md-3 col-6">
        <div class="card stat-card shadow-sm h-100">
            <div class="card-body">
                <p class="text-muted small mb-1"><i class="bi bi-wallet2 me-1"></i>Saldo total</p>
                <h4 class="mb-0 <?= $saldoTotal >= 0 ? 'text-success' : 'text-danger' ?>">
                    R$ <?= number_format($saldoTotal, 2, ',', '.') ?>
                </h4>
            </div>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="card stat-card shadow-sm h-100">
            <div class="card-body">
                <p class="text-muted small mb-1"><i class="bi bi-calendar-month me-1"></i>Saldo do mês</p>
                <h4 class="mb-0 <?= $saldoMes >= 0 ? 'text-success' : 'text-danger' ?>">
                    R$ <?= number_format($saldoMes, 2, ',', '.') ?>
                </h4>
                <small class="text-muted">
                    +<?= number_format($receitasMes, 2, ',', '.') ?>
                    / -<?= number_format($despesasMes, 2, ',', '.') ?>
                </small>
            </div>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="card stat-card shadow-sm h-100">
            <div class="card-body">
                <p class="text-muted small mb-1"><i class="bi bi-piggy-bank me-1"></i>Total economizado</p>
                <h4 class="mb-0 text-primary">R$ <?= number_format($totalEconomizado, 2, ',', '.') ?></h4>
                <small class="text-muted"><?= $metasConcluidas ?> meta(s) concluída(s)</small>
            </div>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="card stat-card shadow-sm h-100">
            <div class="card-body">
                <p class="text-muted small mb-1"><i class="bi bi-credit-card-2-front me-1"></i>Parcelas do mês</p>
                <h4 class="mb-0 text-danger">
                    R$ <?= number_format($totaisParcelas['total_mes'] ?? 0, 2, ',', '.') ?>
                </h4>
                <small class="text-muted"><?= (int) ($totaisParcelas['ativos'] ?? 0) ?> parcelamento(s) ativo(s)</small>
            </div>
        </div>
    </div>
</div>

<!-- Gamificação -->
<?php if ($gamificacao): ?>
    <div class="card stat-card shadow-sm mt-3">
        <div class="card-body">
            <div class="row align-items-center g-3">
                <div class="col-md-8">
                    <div class="d-flex justify-content-between small mb-1">
                        <span class="fw-bold">Nível <?= $gamificacao->getNivel() ?></span>
                        <span class="text-muted"><?= $gamificacao->getXpTotal() ?> XP</span>
                    </div>
                    <div class="progress" style="height: 10px;">
                        <div class="progress-bar bg-warning" role="progressbar"
                            style="width: <?= $progressoNivel ?? 0 ?>%"></div>
                    </div>
                    <small class="text-muted">
                        Faltam <?= $xpProximoNivel ?? 0 ?> XP para o nível <?= $gamificacao->getNivel() + 1 ?>.
                    </small>
                </div>
                <div class="col-md-4 text-md-end">
                    <span class="fs-4"><i class="bi bi-fire text-danger"></i> <?= $gamificacao->getStreakAtual() ?></span>
                    <div><small class="text-muted">dias seguidos (recorde: <?= $gamificacao->getMaiorStreak() ?>)</small></div>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<div class="row g-3 mt-1">

    <!-- RF07: evolução financeira -->
    <div class="col-lg-7">
        <div class="card stat-card shadow-sm h-100">
            <div class="card-body">
                <h5 class="mb-3"><i class="bi bi-graph-up-arrow me-2 text-primary"></i>Evolução financeira</h5>

                <?php if (empty($evolucao)): ?>
                    <p class="text-muted mb-0">Registre receitas e despesas para acompanhar sua evolução.</p>
                <?php else: ?>
                    <?php foreach ($evolucao as $linha): ?>
                        <?php
                        list($anoLinha, $mesLinha) = explode('-', $linha['competencia']);
                        $receitas = (float) $linha['receitas'];
                        $despesas = (float) $linha['despesas'];
                        ?>
                        <div class="mb-3">
                            <div class="d-flex justify-content-between small mb-1">
                                <span class="fw-bold"><?= $meses[(int) $mesLinha] ?>/<?= $anoLinha ?></span>
                                <span class="<?= $receitas - $despesas >= 0 ? 'text-success' : 'text-danger' ?>">
                                    R$ <?= number_format($receitas - $despesas, 2, ',', '.') ?>
                                </span>
                            </div>
                            <div class="progress mb-1" style="height: 7px;">
                                <div class="progress-bar bg-success" role="progressbar"
                                    style="width: <?= $maiorValor > 0 ? $receitas / $maiorValor * 100 : 0 ?>%"></div>
                            </div>
                            <div class="progress" style="height: 7px;">
                                <div class="progress-bar bg-danger" role="progressbar"
                                    style="width: <?= $maiorValor > 0 ? $despesas / $maiorValor * 100 : 0 ?>%"></div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                    <small class="text-muted">
                        <span class="text-success">■</span> receitas
                        <span class="text-danger ms-2">■</span> despesas
                    </small>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Gastos do mês por categoria -->
    <div class="col-lg-5">
        <div class="card stat-card shadow-sm h-100">
            <div class="card-body">
                <h5 class="mb-3"><i class="bi bi-tags me-2 text-danger"></i>Gastos do mês por categoria</h5>

                <?php if (empty($gastoPorCategoria)): ?>
                    <p class="text-muted mb-0">Nenhuma despesa registrada neste mês.</p>
                <?php else: ?>
                    <table class="table table-sm mb-0">
                        <tbody>
                            <?php foreach ($gastoPorCategoria as $gasto): ?>
                                <tr>
                                    <td>
                                        <?php if (!empty($gasto['icone'])): ?>
                                            <i class="bi <?= htmlspecialchars($gasto['icone']) ?> me-1 text-muted"></i>
                                        <?php endif; ?>
                                        <?= htmlspecialchars($gasto['nome']) ?>
                                    </td>
                                    <td class="text-end">R$ <?= number_format($gasto['total'], 2, ',', '.') ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>

</div>

<!-- RF07: progresso das metas -->
<?php if (!empty($metas)): ?>
    <div class="card stat-card shadow-sm mt-3">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="mb-0"><i class="bi bi-bullseye me-2 text-success"></i>Progresso das metas</h5>
                <a href="<?= URL_BASE ?>/metas" class="btn btn-sm btn-outline-primary">Ver todas</a>
            </div>

            <?php foreach (array_slice($metas, 0, 4) as $meta): ?>
                <div class="mb-3">
                    <div class="d-flex justify-content-between small mb-1">
                        <span>
                            <?= htmlspecialchars($meta->getNomeMeta()) ?>
                            <?php if ($meta->eConcluida()): ?>
                                <span class="badge bg-success ms-1">Concluída</span>
                            <?php endif; ?>
                        </span>
                        <span class="text-muted">
                            R$ <?= number_format($meta->getValorAtual(), 2, ',', '.') ?>
                            de R$ <?= number_format($meta->getValorAlvo(), 2, ',', '.') ?>
                        </span>
                    </div>
                    <div class="progress" style="height: 8px;">
                        <div class="progress-bar <?= $meta->eConcluida() ? 'bg-success' : 'bg-primary' ?>"
                            role="progressbar" style="width: <?= $meta->getProgresso() ?>%"></div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
<?php endif; ?>

<!-- Atalhos -->
<div class="row g-3 mt-1">
    <div class="col-md-3 col-6">
        <a href="<?= URL_BASE ?>/transacoes/cadastrar" class="text-decoration-none">
            <div class="card stat-card shadow-sm h-100">
                <div class="card-body text-center">
                    <i class="bi bi-plus-circle fs-3 text-success"></i>
                    <div class="mt-1 small fw-bold">Novo registro</div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-3 col-6">
        <a href="<?= URL_BASE ?>/metas/cadastrar" class="text-decoration-none">
            <div class="card stat-card shadow-sm h-100">
                <div class="card-body text-center">
                    <i class="bi bi-bullseye fs-3 text-primary"></i>
                    <div class="mt-1 small fw-bold">Nova meta</div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-3 col-6">
        <a href="<?= URL_BASE ?>/calculadora" class="text-decoration-none">
            <div class="card stat-card shadow-sm h-100">
                <div class="card-body text-center">
                    <i class="bi bi-calculator fs-3 text-warning"></i>
                    <div class="mt-1 small fw-bold">Simular investimento</div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-3 col-6">
        <a href="<?= URL_BASE ?>/relatorios" class="text-decoration-none">
            <div class="card stat-card shadow-sm h-100">
                <div class="card-body text-center">
                    <i class="bi bi-file-earmark-bar-graph fs-3 text-secondary"></i>
                    <div class="mt-1 small fw-bold">Relatórios</div>
                </div>
            </div>
        </a>
    </div>
</div>

<?php require __DIR__ . '/../partials/footer.php'; ?>
