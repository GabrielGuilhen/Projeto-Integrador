<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= APP_NAME ?> • Gestão financeira com gamificação</title>

    <!-- RNF08: aplica o tema salvo antes de renderizar a página -->
    <script src="<?= URL_BASE ?>/assets/js/tema.js"></script>

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <!-- Estilos do DFLG Investments -->
    <link href="<?= URL_BASE_CSS ?>/style.css" rel="stylesheet">
</head>

<body>

    <nav class="navbar navbar-dark navbar-dflg">
        <div class="container">
            <span class="navbar-brand mb-0 h1">
                <i class="bi bi-piggy-bank-fill me-2"></i>DFLG Investments
            </span>
            <div>
                <a href="<?= URL_BASE ?>/login" class="btn btn-outline-light btn-sm me-1">Entrar</a>
                <a href="<?= URL_BASE ?>/cadastrar" class="btn btn-light btn-sm">Criar conta</a>
            </div>
        </div>
    </nav>

    <!-- Apresentação -->
    <section class="navbar-dflg text-white py-5">
        <div class="container py-4 text-center">
            <h1 class="display-5 fw-bold mb-3">Controle suas finanças e evolua enquanto economiza</h1>
            <p class="lead mb-4 mx-auto" style="max-width: 640px;">
                O DFLG Investments junta a organização das suas contas com um sistema de níveis,
                experiência e sequências de acesso — para que cuidar do dinheiro deixe de ser
                uma obrigação e vire um hábito.
            </p>
            <a href="<?= URL_BASE ?>/cadastrar" class="btn btn-light btn-lg">
                <i class="bi bi-rocket-takeoff me-2"></i>Começar agora, é grátis
            </a>
        </div>
    </section>

    <!-- Como funciona -->
    <section class="container py-5">
        <h2 class="text-center mb-5">Como funciona</h2>

        <div class="row g-4">
            <div class="col-md-4">
                <div class="card stat-card shadow-sm h-100">
                    <div class="card-body text-center p-4">
                        <div class="fs-1 text-primary mb-2"><i class="bi bi-1-circle"></i></div>
                        <h5>Registre suas finanças</h5>
                        <p class="text-muted mb-0">
                            Lance receitas e despesas, organize tudo por categoria e acompanhe
                            seus parcelamentos em um só lugar.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card stat-card shadow-sm h-100">
                    <div class="card-body text-center p-4">
                        <div class="fs-1 text-success mb-2"><i class="bi bi-2-circle"></i></div>
                        <h5>Defina suas metas</h5>
                        <p class="text-muted mb-0">
                            Economizar, comprar algo ou investir: crie metas com prazo,
                            guarde dinheiro aos poucos e veja o progresso crescer.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card stat-card shadow-sm h-100">
                    <div class="card-body text-center p-4">
                        <div class="fs-1 text-warning mb-2"><i class="bi bi-3-circle"></i></div>
                        <h5>Ganhe XP e suba de nível</h5>
                        <p class="text-muted mb-0">
                            Cada dia de acesso, cada registro e cada meta cumprida rendem
                            experiência. Compare sua evolução no ranking.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Recursos -->
    <section class="bg-white py-5">
        <div class="container">
            <h2 class="text-center mb-5">O que você encontra na plataforma</h2>

            <div class="row g-4">
                <div class="col-md-6 col-lg-3">
                    <div class="d-flex">
                        <i class="bi bi-graph-up-arrow fs-3 text-primary me-3"></i>
                        <div>
                            <h6 class="mb-1">Dashboard financeiro</h6>
                            <p class="text-muted small mb-0">Saldo, evolução mensal e gastos por categoria.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="d-flex">
                        <i class="bi bi-pie-chart fs-3 text-danger me-3"></i>
                        <div>
                            <h6 class="mb-1">Orçamento por categoria</h6>
                            <p class="text-muted small mb-0">Defina limites mensais e receba avisos antes de estourar.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="d-flex">
                        <i class="bi bi-calculator fs-3 text-warning me-3"></i>
                        <div>
                            <h6 class="mb-1">Calculadora de investimentos</h6>
                            <p class="text-muted small mb-0">Projete quanto seu dinheiro rende com juros compostos.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="d-flex">
                        <i class="bi bi-file-earmark-bar-graph fs-3 text-secondary me-3"></i>
                        <div>
                            <h6 class="mb-1">Relatórios</h6>
                            <p class="text-muted small mb-0">Comparativos mensais e anuais das suas finanças.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Chamada final -->
    <section class="container py-5 text-center">
        <h3 class="mb-3">Pronto para começar?</h3>
        <p class="text-muted mb-4">Crie sua conta em menos de um minuto.</p>
        <a href="<?= URL_BASE ?>/cadastrar" class="btn btn-primary btn-lg me-2">Criar conta</a>
        <a href="<?= URL_BASE ?>/login" class="btn btn-outline-secondary btn-lg">Já tenho conta</a>
    </section>

    <footer class="text-center text-muted py-4 border-top">
        <small>DFLG Investments &bull; Projeto Integrador TDS &bull; IFPR</small>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
