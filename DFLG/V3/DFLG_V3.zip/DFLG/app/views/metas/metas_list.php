<?php

$titulo = 'Metas';
$paginaAtiva = 'metas';

require __DIR__ . '/../partials/header.php';

?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="mb-0"><i class="bi bi-bullseye me-2"></i>Minhas Metas</h2>
    <a href="<?= URL_BASE ?>/metas/cadastrar" class="btn btn-primary">
        <i class="bi bi-plus-circle"></i> Nova Meta
    </a>
</div>

<?php if (isset($sucesso)): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="bi bi-trophy me-2"></i><?= htmlspecialchars($sucesso) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<?php if (isset($erros)): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="bi bi-exclamation-triangle me-2"></i>
        <?= is_array($erros) ? implode('<br>', $erros) : $erros ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<?php if (empty($lista)): ?>
    <div class="alert alert-info">
        <i class="bi bi-info-circle me-2"></i>
        Você ainda não cadastrou nenhuma meta. Que tal começar agora?
    </div>
<?php else: ?>
    <div class="card shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0 align-middle">
                    <thead class="table-light">
                        <tr>
                            <th class="px-4 py-3">Meta</th>
                            <th class="px-4 py-3">Tipo</th>
                            <th class="px-4 py-3">Progresso</th>
                            <th class="px-4 py-3">Data limite</th>
                            <th class="px-4 py-3 text-end">Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($lista as $meta): ?>
                            <tr>
                                <td class="px-4 py-3">
                                    <?= htmlspecialchars($meta->getNomeMeta()) ?>
                                    <?php if ($meta->eConcluida()): ?>
                                        <span class="badge bg-success ms-1">Concluída</span>
                                    <?php elseif ($meta->eVencida()): ?>
                                        <span class="badge bg-danger ms-1">Prazo vencido</span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-4 py-3">
                                    <span class="badge bg-secondary text-capitalize"><?= htmlspecialchars($meta->getTipoMeta()) ?></span>
                                </td>
                                <td class="px-4 py-3" style="min-width: 220px;">
                                    <div class="progress" style="height: 8px;">
                                        <div class="progress-bar <?= $meta->eConcluida() ? 'bg-success' : 'bg-primary' ?>"
                                            role="progressbar" style="width: <?= $meta->getProgresso() ?>%"></div>
                                    </div>
                                    <small class="text-muted">
                                        R$ <?= number_format($meta->getValorAtual(), 2, ',', '.') ?>
                                        de R$ <?= number_format($meta->getValorAlvo(), 2, ',', '.') ?>
                                        (<?= $meta->getProgresso() ?>%)
                                        <?php if (!$meta->eConcluida()): ?>
                                            &bull; faltam R$ <?= number_format($meta->getValorRestante(), 2, ',', '.') ?>
                                        <?php endif; ?>
                                    </small>
                                </td>
                                <td class="px-4 py-3">
                                    <?= date('d/m/Y', strtotime($meta->getDataLimite())) ?>
                                    <?php if (!$meta->eConcluida() && $meta->getDiasRestantes() >= 0): ?>
                                        <br><small class="text-muted"><?= $meta->getDiasRestantes() ?> dia(s)</small>
                                    <?php endif; ?>
                                </td>
                                <td class="px-4 py-3 text-end text-nowrap">
                                    <?php if (!$meta->eConcluida()): ?>
                                        <!-- RF19: aporte para cumprir a meta -->
                                        <button type="button" class="btn btn-sm btn-success" data-bs-toggle="modal"
                                            data-bs-target="#aporteModal<?= $meta->getId() ?>">
                                            <i class="bi bi-piggy-bank"></i> Guardar
                                        </button>
                                    <?php endif; ?>
                                    <a href="<?= URL_BASE ?>/metas/editar?id=<?= $meta->getId() ?>" class="btn btn-sm btn-outline-primary">
                                        <i class="bi bi-pencil"></i> Editar
                                    </a>
                                    <a href="<?= URL_BASE ?>/metas/excluir?id=<?= $meta->getId() ?>" class="btn btn-sm btn-outline-danger"
                                        onclick="return confirm('Deseja realmente excluir esta meta?')">
                                        <i class="bi bi-trash"></i> Excluir
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Modais de aporte (RF19) -->
    <?php foreach ($lista as $meta): ?>
        <?php if (!$meta->eConcluida()): ?>
            <div class="modal fade" id="aporteModal<?= $meta->getId() ?>" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <form method="post" action="<?= URL_BASE ?>/metas/aportar">
                            <div class="modal-header">
                                <h5 class="modal-title">
                                    <i class="bi bi-piggy-bank me-2"></i><?= htmlspecialchars($meta->getNomeMeta()) ?>
                                </h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                            </div>
                            <div class="modal-body">
                                <input type="hidden" name="id" value="<?= $meta->getId() ?>">

                                <p class="text-muted small">
                                    Guardado: R$ <?= number_format($meta->getValorAtual(), 2, ',', '.') ?>
                                    &bull; Falta: R$ <?= number_format($meta->getValorRestante(), 2, ',', '.') ?>
                                </p>

                                <label for="valor<?= $meta->getId() ?>" class="form-label">Quanto você quer guardar? (R$)</label>
                                <input type="number" step="0.01" min="0.01" class="form-control"
                                    id="valor<?= $meta->getId() ?>" name="valor" required autofocus>
                                <div class="form-text">
                                    Ao atingir o valor alvo você ganha
                                    <?= app\services\GamificacaoService::XP_META_CONCLUIDA ?> XP.
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancelar</button>
                                <button type="submit" class="btn btn-success">
                                    <i class="bi bi-check-lg"></i> Guardar
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    <?php endforeach; ?>
<?php endif; ?>

<?php require __DIR__ . '/../partials/footer.php'; ?>
