<?php

$titulo = 'Novo Parcelamento';
$paginaAtiva = 'parcelamentos';

require __DIR__ . '/../partials/header.php';

?>

        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="mb-0">Novo Parcelamento</h2>
            <a href="<?= URL_BASE ?>/parcelamentos" class="btn btn-outline-secondary">
                <i class="bi bi-arrow-left"></i> Voltar
            </a>
        </div>

        <div class="card shadow-sm">
            <div class="card-body p-4">

                <form action="<?= URL_BASE ?>/parcelamentos/salvar" method="post">

                    <div class="row g-3">

                        <div class="col-md-8">
                            <label for="descricao" class="form-label">Descrição</label>
                            <input type="text" class="form-control" id="descricao" name="descricao"
                                value="<?= htmlspecialchars($parcelamento['descricao'] ?? '') ?>">
                            <?php if (isset($erros['descricao'])): ?>
                                <div class="text-danger small"><?= $erros['descricao'] ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="col-md-4">
                            <label for="categoriaId" class="form-label">Categoria</label>
                            <select class="form-select" id="categoriaId" name="categoriaId">
                                <option value="">Sem categoria</option>
                                <?php foreach ($categorias as $categoria): ?>
                                    <option value="<?= $categoria->getId() ?>"
                                        <?= (isset($parcelamento['categoriaId']) && $parcelamento['categoriaId'] == $categoria->getId()) ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($categoria->getNome()) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="col-md-3">
                            <label for="valorTotal" class="form-label">Valor total (R$)</label>
                            <input type="number" step="0.01" min="0.01" class="form-control" id="valorTotal" name="valorTotal"
                                value="<?= htmlspecialchars($parcelamento['valorTotal'] ?? '') ?>">
                            <?php if (isset($erros['valorTotal'])): ?>
                                <div class="text-danger small"><?= $erros['valorTotal'] ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="col-md-3">
                            <label for="quantidadeParcelas" class="form-label">Qtd. de parcelas</label>
                            <input type="number" min="1" step="1" class="form-control" id="quantidadeParcelas" name="quantidadeParcelas"
                                value="<?= htmlspecialchars($parcelamento['quantidadeParcelas'] ?? '') ?>">
                            <?php if (isset($erros['quantidadeParcelas'])): ?>
                                <div class="text-danger small"><?= $erros['quantidadeParcelas'] ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="col-md-3">
                            <label for="parcelasPagas" class="form-label">Parcelas já pagas</label>
                            <input type="number" min="0" step="1" class="form-control" id="parcelasPagas" name="parcelasPagas"
                                value="<?= htmlspecialchars($parcelamento['parcelasPagas'] ?? '0') ?>">
                            <?php if (isset($erros['parcelasPagas'])): ?>
                                <div class="text-danger small"><?= $erros['parcelasPagas'] ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="col-md-3">
                            <label for="dataPrimeiraParcela" class="form-label">Data da 1ª parcela</label>
                            <input type="date" class="form-control" id="dataPrimeiraParcela" name="dataPrimeiraParcela"
                                value="<?= htmlspecialchars($parcelamento['dataPrimeiraParcela'] ?? date('Y-m-d')) ?>">
                            <?php if (isset($erros['dataPrimeiraParcela'])): ?>
                                <div class="text-danger small"><?= $erros['dataPrimeiraParcela'] ?></div>
                            <?php endif; ?>
                        </div>

                    </div>

                    <div class="mt-4 d-flex justify-content-end">
                        <button type="submit" class="btn btn-primary px-4">
                            <i class="bi bi-check-circle"></i> Salvar
                        </button>
                    </div>

                </form>

            </div>
        </div>

<?php require __DIR__ . '/../partials/footer.php'; ?>
