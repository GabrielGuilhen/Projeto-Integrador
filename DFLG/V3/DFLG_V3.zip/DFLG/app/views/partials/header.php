<?php

// Cabeçalho compartilhado das telas internas.
// A view define $titulo e $paginaAtiva antes de incluir este arquivo.

$titulo = $titulo ?? APP_NAME;
$paginaAtiva = $paginaAtiva ?? '';
$usuarioLogado = $_SESSION['usuario_logado'] ?? null;

$menu = [
    'dashboard' => ['rota' => '/dashboard', 'rotulo' => 'Dashboard'],
    'transacoes' => ['rota' => '/transacoes', 'rotulo' => 'Finanças'],
    'metas' => ['rota' => '/metas', 'rotulo' => 'Metas'],
    'parcelamentos' => ['rota' => '/parcelamentos', 'rotulo' => 'Parcelamentos'],
    'orcamentos' => ['rota' => '/orcamentos', 'rotulo' => 'Orçamento'],
    'relatorios' => ['rota' => '/relatorios', 'rotulo' => 'Relatórios'],
    'calculadora' => ['rota' => '/calculadora', 'rotulo' => 'Calculadora'],
    'ranking' => ['rota' => '/ranking', 'rotulo' => 'Ranking'],
];

?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($titulo) ?> • <?= APP_NAME ?></title>

    <!-- RNF08: aplica o tema salvo antes de renderizar a página -->
    <script src="<?= URL_BASE ?>/assets/js/tema.js"></script>

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <!-- Estilos do DFLG Investments -->
    <link href="<?= URL_BASE_CSS ?>/style.css" rel="stylesheet">
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-dark navbar-dflg mb-4">
        <div class="container">

            <a href="<?= URL_BASE ?>/dashboard" class="navbar-brand">
                <i class="bi bi-piggy-bank-fill me-2"></i>DFLG Investments
            </a>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#menuPrincipal" aria-controls="menuPrincipal"
                aria-expanded="false" aria-label="Abrir menu">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="menuPrincipal">

                <ul class="navbar-nav me-auto">
                    <?php foreach ($menu as $chave => $item): ?>
                        <li class="nav-item">
                            <a class="nav-link <?= $paginaAtiva === $chave ? 'active fw-bold' : '' ?>"
                                href="<?= URL_BASE . $item['rota'] ?>"><?= $item['rotulo'] ?></a>
                        </li>
                    <?php endforeach; ?>

                    <?php if ($usuarioLogado && $usuarioLogado->eAdmin()): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle <?= $paginaAtiva === 'admin' ? 'active fw-bold' : '' ?>"
                                href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="bi bi-shield-lock me-1"></i>Admin
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="<?= URL_BASE ?>/admin">Painel</a></li>
                                <li><a class="dropdown-item" href="<?= URL_BASE ?>/admin/usuarios">Usuários</a></li>
                                <li><a class="dropdown-item" href="<?= URL_BASE ?>/categorias">Categorias</a></li>
                            </ul>
                        </li>
                    <?php endif; ?>
                </ul>

                <div class="d-flex align-items-center gap-2">

                    <!-- RNF08: alternância de tema -->
                    <button type="button" id="temaBotao" class="btn btn-sm btn-outline-light"
                        title="Alternar modo claro e escuro">
                        <i id="temaIcone" class="bi bi-moon-stars-fill"></i>
                    </button>

                    <a href="<?= URL_BASE ?>/perfil"
                        class="btn btn-sm <?= $paginaAtiva === 'perfil' ? 'btn-light' : 'btn-outline-light' ?>">
                        <i class="bi bi-person-circle me-1"></i>Perfil
                    </a>

                    <a href="<?= URL_BASE ?>/logout" class="btn btn-outline-light btn-sm">
                        <i class="bi bi-box-arrow-right me-1"></i>Sair
                    </a>
                </div>

            </div>
        </div>
    </nav>

    <div class="container pb-5">
