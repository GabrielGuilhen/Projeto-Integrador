<?php

$titulo = 'Editar Perfil';
$paginaAtiva = 'perfil';

require __DIR__ . '/../partials/header.php';

?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="mb-0"><i class="bi bi-person-gear me-2"></i>Editar Perfil</h2>
    <a href="<?= URL_BASE ?>/perfil" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left"></i> Voltar
    </a>
</div>

<?php if (isset($erros)): ?>
    <div class="alert alert-danger">
        <i class="bi bi-exclamation-triangle me-2"></i>
        <?= is_array($erros) ? implode('<br>', $erros) : $erros ?>
    </div>
<?php endif; ?>

<div class="card shadow-sm">
    <div class="card-body">
        <form method="post" action="<?= URL_BASE ?>/perfil/atualizar" enctype="multipart/form-data">

            <div class="row g-3">

                <div class="col-md-6">
                    <label for="nome" class="form-label">Nome</label>
                    <input type="text" class="form-control" id="nome" name="nome"
                        value="<?= htmlspecialchars($usuario->getNome()) ?>" required>
                </div>

                <div class="col-md-6">
                    <label for="nickname" class="form-label">Nickname</label>
                    <input type="text" class="form-control" id="nickname" name="nickname"
                        value="<?= htmlspecialchars($usuario->getNickname()) ?>" required>
                </div>

                <div class="col-md-6">
                    <label for="email" class="form-label">E-mail</label>
                    <input type="email" class="form-control" id="email" name="email"
                        value="<?= htmlspecialchars($usuario->getEmail()) ?>" required>
                </div>

                <div class="col-md-6">
                    <label for="dataNascimento" class="form-label">Data de nascimento</label>
                    <input type="date" class="form-control" id="dataNascimento" name="dataNascimento"
                        value="<?= htmlspecialchars($usuario->getDataNascimento()) ?>" required>
                </div>

                <div class="col-12">
                    <label for="foto" class="form-label">Foto de perfil</label>

                    <?php if ($usuario->getFoto()): ?>
                        <div class="mb-2">
                            <img src="<?= URL_BASE_UPLOADS ?>/<?= htmlspecialchars($usuario->getFoto()) ?>"
                                alt="Foto atual" class="rounded-circle"
                                style="width: 80px; height: 80px; object-fit: cover;">
                        </div>
                    <?php endif; ?>

                    <input type="file" class="form-control" id="foto" name="foto" accept="image/*">
                    <div class="form-text">JPG, PNG, GIF ou WEBP, até 2MB. Deixe em branco para manter a foto atual.</div>
                </div>

            </div>

            <div class="mt-4">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-check-lg"></i> Salvar alterações
                </button>
                <a href="<?= URL_BASE ?>/perfil" class="btn btn-light">Cancelar</a>
            </div>

        </form>
    </div>
</div>

<?php require __DIR__ . '/../partials/footer.php'; ?>
