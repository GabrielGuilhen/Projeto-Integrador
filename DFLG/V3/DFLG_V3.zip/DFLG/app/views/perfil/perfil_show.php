<?php

$titulo = 'Meu Perfil';
$paginaAtiva = 'perfil';

require __DIR__ . '/../partials/header.php';

$origens = [
    'acesso_diario' => ['rotulo' => 'Acesso diário', 'icone' => 'bi-calendar-check'],
    'registro_financeiro' => ['rotulo' => 'Registro financeiro', 'icone' => 'bi-cash-stack'],
    'meta_concluida' => ['rotulo' => 'Meta concluída', 'icone' => 'bi-trophy'],
];

?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="mb-0"><i class="bi bi-person-circle me-2"></i>Meu Perfil</h2>
    <a href="<?= URL_BASE ?>/perfil/editar" class="btn btn-primary">
        <i class="bi bi-pencil"></i> Editar perfil
    </a>
</div>

<?php if (!empty($sucesso)): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="bi bi-check-circle me-2"></i><?= htmlspecialchars($sucesso) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<?php if (!empty($erros)): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="bi bi-exclamation-triangle me-2"></i>
        <?= is_array($erros) ? implode('<br>', $erros) : $erros ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<div class="row g-3">

    <!-- Cartão de identidade (RF14) -->
    <div class="col-lg-4">
        <div class="card stat-card shadow-sm h-100">
            <div class="card-body text-center">

                <?php if ($usuario->getFoto()): ?>
                    <img src="<?= URL_BASE_UPLOADS ?>/<?= htmlspecialchars($usuario->getFoto()) ?>"
                        alt="Foto de perfil" class="rounded-circle mb-3"
                        style="width: 120px; height: 120px; object-fit: cover;">
                <?php else: ?>
                    <div class="rounded-circle bg-secondary d-inline-flex align-items-center justify-content-center mb-3"
                        style="width: 120px; height: 120px;">
                        <i class="bi bi-person text-white" style="font-size: 3rem;"></i>
                    </div>
                <?php endif; ?>

                <h4 class="mb-0"><?= htmlspecialchars($usuario->getNome()) ?></h4>
                <p class="text-muted">@<?= htmlspecialchars($usuario->getNickname()) ?></p>

                <?php if ($usuario->eAdmin()): ?>
                    <span class="badge bg-warning text-dark mb-2">Administrador</span>
                <?php endif; ?>

                <hr>

                <div class="row text-center">
                    <div class="col">
                        <div class="fw-bold fs-4"><?= $gamificacao ? $gamificacao->getNivel() : 1 ?></div>
                        <small class="text-muted">Nível</small>
                    </div>
                    <div class="col">
                        <div class="fw-bold fs-4"><?= $posicao !== null ? $posicao . 'º' : '—' ?></div>
                        <small class="text-muted">Ranking</small>
                    </div>
                    <div class="col">
                        <div class="fw-bold fs-4"><?= $gamificacao ? $gamificacao->getStreakAtual() : 0 ?></div>
                        <small class="text-muted">Sequência</small>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <!-- Progresso e estatísticas -->
    <div class="col-lg-8">
        <div class="card stat-card shadow-sm mb-3">
            <div class="card-body">
                <h5 class="mb-3"><i class="bi bi-stars me-2 text-warning"></i>Progresso</h5>

                <?php if ($gamificacao): ?>
                    <div class="d-flex justify-content-between small mb-1">
                        <span>Nível <?= $gamificacao->getNivel() ?></span>
                        <span><?= $gamificacao->getXpTotal() ?> XP no total</span>
                    </div>
                    <div class="progress mb-2" style="height: 12px;">
                        <div class="progress-bar bg-warning" role="progressbar"
                            style="width: <?= $progressoNivel ?? 0 ?>%"></div>
                    </div>
                    <small class="text-muted">
                        Faltam <?= $xpProximoNivel ?? 0 ?> XP para o nível <?= $gamificacao->getNivel() + 1 ?>.
                    </small>

                    <div class="row text-center mt-4">
                        <div class="col-4">
                            <div class="fw-bold fs-5"><?= $gamificacao->getMaiorStreak() ?></div>
                            <small class="text-muted">Maior sequência</small>
                        </div>
                        <div class="col-4">
                            <div class="fw-bold fs-5"><?= $totalMetas ?></div>
                            <small class="text-muted">Metas criadas</small>
                        </div>
                        <div class="col-4">
                            <div class="fw-bold fs-5"><?= $metasConcluidas ?></div>
                            <small class="text-muted">Metas concluídas</small>
                        </div>
                    </div>
                <?php else: ?>
                    <p class="text-muted mb-0">
                        Contas administrativas não participam da gamificação.
                    </p>
                <?php endif; ?>
            </div>
        </div>

        <!-- RF04: visibilidade no ranking -->
        <?php if ($gamificacao): ?>
            <div class="card stat-card shadow-sm">
                <div class="card-body">
                    <h5 class="mb-3"><i class="bi bi-eye me-2 text-primary"></i>Visibilidade no ranking</h5>

                    <form method="post" action="<?= URL_BASE ?>/perfil/visibilidade">
                        <div class="form-check form-switch mb-3">
                            <input class="form-check-input" type="checkbox" role="switch"
                                id="visibilidadeRanking" name="visibilidadeRanking"
                                <?= $gamificacao->getVisibilidadeRanking() ? 'checked' : '' ?>>
                            <label class="form-check-label" for="visibilidadeRanking">
                                Aparecer no ranking público
                            </label>
                        </div>
                        <button type="submit" class="btn btn-sm btn-outline-primary">Salvar preferência</button>
                    </form>
                </div>
            </div>
        <?php endif; ?>
    </div>

</div>

<!-- Histórico de experiência -->
<?php if (!empty($historico)): ?>
    <div class="card stat-card shadow-sm mt-3">
        <div class="card-body">
            <h5 class="mb-3"><i class="bi bi-clock-history me-2 text-success"></i>Últimos ganhos de XP</h5>
            <div class="table-responsive">
                <table class="table table-sm mb-0 align-middle">
                    <tbody>
                        <?php foreach ($historico as $ganho): ?>
                            <?php $origem = $origens[$ganho['origem']] ?? ['rotulo' => $ganho['origem'], 'icone' => 'bi-dot']; ?>
                            <tr>
                                <td style="width: 40px;"><i class="bi <?= $origem['icone'] ?> text-muted"></i></td>
                                <td><?= $origem['rotulo'] ?></td>
                                <td class="text-muted"><?= date('d/m/Y', strtotime($ganho['data_ganho'])) ?></td>
                                <td class="text-end fw-bold text-success">+<?= (int) $ganho['pontos'] ?> XP</td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php endif; ?>

<!-- Troca de senha -->
<div class="card stat-card shadow-sm mt-3">
    <div class="card-body">
        <h5 class="mb-3"><i class="bi bi-key me-2 text-secondary"></i>Alterar senha</h5>

        <form method="post" action="<?= URL_BASE ?>/perfil/senha" class="row g-3">
            <div class="col-md-4">
                <label for="senhaAtual" class="form-label">Senha atual</label>
                <input type="password" class="form-control" id="senhaAtual" name="senhaAtual" required>
            </div>
            <div class="col-md-4">
                <label for="novaSenha" class="form-label">Nova senha</label>
                <input type="password" class="form-control" id="novaSenha" name="novaSenha" minlength="6" required>
            </div>
            <div class="col-md-4">
                <label for="confirmacao" class="form-label">Confirmar nova senha</label>
                <input type="password" class="form-control" id="confirmacao" name="confirmacao" minlength="6" required>
            </div>
            <div class="col-12">
                <button type="submit" class="btn btn-outline-secondary">
                    <i class="bi bi-shield-lock"></i> Alterar senha
                </button>
            </div>
        </form>
    </div>
</div>

<?php require __DIR__ . '/../partials/footer.php'; ?>
