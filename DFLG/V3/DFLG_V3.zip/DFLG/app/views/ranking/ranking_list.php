<?php

$titulo = 'Ranking';
$paginaAtiva = 'ranking';

require __DIR__ . '/../partials/header.php';

?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="mb-0"><i class="bi bi-trophy me-2"></i>Ranking</h2>
    <?php if ($minhaPosicao !== null): ?>
        <span class="badge bg-primary fs-6">Sua posição: <?= $minhaPosicao ?>º</span>
    <?php endif; ?>
</div>

<!-- RN10: rankings geral, mensal e semanal -->
<ul class="nav nav-pills mb-4">
    <?php foreach ($periodos as $chave => $rotulo): ?>
        <li class="nav-item">
            <a class="nav-link <?= $periodo === $chave ? 'active' : '' ?>"
                href="<?= URL_BASE ?>/ranking?periodo=<?= $chave ?>"><?= $rotulo ?></a>
        </li>
    <?php endforeach; ?>
</ul>

<?php if ($minhaPosicao === null): ?>
    <div class="alert alert-secondary">
        <i class="bi bi-eye-slash me-2"></i>
        Você não aparece no ranking. Ative a visibilidade no
        <a href="<?= URL_BASE ?>/perfil">seu perfil</a> para participar.
    </div>
<?php endif; ?>

<?php if (empty($lista)): ?>
    <div class="alert alert-info">
        <i class="bi bi-info-circle me-2"></i>
        Nenhuma pontuação registrada neste período ainda.
    </div>
<?php else: ?>
    <div class="card shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0 align-middle">
                    <thead class="table-light">
                        <tr>
                            <th class="px-4 py-3" style="width: 80px;">#</th>
                            <th class="px-4 py-3">Usuário</th>
                            <th class="px-4 py-3 text-center">Nível</th>
                            <th class="px-4 py-3 text-center">Sequência</th>
                            <th class="px-4 py-3 text-end">
                                <?= $periodo === 'geral' ? 'XP total' : 'XP no período' ?>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($lista as $linha): ?>
                            <tr class="<?= (int) $linha['id'] === $usuarioLogadoId ? 'table-primary' : '' ?>">
                                <td class="px-4 py-3">
                                    <?php if ($linha['posicao'] <= 3): ?>
                                        <i class="bi bi-trophy-fill <?= $linha['posicao'] === 1 ? 'text-warning' : ($linha['posicao'] === 2 ? 'text-secondary' : 'text-danger') ?>"></i>
                                    <?php endif; ?>
                                    <?= $linha['posicao'] ?>º
                                </td>
                                <td class="px-4 py-3">
                                    <?= htmlspecialchars($linha['nome']) ?>
                                    <small class="text-muted">@<?= htmlspecialchars($linha['nickname']) ?></small>
                                    <?php if ((int) $linha['id'] === $usuarioLogadoId): ?>
                                        <span class="badge bg-primary ms-1">Você</span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-4 py-3 text-center">
                                    <span class="badge bg-secondary">Nível <?= (int) $linha['nivel'] ?></span>
                                </td>
                                <td class="px-4 py-3 text-center">
                                    <i class="bi bi-fire text-danger"></i> <?= (int) $linha['streak_atual'] ?>
                                </td>
                                <td class="px-4 py-3 text-end fw-bold">
                                    <?= $periodo === 'geral' ? (int) $linha['xp_total'] : (int) $linha['pontos_periodo'] ?> XP
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php require __DIR__ . '/../partials/footer.php'; ?>
