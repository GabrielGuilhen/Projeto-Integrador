<?php

$titulo = 'Relatórios';
$paginaAtiva = 'relatorios';

require __DIR__ . '/../partials/header.php';

$nomesMeses = [
    1 => 'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
    'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro',
];

// Indexa o resumo anual por mês para preencher os meses sem lançamento
$porMes = [];

foreach ($resumoAnual as $linha) {
    $porMes[(int) $linha['mes']] = $linha;
}

$maiorValorAno = 0;

foreach ($resumoAnual as $linha) {
    $maiorValorAno = max($maiorValorAno, (float) $linha['receitas'], (float) $linha['despesas']);
}

$totalGastoMes = 0;

foreach ($gastoPorCategoria as $gasto) {
    $totalGastoMes += (float) $gasto['total'];
}

?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="mb-0"><i class="bi bi-file-earmark-bar-graph me-2"></i>Relatórios</h2>
</div>

<!-- Seleção do período -->
<div class="card shadow-sm mb-4">
    <div class="card-body">
        <form action="<?= URL_BASE ?>/relatorios" method="get" class="row g-2 align-items-end">
            <div class="col-md-3">
                <label for="mes" class="form-label small fw-bold">Mês</label>
                <select class="form-select" id="mes" name="mes">
                    <?php foreach ($nomesMeses as $numero => $nome): ?>
                        <option value="<?= $numero ?>" <?= $mes === $numero ? 'selected' : '' ?>><?= $nome ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label for="ano" class="form-label small fw-bold">Ano</label>
                <select class="form-select" id="ano" name="ano">
                    <?php foreach ($anosDisponiveis as $anoOpcao): ?>
                        <option value="<?= $anoOpcao ?>" <?= $ano === $anoOpcao ? 'selected' : '' ?>><?= $anoOpcao ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-search"></i> Gerar relatório
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Relatório mensal -->
<h5 class="mb-3"><i class="bi bi-calendar-month me-2 text-primary"></i>
    Relatório de <?= $nomesMeses[$mes] ?> de <?= $ano ?>
</h5>

<div class="row g-3">
    <div class="col-md-4">
        <div class="card stat-card shadow-sm h-100">
            <div class="card-body">
                <p class="text-muted small mb-1">Receitas do mês</p>
                <h4 class="mb-0 text-success">R$ <?= number_format($receitasMes, 2, ',', '.') ?></h4>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card stat-card shadow-sm h-100">
            <div class="card-body">
                <p class="text-muted small mb-1">Despesas do mês</p>
                <h4 class="mb-0 text-danger">R$ <?= number_format($despesasMes, 2, ',', '.') ?></h4>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card stat-card shadow-sm h-100">
            <div class="card-body">
                <p class="text-muted small mb-1">Saldo do mês</p>
                <h4 class="mb-0 <?= $saldoMes >= 0 ? 'text-success' : 'text-danger' ?>">
                    R$ <?= number_format($saldoMes, 2, ',', '.') ?>
                </h4>
            </div>
        </div>
    </div>
</div>

<div class="card stat-card shadow-sm mt-3">
    <div class="card-body">
        <h5 class="mb-3">Despesas por categoria</h5>

        <?php if (empty($gastoPorCategoria)): ?>
            <p class="text-muted mb-0">Nenhuma despesa registrada neste mês.</p>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover mb-0 align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Categoria</th>
                            <th style="width: 40%;">Participação</th>
                            <th class="text-end">Valor</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($gastoPorCategoria as $gasto): ?>
                            <?php $participacao = $totalGastoMes > 0 ? $gasto['total'] / $totalGastoMes * 100 : 0; ?>
                            <tr>
                                <td>
                                    <?php if (!empty($gasto['icone'])): ?>
                                        <i class="bi <?= htmlspecialchars($gasto['icone']) ?> me-2 text-muted"></i>
                                    <?php endif; ?>
                                    <?= htmlspecialchars($gasto['nome']) ?>
                                </td>
                                <td>
                                    <div class="progress" style="height: 8px;">
                                        <div class="progress-bar bg-danger" role="progressbar"
                                            style="width: <?= $participacao ?>%"></div>
                                    </div>
                                    <small class="text-muted"><?= number_format($participacao, 1, ',', '.') ?>%</small>
                                </td>
                                <td class="text-end fw-bold">R$ <?= number_format($gasto['total'], 2, ',', '.') ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot class="table-light">
                        <tr>
                            <th colspan="2">Total</th>
                            <th class="text-end">R$ <?= number_format($totalGastoMes, 2, ',', '.') ?></th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Relatório anual -->
<h5 class="mt-4 mb-3"><i class="bi bi-calendar3 me-2 text-secondary"></i>Relatório anual de <?= $ano ?></h5>

<div class="row g-3">
    <div class="col-md-4">
        <div class="card stat-card shadow-sm h-100">
            <div class="card-body">
                <p class="text-muted small mb-1">Receitas do ano</p>
                <h4 class="mb-0 text-success">R$ <?= number_format($receitasAno, 2, ',', '.') ?></h4>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card stat-card shadow-sm h-100">
            <div class="card-body">
                <p class="text-muted small mb-1">Despesas do ano</p>
                <h4 class="mb-0 text-danger">R$ <?= number_format($despesasAno, 2, ',', '.') ?></h4>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card stat-card shadow-sm h-100">
            <div class="card-body">
                <p class="text-muted small mb-1">Saldo do ano</p>
                <h4 class="mb-0 <?= $saldoAno >= 0 ? 'text-success' : 'text-danger' ?>">
                    R$ <?= number_format($saldoAno, 2, ',', '.') ?>
                </h4>
            </div>
        </div>
    </div>
</div>

<div class="card stat-card shadow-sm mt-3">
    <div class="card-body">
        <h5 class="mb-3">Comparativo mês a mês</h5>
        <div class="table-responsive">
            <table class="table table-hover mb-0 align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Mês</th>
                        <th style="width: 35%;">Receitas x Despesas</th>
                        <th class="text-end">Receitas</th>
                        <th class="text-end">Despesas</th>
                        <th class="text-end">Saldo</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($nomesMeses as $numero => $nome): ?>
                        <?php
                        $receitas = isset($porMes[$numero]) ? (float) $porMes[$numero]['receitas'] : 0.0;
                        $despesas = isset($porMes[$numero]) ? (float) $porMes[$numero]['despesas'] : 0.0;
                        $saldo = $receitas - $despesas;
                        ?>
                        <tr class="<?= $numero === $mes ? 'table-primary' : '' ?>">
                            <td><?= $nome ?></td>
                            <td>
                                <div class="progress mb-1" style="height: 6px;">
                                    <div class="progress-bar bg-success" role="progressbar"
                                        style="width: <?= $maiorValorAno > 0 ? $receitas / $maiorValorAno * 100 : 0 ?>%"></div>
                                </div>
                                <div class="progress" style="height: 6px;">
                                    <div class="progress-bar bg-danger" role="progressbar"
                                        style="width: <?= $maiorValorAno > 0 ? $despesas / $maiorValorAno * 100 : 0 ?>%"></div>
                                </div>
                            </td>
                            <td class="text-end text-success">R$ <?= number_format($receitas, 2, ',', '.') ?></td>
                            <td class="text-end text-danger">R$ <?= number_format($despesas, 2, ',', '.') ?></td>
                            <td class="text-end fw-bold <?= $saldo >= 0 ? 'text-success' : 'text-danger' ?>">
                                R$ <?= number_format($saldo, 2, ',', '.') ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require __DIR__ . '/../partials/footer.php'; ?>
