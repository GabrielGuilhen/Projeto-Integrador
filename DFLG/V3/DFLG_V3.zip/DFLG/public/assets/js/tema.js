/*
 * RNF08: alternância entre modo claro e modo escuro.
 * A preferência fica no localStorage e é reaplicada em todas as telas.
 */
(function () {
    'use strict';

    var CHAVE = 'dflg-tema';

    function aplicar(tema) {
        document.documentElement.setAttribute('data-tema', tema);

        var icone = document.getElementById('temaIcone');

        if (icone) {
            icone.className = tema === 'escuro' ? 'bi bi-sun-fill' : 'bi bi-moon-stars-fill';
        }
    }

    function temaSalvo() {
        return localStorage.getItem(CHAVE) || 'claro';
    }

    // Aplica antes da renderização para evitar piscar a tela clara
    aplicar(temaSalvo());

    document.addEventListener('DOMContentLoaded', function () {

        aplicar(temaSalvo());

        var botao = document.getElementById('temaBotao');

        if (!botao) {
            return;
        }

        botao.addEventListener('click', function () {

            var novoTema = temaSalvo() === 'escuro' ? 'claro' : 'escuro';

            localStorage.setItem(CHAVE, novoTema);
            aplicar(novoTema);
        });
    });
})();
