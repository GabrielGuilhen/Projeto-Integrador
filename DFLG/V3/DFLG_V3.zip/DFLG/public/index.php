<?php

require_once __DIR__ . '/../app/core/Autoload.php';
require_once __DIR__ . '/../app/config/Config.php';

use app\core\Router;

$router = new Router();

// RF15/RN11: a raiz é a home pública; o dashboard exige autenticação
$router->get('/', 'HomeController@index');
$router->get('/dashboard', 'DashboardController@index');

//Autenticacao
$router->get('/login', 'AutenticacaoController@login');
$router->post('/logar', 'AutenticacaoController@logar');
$router->get('/logout', 'AutenticacaoController@logout');

$router->get('/cadastrar', 'AutenticacaoController@cadastrar');
$router->post('/cadastrar/salvar', 'AutenticacaoController@salvar');

// Ranking Routes
$router->get('/ranking', 'RankingController@index');

// Perfil Routes
$router->get('/perfil', 'PerfilController@index');
$router->get('/perfil/editar', 'PerfilController@editar');
$router->post('/perfil/atualizar', 'PerfilController@atualizar');
$router->post('/perfil/senha', 'PerfilController@alterarSenha');
$router->post('/perfil/visibilidade', 'PerfilController@alterarVisibilidade');

// Calculadora Routes
$router->get('/calculadora', 'CalculadoraController@index');
$router->post('/calculadora/calcular', 'CalculadoraController@calcular');
$router->post('/calculadora/salvar', 'CalculadoraController@salvar');
$router->get('/calculadora/excluir', 'CalculadoraController@excluir');

// Relatorio Routes
$router->get('/relatorios', 'RelatorioController@index');

// Orcamento Routes
$router->get('/orcamentos', 'CategoriaController@orcamentos');
$router->post('/orcamentos/salvar', 'CategoriaController@salvarOrcamento');
$router->get('/orcamentos/excluir', 'CategoriaController@excluirOrcamento');

// Categoria Routes (admin)
$router->get('/categorias', 'CategoriaController@listarTodas');
$router->get('/categorias/cadastrar', 'CategoriaController@criar');
$router->post('/categorias/salvar', 'CategoriaController@salvar');
$router->get('/categorias/editar', 'CategoriaController@editar');
$router->post('/categorias/atualizar', 'CategoriaController@atualizar');
$router->get('/categorias/excluir', 'CategoriaController@excluir');

// Admin Routes
$router->get('/admin', 'AdminController@index');
$router->get('/admin/usuarios', 'AdminController@listarUsuarios');
$router->get('/admin/usuarios/editar', 'AdminController@editar');
$router->post('/admin/usuarios/atualizar', 'AdminController@atualizar');
$router->get('/admin/usuarios/bloquear', 'AdminController@bloquear');
$router->get('/admin/usuarios/desbloquear', 'AdminController@desbloquear');
$router->get('/admin/usuarios/excluir', 'AdminController@excluir');

// Meta Routes
$router->get('/metas', 'MetaController@listarTodas');
$router->get('/metas/cadastrar', 'MetaController@criar');
$router->post('/metas/salvar', 'MetaController@salvar');
$router->get('/metas/editar', 'MetaController@editar');
$router->post('/metas/atualizar', 'MetaController@atualizar');
$router->post('/metas/aportar', 'MetaController@aportar');
$router->get('/metas/excluir', 'MetaController@excluir');

// Transacao Routes
$router->get('/transacoes', 'TransacaoController@listarTodas');
$router->get('/transacoes/cadastrar', 'TransacaoController@criar');
$router->post('/transacoes/salvar', 'TransacaoController@salvar');
$router->get('/transacoes/editar', 'TransacaoController@editar');
$router->post('/transacoes/atualizar', 'TransacaoController@atualizar');
$router->get('/transacoes/excluir', 'TransacaoController@excluir');

// Parcelamento Routes
$router->get('/parcelamentos', 'ParcelaController@listarTodos');
$router->get('/parcelamentos/cadastrar', 'ParcelaController@criar');
$router->post('/parcelamentos/salvar', 'ParcelaController@salvar');
$router->get('/parcelamentos/editar', 'ParcelaController@editar');
$router->post('/parcelamentos/atualizar', 'ParcelaController@atualizar');
$router->get('/parcelamentos/excluir', 'ParcelaController@excluir');

$router->run();
